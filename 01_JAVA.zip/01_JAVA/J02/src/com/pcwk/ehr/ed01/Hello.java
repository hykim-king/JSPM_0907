package com.pcwk.ehr.ed01;

//실행: ctrl + f11
//클래스
public class Hello {

	//main 메서드
	public static void main(String args[]) {
		System.out.println("Hello, world!"); //문장의 끝
	}
	
}
