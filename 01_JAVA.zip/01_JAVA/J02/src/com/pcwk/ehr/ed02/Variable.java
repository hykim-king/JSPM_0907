package com.pcwk.ehr.ed02;

public class Variable {
    
	/**
	 * main : 모든 프로그램에 시작 <br/>
	 * 변수: 데이터를 저장하는 공간
	 * @param args
	 */
	public static void main(String[] args) {
		int year = 2023; //문장에 끝 ';' 사용
		int age  = 22;
		
		System.out.println("year:"+year);//year:2023
		System.out.println("age:"+age);
	}
}
