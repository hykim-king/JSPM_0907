package com.pcwk.ehr.ed01;

public class ConstantMain {

	public static void main(String[] args) {
		final int MAX_SPEED = 10;//final 상수 생성
		
		//MAX_SPEED = 99; 상수는 값을 변경할 수 없다.

		System.out.println("MAX_SPEED:"+MAX_SPEED);
	}

}
