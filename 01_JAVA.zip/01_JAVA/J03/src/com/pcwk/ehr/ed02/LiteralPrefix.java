package com.pcwk.ehr.ed02;

public class LiteralPrefix {

	public static void main(String[] args) {
		int octNum = 010;//8진수 10
		int hexNum = 0x10;//16진수 10
		int binNum = 0b10;//2진수 10
		
		System.out.println("octNum="+octNum);//10진수 8
		System.out.println("hexNum="+hexNum);//10진수 16
		System.out.println("binNum="+binNum);//10진수 2
		
		System.out.println("-------------------------");
		//천단위 구분 기호
		long big = 100_000_000_000L;
		
		long hex = 0x100_000_000_000L;
		System.out.println("big="+big);
		System.out.println("hex="+hex);
		
	}
	

}
