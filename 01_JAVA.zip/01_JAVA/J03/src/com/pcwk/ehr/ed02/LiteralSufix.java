package com.pcwk.ehr.ed02;

public class LiteralSufix {

	public static void main(String []args) {
		//정수형
		//int age = 80L;//
		long age = 80L;// L/l 접미사 사용
		
		//실수형
		float pi = 3.14f;
		double rate = 1.414D;
		
	}
}
