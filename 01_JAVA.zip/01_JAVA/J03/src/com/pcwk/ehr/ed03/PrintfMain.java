package com.pcwk.ehr.ed03;

public class PrintfMain {

	public static void main(String[] args) {
		/*
		지사자	설명
		%b	불리언(boolean)형식으로 출력
		%d	10(decimal) 정수의 형식으로 출력
		%o	8(octal) 정수의 형식으로 출력
		%x, %X	16(hexa-decimal) 정수의 형식으로 출력
		%f	부동 소수점(floating-point) 형식으로 출력
		%e, %E	지수(exponent)표현식의 형식으로 출력
		%c	문자(character)로 출력
		%s	문자열(string)로 출력
		%n  = \n 라인스킵
		*/
		
		byte  b   = 1;
		short s   = 2;
		char  ch  = 'A';
	
		int   finger = 12;
		
		int octNum = 010;//8진수  10
		int hexNum = 0x10;//16진수 10
		int binNum = 0b10;//2진수 10 
		System.out.printf("b=%d\n",b);
		System.out.printf("s=%d%n",s);
		System.out.printf("ch=%c, %d\n",ch,(int)ch);
		System.out.printf("--------------------------------\n");
		//자리수 표현
		System.out.printf("finger=[%5d]%n",finger);//공간 5개 확보,오른쪽 정렬
		System.out.printf("finger=[%-5d]%n",finger);//공간 5개 확보,왼쪽 정렬
		System.out.printf("finger=[%05d]%n",finger);//공간 5개 확보,오른쪽 정렬, 빈자리는 0으로 채우세요
		System.out.printf("--------------------------------\n");
		
		//진수출력
		System.out.printf("octNum=%o, %d%n",octNum ,octNum);//8진수 출력
		System.out.printf("hexNum=%x, %d%n",hexNum ,hexNum);
		System.out.printf("hexNum=%#x, %d%n",hexNum ,hexNum);//0x
		System.out.printf("binNum=%s, %d%n",Integer.toBinaryString(binNum),binNum);
		
		
	}

}







