package com.pcwk.ehr.ed04;

import java.util.Scanner;

public class ScannerMain {

	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		System.out.print("두 자리 정수를 입력하세요.>");
		String input = scanner.nextLine();
		
		int num = Integer.parseInt(input);
		System.out.printf("input = %s\n",input);
		System.out.printf("num=%d\n",num);
	}

}
