package com.pcwk.ehr.ed06;

public class Character01 {

	public static void main(String[] args) {
		char ch = 'A';//문자 'A'를 char 타입 변수 ch에 저장
		//char ch = 65;//문자 'A'를 char 타입 변수 ch에 저장
		int code = (int)ch;//ch에 저장된 값을 int 타입으로 변환저장
		
		System.out.printf("ch=%c, code=%d %n",ch,code);

		char hch = '가';
		System.out.printf("hch=%c,  %#X\n",hch,(int)hch);
		
		char nhch = '\uAC00';
		System.out.printf("nhch=%c",nhch);
	}
}
