package com.pcwk.ehr.ed06;

public class E02_SpecialChar {

	public static void main(String[] args) {
//		특수문자	문자 리터럴(값)
//		tab	\t
//		backspace	\b
//		new line	\n
//		form feed	\f
//		carriage return	\r
//		역슬러쉬(\)	\\
//		작은따옴표	\’
//		큰따옴표	\”
//		유니코드(16진)문자	\\u 유니코드

		System.out.println('\'');
		System.out.println("abc\t123");
		System.out.println('\n');
		System.out.println("\"Hello\"");//"Hello"
		
		//C:\JSPM_0907
		System.out.println("C:\\JSPM_0907");
		
		
		
	}

}
