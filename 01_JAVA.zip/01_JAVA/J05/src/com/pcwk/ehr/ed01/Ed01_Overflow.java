package com.pcwk.ehr.ed01;

public class Ed01_Overflow {

	public static void main(String[] args) {
		byte over = 127;//-128 ~ 127
		
		System.out.printf("over=%d%n",over);
		over++;//over=over+1
		
		//표현 범위를 넘어 쓰레기 값이 나왔다.
		System.out.printf("over=%d%n",over);//over=-128 

	}

}
