package com.pcwk.ehr.ed03;

public class Ed03_Casting {

	public static void main(String []args) {
		//묵시적 형변환(자동 형변환)
		byte bNum = 12;
		int  iNum = 14;
		int result = bNum + iNum;//int + int
		
		System.out.printf("%d+%d=%d%n",bNum,iNum,result);
		
		//정수와 실수간 연산
		int iNum02 = 17;
		float fNum = 22.0f;
		
		double dResult =  iNum02 + fNum;//float + float
		System.out.printf("dResult=%f",dResult);
		
	}//--main
	
}//--class
