package com.pcwk.ehr.ed04;

public class Ed05_Operator {

	public static void main(String[] args) {
		int x = 10; // '=' 대입연산자
		int y = 3;
		
		System.out.printf("x=%d, y=%d%n",x,y);
		System.out.printf("x+y=%d%n",(x+y));
		System.out.printf("x-y=%d%n",(x-y));
		System.out.printf("x*y=%d%n",(x*y));
		
		System.out.printf("x/y="+(x/y));// int/int = int(3)
		System.out.println("x/y="+(x/(y*1.0)));//3.333333333333333
		System.out.println("x%y="+(x%y));
	}

}
