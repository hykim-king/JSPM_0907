package com.pcwk.ehr.ed05;

public class Ed07_IncreaseOperator {

	public static void main(String[] args) {
		int i = 12;
		int j = 0;
		
		j = i++;//후위 연산자 : 할당하고 증가
		System.out.printf("i++=%d, j=%d%n",i,j);

		//초기화
		i = 12;
		j = 0;
		
		j = ++i;//전위 연산자: 증가 시키고 j에 할당
		System.out.printf("i++=%d, j=%d%n",i,j);
	}

}
