package com.pcwk.ehr.ed06;

public class Ed08_SignOperator {

	public static void main(String[] args) {
		int x = -12;
		x = +x;
		
		System.out.println("x="+x);
		
		x = -12;
		x = -x;
		
		System.out.println("x="+x);

	}

}
//x=-12
//x=12