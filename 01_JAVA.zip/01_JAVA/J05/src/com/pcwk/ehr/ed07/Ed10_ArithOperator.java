package com.pcwk.ehr.ed07;

public class Ed10_ArithOperator {

	public static void main(String[] args) {
		byte a = 12;
		byte b = 14;
		// byte + byte -> (byte)(int + int)
		byte c = (byte)(a+b);
		
		System.out.printf("c=%d%n",c);
		
	}

}
//c=26