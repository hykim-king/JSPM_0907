package com.pcwk.ehr.ed07;

public class Ed12_ArithOperator {

	public static void main(String[] args) {
		//char + int -> int + int -> int
		
		char ch = 'A';//A의 ascii코드 65
		int  i  = 1;
		int result = ch + 1;
		
		System.out.println("result="+result);
		
		char chResult = (char)(ch + 32);
		
		System.out.println("chResult="+chResult);
	}

}
//result=66
//chResult=a