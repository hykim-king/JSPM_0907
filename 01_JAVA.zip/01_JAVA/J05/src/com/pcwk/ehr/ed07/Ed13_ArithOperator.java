package com.pcwk.ehr.ed07;

public class Ed13_ArithOperator {

	public static void main(String[] args) {
		int x = 1_000_000;
		int result01 = x * x / x;//1_000_000*1_000_000/1_000_000 => 오버플로우
		int result02 = x / x * x;//1_000_000/1_000_000*1_000_000 => 1000000 
		
		System.out.println("result01="+result01);
		System.out.println("result02="+result02);
	}

}
//result01=-727    쓰레기 값
//result02=1000000
