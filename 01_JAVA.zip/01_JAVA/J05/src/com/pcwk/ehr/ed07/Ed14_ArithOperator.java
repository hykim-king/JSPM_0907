package com.pcwk.ehr.ed07;

public class Ed14_ArithOperator {

	public static void main(String[] args) {
		char c = '0';//48
		
		for(int i=0;i<10;i++) {//0<=i<=10
			System.out.print(c++);
		}
		System.out.println();
		
		c = 'A';
		for(int i=0;i<26;i++) {
			System.out.print(c++);
		}
		System.out.println();
		
		c = 'a';
		for(int i=0;i<26;i++) {
			System.out.print(c++);
		}		
	}

}
