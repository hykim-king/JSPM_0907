package com.pcwk.ehr.ed07;

public class Ed15_ArithOperator {

	public static void main(String[] args) {
		//소수 세째자리에서 버림!
		//3.141
		float pi = 3.141592f;
		
		float shortPI=(int)(pi*1000)/1000f;
		
		System.out.println("shortPI="+shortPI);

	}

}
//shortPI=3.141