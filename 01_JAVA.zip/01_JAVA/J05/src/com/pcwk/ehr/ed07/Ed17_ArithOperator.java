package com.pcwk.ehr.ed07;

public class Ed17_ArithOperator {

	public static void main(String[] args) {
		float pi = 3.141592f;
		
		float shortPI = Math.round(pi*1000)/1000f;
		System.out.println("shortPI="+shortPI);

	}

}
//shortPI=3.142