package com.pcwk.ehr.ed01;

public class Ed01_Operater {

	public static void main(String[] args) {
		float fValue = 0.1f;
		
		double dValue = 0.1;//default 실수는 double
		System.out.println(10.0 == 10.0f);//true
		//정수형과 달리 실수형은 2진수 근사값으로 저장되므로 오차가 발생한다.
		System.out.printf("0.1 == 0.1f \t %b%n", (fValue == dValue) );
		
		System.out.printf("fValue=%19.17f%n",fValue);
		System.out.printf("dValue=%19.17f%n",dValue);
		
	}

}
//true
//0.1 == 0.1f 	 false
//fValue=0.10000000149011612
//dValue=0.10000000000000000