package com.pcwk.ehr.ed01;

public class Ed02_StringOperator {

	public static void main(String[] args) {
		String str01 = "abc";//문자열 1
		String str02 = new String("abc");//문자열 2
		
		System.out.println("str01="+str01);
		System.out.println("str02="+str02);
		
		System.out.println("========================");
		
		System.out.println("abc" == "abc");//true
		System.out.println(str01 == "abc");//true
		System.out.println(str02 == "abc");//false
		
		System.out.println("-------------------------");
		
		System.out.println(str01.equals("abc"));//true
		System.out.println(str02.equals("abc"));//true
		
		

	}

}
