package com.pcwk.ehr.ed01;

public class Ed03_Operator {

	public static void main(String[] args) {
		int x = 0;
		char ch =' ';//문자 초기화 
		
		//x는 10보다 크고 20보다 작다
		x = 12;
		System.out.printf("x=%2d \t (10<x && x <20)=%b%n",x,(10<x && x <20) );
				
		x = 9;
		//x는 2의배수 또는 3의 배수
		System.out.printf("x=%-3d, \t (x %% 2 ==0 || x %% 3==0) = %b%n",x, (x % 2 ==0 || x % 3==0));

		
		//문자 ch는 숫자('0'~'9')
		//'0'<=ch && ch <='9'
		
		ch = '2';
		System.out.printf("ch=%c, \t '0' <= ch && ch <='9' =%b%n",ch, ('0' <= ch && ch <='9')  );
		
	}

}
//x=12 	 (10<x && x <20)=true
//x=9  , (x % 2 ==0 || x % 3==0) = true
//ch=2,  '0' <= ch && ch <='9' =true
