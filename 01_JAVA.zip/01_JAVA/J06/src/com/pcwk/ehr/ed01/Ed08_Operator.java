package com.pcwk.ehr.ed01;

public class Ed08_Operator {

	public static void main(String arg[]) {
		
		//나이에 따라 미성년 여부 판단.
		int age = 17;
		String message = (age>=18) ? "성인":"미성년";
		System.out.printf("나이=%d, 성인여부:%s%n",age,message);
		
		
	}
}
//나이=17, 성인여부:미성년