package com.pcwk.ehr.ed02;

import java.util.Scanner;

public class Ed11_if_elseif_else {

	public static void main(String[] args) {
		//1.성적을 입력 받아, 
		//2.학점을 출력
		
		int score = 0;  //성적
		char grade =' ';//학점
		
		Scanner scanner=new Scanner(System.in);
		System.out.print("성적을 입력 하세요.>");
		score = scanner.nextInt();
		System.out.printf("score=%d%n",score);
		
		if(score >=90) {
			grade = 'A';
		}else if(score >=80) {// 80<=score && score <90 : 위 에서 아래로 조건 비교하면 내려 온다. 'score >=80'
			grade = 'B';
		}else if(score >=70) {
			grade = 'C';
		}else if(score >=60) {
			grade = 'D';
		}else {
			grade = 'F';
		}
		
		System.out.printf("score=%d, grade=%c%n",score,grade);
		
	}

}
//성적을 입력 하세요.>90
//score=90
//score=90, grade=A






