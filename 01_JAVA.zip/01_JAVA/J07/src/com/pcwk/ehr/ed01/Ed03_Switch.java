package com.pcwk.ehr.ed01;

import java.util.Scanner;

public class Ed03_Switch {

	public static void main(String[] args) {
//		월을 받아 그달의 일수 구하기.
//		31 : 1,3,5,7,8,10,12
//		28 : 2
//		30 : 4,6,9,11

		int month = 0;//월
		int days  = 0;//일수
		
		Scanner scanner=new Scanner(System.in);
		System.out.print("월을 입력 하세요.(1~12월)>");
		month = scanner.nextInt();
		
		System.out.printf("month=%d%n",month);
		
		switch(month) {
		case 4:case 6:case 9:case 11:
			days = 30;
			break;
		case 2:
			days = 28;
			break;
		default:
			days = 31;
			break;
		}
		
		System.out.printf("days=%d\n",days);
	}

}
