package com.pcwk.ehr.ed01;

import java.util.Scanner;

public class Ed04_01Switch {

	public static void main(String[] args) {
		//computer 난수 처리: 1 ~ 3

//		Math.random();  //0.0<=x<1.0
//		Math.random()*3;//0.0<=x<3.0
//		(int)Math.random()*3;//0<=x<3
//		( (int)Math.random()*3 ) +1 ;//1<=x<4
		int user = 0;//사용자
		int com = (int)(Math.random()*3)+1;
		String message = "";
		
		Scanner scanner=new Scanner(System.in);
		System.out.print("가위(1),바위(2),보(3)을 입력하세요.>");
		
		//-------------------------------------------------
		// 가위, 바위, 보 : 1,2,3으로 메핑
		//-------------------------------------------------
		String userAction = scanner.nextLine();
		if(userAction.equals("가위")) {
			user = 1;
		}else if(userAction.equals("바위")) {
			user = 2;
		}else if(userAction.equals("보")) {
			user = 3;
		}else {
			System.out.print("가위(1),바위(2),보(3)을 입력하세요.");
			return;
		}
		
		//user = scanner.nextInt();
		
		System.out.printf("com=%d\n",com);
		
		switch(user - com) {
		case 1: case -2:
			message = "user승";
			break;
		case -1: case 2:
			message ="computer승";
			break;
		default:
			message ="무승부";
			break;
		}
		
		System.out.printf("user=%d\n",user);
		System.out.printf("%s",message);
		
	}

}
//가위(1),바위(2),보(3)을 입력하세요.>1
//com=3
//user=1
//user승