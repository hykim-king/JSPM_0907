package com.pcwk.ehr.ed02;

public class Ed07_For {

	public static void main(String[] args) {
		System.out.println("오늘은 즐거운 목요일!");
		System.out.println("오늘은 즐거운 목요일!");
		System.out.println("오늘은 즐거운 목요일!");
		System.out.println("오늘은 즐거운 목요일!");
		System.out.println("오늘은 즐거운 목요일!");
		System.out.println("오늘은 즐거운 목요일!");
		System.out.println("오늘은 즐거운 목요일!");

		System.out.println("=========================");
		for(int i=1;i<=7;i++){
			System.out.println("오늘은 즐거운 목요일!");
		}

	}

}
