package com.pcwk.ehr.ed02;

public class Ed09_For {

	public static void main(String[] args) {
		
		//5부터 1까지 감소
		for(int i=5;i >=1;i--) {
			System.out.printf("현재 i값 =%d\n",i);
		}

	}

}
//현재 i값 =5
//현재 i값 =4
//현재 i값 =3
//현재 i값 =2
//현재 i값 =1