package com.pcwk.ehr.ed02;

public class Ed10_ForLoop {

	public static void main(String[] args) {
//		1		10
//		2		9
//		3		8
//		4		7
//		5		6
//		6		5
//		7		4
//		8		3
//		9		2
//		10		1
		
		for(int i=1,j=10;i<=10;i++,j--) {
			System.out.printf("%2d \t %2d\n",i,j);
		}
	}

}
