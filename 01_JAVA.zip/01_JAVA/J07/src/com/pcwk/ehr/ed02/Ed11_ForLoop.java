package com.pcwk.ehr.ed02;

public class Ed11_ForLoop {

	public static void main(String[] args) {
		
		//1-10까지 홀수의 합 구하기.
		int sum = 0;
		for(int i=1;i<=10;i++) {
			
			if(i%2 != 0) {
				sum +=i;//sum=sum+i
				System.out.println(i);
			}
		}
		
		System.out.printf("sum=%d\n",sum);
		
		//---------------------------------------------
		
		sum = 0;
		for( int i=1;i<=10;i+=2) {
			sum+=i;
			System.out.println(i);
		}
		System.out.printf("sum=%d\n",sum);
		
	}

}
//1
//3
//5
//7
//9
//sum=25
//1
//3
//5
//7
//9
//sum=25
