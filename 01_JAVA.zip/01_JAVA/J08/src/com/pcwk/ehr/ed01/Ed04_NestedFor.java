package com.pcwk.ehr.ed01;

public class Ed04_NestedFor {

	public static void main(String[] args) {
		// 2~9단
		for (int i = 2; i <= 9; i++) {
			System.out.printf("%2d단\n", i);

			// 1~9
			for (int j = 1; j <= 9; j++) {
				System.out.printf("%d X %d = %2d\n", i, j, (i * j));
			}
		}

	}

}
