package com.pcwk.ehr.ed02;

public class Ed05_EnhancedFor {

	public static void main(String[] args) {
		int []ageArray = {12,14,17,51,47,88};
		
		//향상된 for
		for(int age :ageArray) {
			System.out.printf("age=%d\n",age);
		}
		System.out.println("-------------------------------------------------");
		//기존 for
		for(int i=0;i<ageArray.length;i++) {
			System.out.println("age="+ageArray[i]);
		}
		

	}

}
//age=12
//age=14
//age=17
//age=51
//age=47
//age=88
//-------------------------------------------------
//age=12
//age=14
//age=17
//age=51
//age=47
//age=88