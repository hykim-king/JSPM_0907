package com.pcwk.ehr.ed03;

public class Ed06_While {

	public static void main(String[] args) {
		
		int totalSum = 0;//합계
		int i = 1;//증가변수
		
		while(i<=100) {
			totalSum += i;
			System.out.println(totalSum+","+i);
			i++;
		}//--while 끝
		
		System.out.println("totalSum:"+totalSum);

	}

}
