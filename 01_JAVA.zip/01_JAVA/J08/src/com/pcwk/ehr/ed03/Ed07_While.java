package com.pcwk.ehr.ed03;

public class Ed07_While {

	public static void main(String[] args) {

		for(;;) {
			  
		}

	}

}
