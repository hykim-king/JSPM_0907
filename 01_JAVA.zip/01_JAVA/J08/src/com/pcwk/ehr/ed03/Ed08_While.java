package com.pcwk.ehr.ed03;

public class Ed08_While {

	public static void main(String[] args) {
		//1 ~ 20까지 정수 중 2또는 3의 배수가 아닌 수의 총합을 구하시오.

		int totalSum = 0;//총합
		int i        = 1;//증가
		
		while(i<=20) {
			
			if( !(i%2==0 || i%3==0)){
				//System.out.printf("i=%2d\n",i);
				System.out.println("i="+i);
				totalSum = totalSum +i;
				//totalSum +=i;
			}
			
			i++;
		}
		
		System.out.println("1 ~ 20까지 정수 중 2또는 3의 배수가 아닌 수의 총합="+totalSum);
		
		
	}

}
