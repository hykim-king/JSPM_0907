package com.pcwk.ehr.ed03;

public class Ed09_WhileToFor {

	public static void main(String[] args) {
		//1 ~ 20까지 정수 중 2또는 3의 배수가 아닌 수의 총합을 구하시오.

		int totalSum = 0;//총합
		int i        = 1;//증가
		
		for(i=1;i<=20;i++) {
			if( !(i%2==0 || i%3==0)) {
				System.out.printf("%d\n",i);
				totalSum +=i;
			}//--if
		}//--for
		

		
		System.out.println("1 ~ 20까지 정수 중 2또는 3의 배수가 아닌 수의 총합="+totalSum);
		
		
	}

}
