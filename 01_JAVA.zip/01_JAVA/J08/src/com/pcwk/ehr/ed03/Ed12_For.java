package com.pcwk.ehr.ed03;

public class Ed12_For {

	public static void main(String[] args) {
		//1 + (-2) + 3 +(-4) + … 몇까지 더해야 총합이 100이상이 될까요?
			//1. 양수, 음수,양수,음수,…
			//2. 누적해 100이상
		
		int sum = 0;//합계
		
		for(int i=1,j=1;;i++,j=j*-1) {
			int k = (i*j);	
			System.out.printf("k=%4d, j=%2d\n",k,j);
			sum +=k;
			if(sum>100) {
				System.out.printf("i=%d, sum=%d",i, sum);
				break;//반복문 1개를 벋어 난다.
			}
		}

	}

}
//i=201, sum=101