package com.pcwk.ehr.ed03;

import java.util.Scanner;

public class Ed13_DoWhile {

	public static void main(String[] args) {
//		1~100사이에 임의의 난수 발생, 이 수를 맞추기.
//		수자를 입력하면 크다, 작다,정답
		
//      1~100사이 난수
		int answer = 0;	
		int input  = 0;//사용자 입력 변수

		answer=(int)(Math.random()*100)+1;	//1<=x<101
		
//      사용자 숫자 입력		
		Scanner scanner=new Scanner(System.in);
		System.out.println("answer="+answer);
		do {
			System.out.print("1~100사이 정수를 입력 하세요.>");
			input = scanner.nextInt();

			if(input>answer) {
				System.out.println("더 작은 수를 입력 하세요.");
			}else if(input<answer)  {
				System.out.println("더 큰 수를 입력 하세요.");
			}
			
		}while(input != answer );

		System.out.println("정답입니다. ");
	}

}


