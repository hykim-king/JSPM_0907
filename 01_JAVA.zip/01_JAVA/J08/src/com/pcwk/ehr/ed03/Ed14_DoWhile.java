package com.pcwk.ehr.ed03;

import java.util.Random;

public class Ed14_DoWhile {

	public static void main(String[] args) {
		Random random=new Random();
		System.out.println("중복 제거된 난수(로또번호) 생성기");
		
		int count = 0;
		int []save=new int[6];//중복 제거 데이터 저장!
		do {
			//중복 발생: 각 데이터를 저장한다.
			//저장된 데이터에 중복이 있는지 확인 한다.
			//중복이 없으면 저장한다.
			int randomNumber = random.nextInt(45)+1;
			
			int isSave = 0;//중복체크
			
			//중복체크------------------------------
			for(int i=0;i<save.length;i++) {
				if(save[i]==randomNumber) {
					isSave = 1;
					break;
				}
			}
			//--중복체크------------------------------
			
			if(isSave == 0) {//중복 없음
				save[count++]=randomNumber;
				System.out.print(randomNumber+" ");
			}

			
			//System.out.println("count="+count);
		}while(count < 6);
       
		System.out.println("\n중복 제거된 난수(로또번호) 생성기 종료!");	
	}
}
//중복 제거된 난수(로또번호) 생성기
//11 20 21 29 30 44 
//중복 제거된 난수(로또번호) 생성기 종료!
