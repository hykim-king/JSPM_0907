package com.pcwk.ehr.ed01;

public class Ed01_Ex01 {

	public static void main(String[] args) {
//		1+(1+2)+(1+2+3)+(1+2+3+4)+...+(1+2+3+...+10)의 결과를 계산하시오.
//
//		totalSum=220
		int totalSum = 0;//누적 합
		for(int i=1;i<=10;i++) {
			int subTotal = 0;
			for(int j=1;j<=i;j++) {
				
				subTotal +=j;
				System.out.printf("%d",j);
			}
			System.out.printf("\t\t\t %3d",subTotal);
			totalSum +=subTotal;
			
			System.out.println();
		}
		System.out.println("totalSum="+totalSum);

	}

}
