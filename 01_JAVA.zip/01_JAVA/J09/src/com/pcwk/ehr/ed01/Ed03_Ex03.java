package com.pcwk.ehr.ed01;

import java.util.Scanner;

public class Ed03_Ex03 {

	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int year  = 0; //년도
		int month = 0; //월
		int days  = 0 ;//일수
		
		System.out.print("년도를 입력 하세요.>");
		year = scanner.nextInt();
		
		System.out.print("월을 입력 하세요.>");
		month = scanner.nextInt();
		
		switch(month) {
		case 4: case 6: case 9: case 12:
			days = 30;
			break;
		case 2:
			//윤달은 년도가 4의 배수이고 그리고 년도가 100으로 나누어 떨어 지진 않고, 그리고 400의 배수이면 윤달이다.
			if(  (year % 4 ==0) && (year % 100 !=0) || (year % 400 ==0)){
			      days  = 29;
			}else {
				  days  = 28;
			}
			break;
			
		default :
			days = 31;
			break;
		}
		
		System.out.printf("year=%4d, month=%2d, days=%2d",year, month, days);
	}

}
//년도를 입력 하세요.>2024
//월을 입력 하세요.>2
//year=2024, month= 2, days=29

//년도를 입력 하세요.>2020
//월을 입력 하세요.>2
//year=2020, month= 2, days=29