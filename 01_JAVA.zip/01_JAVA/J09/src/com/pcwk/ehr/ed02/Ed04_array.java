package com.pcwk.ehr.ed02;

public class Ed04_array {

	public static void main(String[] args) {
		int []studentScore;//배열 선언
		
		studentScore = new int[5];//배열 생성
		
		System.out.println(studentScore[0]);//int에 default인 0으로 초기화
		
		int i =1;
		
		//배열 요소에 값 할당
		studentScore[0] = 77;
		studentScore[1] = 88;
		studentScore[i+1] = 89;//studentScore[2]
		studentScore[i+2] = 92;//studentScore[3]
		studentScore[4] = 95;
		
		//배열에 할당된 요소값 출력
		int tmpScore = studentScore[0];
		System.out.printf("tmpScore=%d\n",tmpScore);
		
		//배열요소 인덱스[1]+인덱스[2]
		tmpScore=studentScore[1] + studentScore[2];
		System.out.printf("studentScore[1] + studentScore[2]=%d\n",tmpScore);
		
		//배열이름.length : 배열의 길이
		System.out.printf("배열이름.length=%d\n",studentScore.length);
		
		//배열의 전체 데이터 접근
		for(i=0;i<studentScore.length;i++) {
			System.out.printf("i=%d, studentScore[%d]=%d\n",i,i,studentScore[i]);
		}

		
	}

}

//0
//tmpScore=77
//studentScore[1] + studentScore[2]=177
//배열이름.length=5
//i=0, studentScore[0]=77
//i=1, studentScore[1]=88
//i=2, studentScore[2]=89
//i=3, studentScore[3]=92
//i=4, studentScore[4]=95

