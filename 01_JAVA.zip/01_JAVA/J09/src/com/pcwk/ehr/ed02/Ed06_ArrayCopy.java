package com.pcwk.ehr.ed02;

public class Ed06_ArrayCopy {

	public static void main(String[] args) {
		//배열은 생성하고 크기가 정해지면, 그 크기 변경불가.
		//-> 또다른 배열을 생성, 원하는 만큼 크기의 배열 생성
		//-> 데이터를 새로운 배열에 1개씩 copy
		//-> 기존 배열과 새로운 배열의 주소 변경.
		int []iArray = {77,88,79,95,99};
		int []iArrayCopy = new int[iArray.length*2];
		
		
		for(int i=0;i<iArray.length;i++) {
			iArrayCopy[i] = iArray[i];
		}
		
		
		//데이터 확인
		for(int i=0;i<iArray.length;i++) {
			System.out.printf("iArray[%d]=%d\n",i,iArray[i]);
		}
		
		System.out.println("-------------------------------------------------");
		//데이터 copy확인
		for(int i=0;i<iArrayCopy.length;i++) {
			System.out.printf("iArrayCopy[%d]=%d\n",i,iArrayCopy[i]);
		}		
		
		System.out.println("=================================================");
		//원본(iArray) copy(iArrayCopy) 주소 변경
		iArray = iArrayCopy;
		//데이터 확인
		for(int i=0;i<iArray.length;i++) {
			System.out.printf("iArray[%d]=%d\n",i,iArray[i]);
		}		
		

	}

}

//iArray[0]=77
//iArray[1]=88
//iArray[2]=79
//iArray[3]=95
//iArray[4]=99
//-------------------------------------------------
//iArrayCopy[0]=77
//iArrayCopy[1]=88
//iArrayCopy[2]=79
//iArrayCopy[3]=95
//iArrayCopy[4]=99
//iArrayCopy[5]=0
//iArrayCopy[6]=0
//iArrayCopy[7]=0
//iArrayCopy[8]=0
//iArrayCopy[9]=0
//=================================================
//iArray[0]=77
//iArray[1]=88
//iArray[2]=79
//iArray[3]=95
//iArray[4]=99
//iArray[5]=0
//iArray[6]=0
//iArray[7]=0
//iArray[8]=0
//iArray[9]=0
