package com.pcwk.ehr.ed02;

import java.util.Arrays;

public class Ed07_ArrayCopy {

	public static void main(String[] args) {
		int []srcArray= {1,2,3,4,5};
		int []targetArray = {0,0,0,0,0,0};
		
		//srcArray to copy targetArray
		for(int i=0;i<srcArray.length;i++) {
			System.out.printf("srcArray[%d]=%d\n",i,srcArray[i]);
		}
		
		//Arrays.toString(): 배열에 들어 있는 모든 요소 출력
		System.out.println("Copy전 데이터");
		System.out.println(Arrays.toString(srcArray));
		System.out.println(Arrays.toString(targetArray));
		System.out.println("==================================================");
		//배열copy
		System.arraycopy(srcArray, 0, targetArray, 0, srcArray.length);
		
		System.out.println("Copy이후 데이터");
		System.out.println(Arrays.toString(srcArray));
		System.out.println(Arrays.toString(targetArray));
		
		System.out.println("==================================================");
		//targetArray 0으로 배열  초기화
		for(int i=0;i<targetArray.length;i++) {
			targetArray[i] = 0;
		}
		System.out.println(Arrays.toString(targetArray));
		
		//배열copy활용: srcArray[2]부터 , targetArray[2]로 , srcArray[2]q부터 3개 copy
		System.arraycopy(srcArray, 2, targetArray, 2, 3);//
		System.out.println(Arrays.toString(targetArray));
	}

}
//srcArray[0]=1
//srcArray[1]=2
//srcArray[2]=3
//srcArray[3]=4
//srcArray[4]=5
//Copy전 데이터
//[1, 2, 3, 4, 5]
//[0, 0, 0, 0, 0, 0]
//==================================================
//Copy이후 데이터
//[1, 2, 3, 4, 5]
//[1, 2, 3, 4, 5, 0]
//==================================================
//[0, 0, 0, 0, 0, 0]
//[0, 0, 3, 4, 5, 0]
