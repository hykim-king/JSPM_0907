package com.pcwk.ehr.ed02;

public class Ed09_Ex02 {

	public static void main(String[] args) {
		//배열의 요소 중에서 제일 큰 값과 제일 작은 값을 찾는다.
		int []score = { 79,88,55,100,77,66,87};
		
		int max = 0;//최대값
		int min = 0;//최소값
		int i   = 0;//증감
		
		max = score[0];
		min = score[0];
		
		System.out.println("max="+max);
		
		for(i=1;i<score.length;i++) {
			if(max < score[i]) {
				max = score[i];
			}
			
			if(min>score[i]) {
				min = score[i];
			}
			
		}
		
		System.out.printf("max = %d\n",max);
		System.out.printf("min = %d\n",min);

	}

}
//max=79
//max = 100
//min = 55