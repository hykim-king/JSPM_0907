package com.pcwk.ehr.ed02;

import java.util.Arrays;

public class Ed10_Ex03 {

	public static void main(String[] args) {
		int []num=new int[10];
		
		for(int i=0;i<num.length;i++){
		     num[i] = i;
		}
		
		//[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
		System.out.println("shuffle 전");
		System.out.println(""+Arrays.toString(num));
		System.out.println("======================");
		for(int i=0;i<50;i++) {
			int n=(int)(Math.random()*10);//0.0<=x<1.0
			//System.out.println("n="+n);
			int temp = num[0];//배열요소 0
			num[0]   = num[n];
			num[n]   = temp;
		}
		
		System.out.println("shuffle 후");
		for(int i=0;i<num.length;i++) {
			System.out.printf("num[%d]=%d\n",i,num[i]);
		}
		
	}

}
//shuffle 전
//[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
//======================
//shuffle 후
//num[0]=2
//num[1]=6
//num[2]=3
//num[3]=8
//num[4]=0
//num[5]=7
//num[6]=1
//num[7]=5
//num[8]=4
//num[9]=9
