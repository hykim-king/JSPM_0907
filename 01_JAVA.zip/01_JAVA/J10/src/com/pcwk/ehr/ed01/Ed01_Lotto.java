package com.pcwk.ehr.ed01;

import java.util.Arrays;

public class Ed01_Lotto {

	public static void main(String[] args) {
//		1. 1~45 배열을 생성한다.
//		2. shuffle 20회
//		3. 6개의 데이터를 추출 한다.

		int []ball=new int[45];
		
		//1,2,3...45
		for(int i=0;i<ball.length;i++) {
			ball[i] = i+1;//1~45
		}
		
		System.out.println("초기화:"+Arrays.toString(ball));
		
		//shuffle
		
		int numCount = 100;
		for(int i=0;i<numCount;i++) {
			//1~45 임이에 난수 발생
			int n =(int)(Math.random()*45);//0<=x<45
			//System.out.println("n="+n);
			
			//주스(ball[0]), 우유(ball[n]), 빈컵(temp)
			int temp = ball[0];
			ball[0]  = ball[n];
			ball[n]  = temp;			
		}
		//System.out.println("shuffle이후:"+Arrays.toString(ball));
		//데이터 6개 추출
		for(int i=0;i<6;i++) {
			System.out.printf("ball[%d]=%2d\n",i,ball[i]);
		}
	}

}

//초기화:[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45]
//ball[0]=26
//ball[1]= 8
//ball[2]=31
//ball[3]=14
//ball[4]=23
//ball[5]= 6






