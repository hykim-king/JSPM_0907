package com.pcwk.ehr.ed01;

import java.util.Arrays;

public class Ed02_BubbleSort {

	public static void main(String[] args) {
		// 버블소트 : 이 알고리즘은 인접한 두 원소를 비교하고 필요한 경우 위치를 교환하여 배열을 정렬
		int []numArray = {7,4,5,1,3};
		System.out.println("Sort전");
		for(int i=0;i<numArray.length;i++) {
			System.out.printf(numArray[i]+",");
		}
		System.out.println("--------------------------------------------------");
		
		//ASC SORT
		for(int i=0;i<numArray.length-1;i++) {
			
			for(int j=0;j<numArray.length-i-1;j++) {
				//앞 데이터가 비교 데이터 보다 크면 자리 교환:ASC -> >
				//앞 데이터가 비교 데이터 보다 작으면 자리 교환:DESC -> <
				if(numArray[j]>numArray[j+1]) {
					int temp = numArray[j];
					numArray[j] = numArray[j+1];
					numArray[j+1] = temp;
				}//--if
				
			}//--for j
			System.out.println(Arrays.toString(numArray));
			
			
		}//--for i

		System.out.println("Sort전후");
		for(int i=0;i<numArray.length;i++) {
			System.out.printf(numArray[i]+",");
		}		
	}

}
//Sort전
//7,4,5,1,3,--------------------------------------------------
//[4, 5, 1, 3, 7]
//[4, 1, 3, 5, 7]
//[1, 3, 4, 5, 7]
//[1, 3, 4, 5, 7]
//Sort전후
//1,3,4,5,7,