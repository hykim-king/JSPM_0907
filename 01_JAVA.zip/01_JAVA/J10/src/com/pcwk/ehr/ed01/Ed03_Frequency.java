package com.pcwk.ehr.ed01;

import java.util.Arrays;

public class Ed03_Frequency {

	public static void main(String[] args) {
		//배열(array)에서 데이터의 빈도수 구하기. 
		int []numArray = {4,4,4,7,2,8,2,9,3,8};
		
		//비도수 저장 배열 생성
		int []counter = new int[10];//{0,0,0,0,0,0,0,0,0,0}
		
		for(int i=0;i<numArray.length;i++) {
			counter[numArray[i]]++;
			//System.out.println(Arrays.toString(counter));
		}
		System.out.println(Arrays.toString(counter));
	}

}
//[0, 0, 2, 1, 3, 0, 0, 1, 2, 1]