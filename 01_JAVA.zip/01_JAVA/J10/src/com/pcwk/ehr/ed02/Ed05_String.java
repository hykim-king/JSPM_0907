package com.pcwk.ehr.ed02;

public class Ed05_String {

	public static void main(String[] args) {
		//16진수를 2진수로 변환.
		
		char[] hex = {'C','A','F','E','2'};//16진수

		String[] binary = {  "0000"	
							,"0001"	
							,"0010"	
							,"0011"	
							,"0100"	
							,"0101"	
							,"0110"	
							,"0111"	
							,"1000"	
							,"1001"	
							,"1010"	
							,"1011"	
							,"1100"	
							,"1101"	
							,"1110"	
							,"1111"	};
		
		String result = "";//결과 저장
		System.out.println("binary:"+binary.length);
		for(int i=0;i<hex.length;i++) {
			//영문 대문자 16진수 to 이진수
			if(hex[i]>=65 && hex[i]<=91) {
				result+=binary[hex[i] -'A' + 10]+",";
				//System.out.println(result);
				
			//숫자 16진수 to 이진수	
			}else {
				result +=binary[hex[i] -'0'];
			}	
		}
		
		System.out.println("hex:"+new String(hex));
		System.out.println("result:"+result);

		
	}//--main

}//--class
//hex:CAFE2
//result:1100,1010,1111,1110,0010