package com.pcwk.ehr.ed02;

public class Ed06_Morse {

	public static void main(String[] args) {
		String source = "ASOSHELP01";
		String []morse = {
				".-"
				,"-..."
				,"-.-."
				,"-.."
				,"."
				,"..-."
				,"--."
				,"...."
				,".."
				,".---"
				,"-.-"
				,".-.."
				,"--"
				,"-."
				,"---"
				,".--."
				,"--.-"
				,".-."
				,"..."
				,"-"
				,"..-"
				,"...-"
				,".--"
				,"-..-"
				,"-.--"
				,"--.."  //Z
				,"-----" //0
				,".----" //1
				,"..---" //2
				,"...--"
				,"....-"
				,"....."
				,"-...."
				,"--..."
				,"---.."
				,"----."
				
		};

		String result = "";//변환 결과용
		//"ASOSHELP01"
		for(int i=0;i<source.length();i++) {
			//모르스 부호 : A=0
			//source.charAt(i) -'A' : 알파벳 char - 'A' -> 모르스 부호 인덱스와 메핑
			//System.out.printf("%c \t index=%d\n", source.charAt(i),(source.charAt(i) -'A'));
			if(source.charAt(i)>='A' && source.charAt(i)<='Z') {
				result += morse[(source.charAt(i) -'A')];
			//숫자인 경우	
			}else if(source.charAt(i)>='0' && source.charAt(i)<='9') {
				result += morse[(source.charAt(i) -'0'+26)];
			}
		}
		
		
		System.out.println("source:"+source);
		System.out.println("모르스 부호:"+result);
		
	}

}
//source:ASOSHELP01
//모르스 부호:.-...---.........-...--.-----.----
