package com.pcwk.ehr.ed03;

public class Ed09_StringMethod {

	public static void main(String[] args) {
		String str = "ABCDE";
		
		char ch = str.charAt(3);
		//str.charAt(3)=D, 문자 하나 추출
		System.out.println("str.charAt(3)="+ch);

		String tmp = str.substring(1, 4);
		//str.substring(1, 4)=BCD, 문자열 추출
		System.out.println("str.substring(1, 4)="+tmp);
		
		//char[] <-> String
		char[] chArray = {'A','B','C','D','E'};
		
		//char[] -> String
		String str02 =new String(chArray);
		//str02:ABCDE
		System.out.println("str02:"+str02);
		
		//String -> char[] 
		char[] tmp02 = str02.toCharArray();
		for(int i=0;i<tmp02.length;i++) {
			System.out.printf("tmp02[%d]=%c\n",i,tmp02[i]);
		}
	}

}
//str.charAt(3)=D
//str.substring(1, 4)=BCD
//str02:ABCDE
//tmp02[0]=A
//tmp02[1]=B
//tmp02[2]=C
//tmp02[3]=D
//tmp02[4]=E