package com.pcwk.ehr.ed03;

public class Ed10_MultiArray {

	public static void main(String[] args) {
		int [][]score = { 
				{100,100,100}		
				,{20,20,20	}	
				,{30,30,30	}	
				,{40,40,40	}	
				,{50,50,50	}
			};
		//행 요소( 박 for): 5
		System.out.println("score.length="+score.length);
		//열 요소( 안 for):3
		System.out.println("score[0].length="+score[0].length);
		
		int sum = 0; //총합
		
		for(int i=0;i<score.length;i++) {
			for(int j=0;j<score[0].length;j++) {
				System.out.printf("score[%d][%d]=%3d\t",i,j,score[i][j]);
				sum += score[i][j];
			}//--for j
			System.out.println();
		}//--for i

		System.out.println("총점1="+sum);
		
		sum = 0 ;
		//향상된 for문
		for(int []tmp  :score) {
			for(int i :tmp) {
				sum +=i;
			}
		}
		System.out.println("총점2="+sum);

	}

}
//score.length=5
//score[0].length=3
//score[0][0]=100	score[0][1]=100	score[0][2]=100	
//score[1][0]= 20	score[1][1]= 20	score[1][2]= 20	
//score[2][0]= 30	score[2][1]= 30	score[2][2]= 30	
//score[3][0]= 40	score[3][1]= 40	score[3][2]= 40	
//score[4][0]= 50	score[4][1]= 50	score[4][2]= 50	
//총점1=720
//총점2=720





