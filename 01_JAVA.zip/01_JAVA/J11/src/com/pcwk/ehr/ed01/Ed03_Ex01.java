package com.pcwk.ehr.ed01;

import java.util.Scanner;

public class Ed03_Ex01 {

	public static void main(String[] args) {
		//0:바다, 1:배
		byte[][] shipBoard =	{  //1 2 3 4 5 6 7 8 9
									{0,0,0,0,0,0,1,0,0}, //1
									{0,0,0,0,0,0,1,0,0}, //2
									{1,1,1,1,0,0,1,0,0}, //3
									{0,0,0,0,0,0,1,0,0}, //4
									{0,0,0,1,0,0,0,0,1}, //5
									{0,0,0,0,0,0,0,0,0}, //6
									{1,1,0,0,1,0,0,0,0}, //7
									{0,0,0,0,0,0,1,0,0}, //8
									{0,0,0,0,0,0,0,0,0}  //9
								};
		final int SIZE = 10;
		int x = 0;//좌표 X
		int y = 0;//좌표 Y
//		int x=0, y=0;
		char [][]board=new char[SIZE][SIZE];
		
		for(int i=1;i<SIZE;i++) {
			board[0][i] = (char)(i+'0');//가로:1,2,3,4,5,6,7,8,9
			board[i][0] = (char)(i+'0');//세로:1,2,3,4,5,6,7,8,9
		}
		
		Scanner scanner=new Scanner(System.in);//좌표값 입력
		
		while(true) {
			System.out.printf("좌표를 입력 하세요.(종료는 00)>");
			String input = scanner.nextLine();//좌표 입력 22
			
			//22
			if(input.length() == 2) {
				x = input.charAt(0) - '0';//char 아스키 코드 50 - 48
				y = input.charAt(1) - '0';
				
				System.out.printf("x=%d,y=%d\n",x,y);
				//종료는 00
				if(x == 0 && y==0) {
					break;
				}
			}
			
			//223 : 입력을 다시 받는 case
			if(input.length() !=2 || x<=0 || x>=SIZE || y<=0 || y>=SIZE) {
				System.out.println("잘못된 입력 입니다.\n다시 입력해 주세요.");
				continue;
			}
			
			
			//배가 있는 곳을 찾는다.
			//1~9 좌표 x,y입력 : shipBoard는 배열 이므로 0번지 부터 시작한다.
			//따라서 1을 빼주어야 한다.
			board[x][y]=(shipBoard[x-1][y-1]==1)?'O':'X';
			
			//board배열의 내용 출력
			for(int i=0;i<SIZE;i++) {
				System.out.println(board[i]);//1차원 행열
			}//--board출력
			
		}//--while
		
		
		System.out.println("==========================");
		System.out.println("==프로그램 종료!==");
		System.out.println("==========================");

	}//--main

}//--class



