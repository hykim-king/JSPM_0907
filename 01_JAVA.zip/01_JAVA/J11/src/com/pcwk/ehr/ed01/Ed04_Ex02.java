package com.pcwk.ehr.ed01;

import java.util.Scanner;

public class Ed04_Ex02 {

	public static void main(String[] args) {
		//빙고
		final int SIZE = 5; //빙고판 크기
		int x =0; 
		int y =0;
		
		int num = 0;
		
		int[][] bingo=new int[SIZE][SIZE];
		Scanner scanner=new Scanner(System.in);
		
		//1~25까지 할당
		for(int i=0;i<SIZE;i++) {
			for(int j=0;j<SIZE;j++) {
				bingo[i][j]=i*SIZE+j+1;//5i+j+1 -> 1 ~ 25
				//System.out.printf("%3d",bingo[i][j]);
			}
			//System.out.println();
		}
		
		//배열된 값을 섞는다.(suffle)
		for(int i=0;i<SIZE;i++) {
			for(int j=0;j<SIZE;j++) {
				x = (int)(Math.random()*SIZE) ;//0<=x<5
				y = (int)(Math.random()*SIZE) ;//0<=y<5
				
				int temp = bingo[i][j];
				bingo[i][j] = bingo[x][y];
				bingo[x][y] = temp;
			}
		}
		
//		System.out.println("suffle 이후");
		//1~25까지 할당
//		for(int i=0;i<SIZE;i++) {
//			for(int j=0;j<SIZE;j++) {
//				//bingo[i][j]=i*SIZE+j+1;//5i+j+1 -> 1 ~ 25
//				System.out.printf("%3d",bingo[i][j]);
//			}
//			System.out.println();
//		}		
		
		do {
			//shuffle된 빙고판 출력
			for(int i=0;i<SIZE;i++) {
				for(int j=0;j<SIZE;j++) {
					System.out.printf("%2d ",bingo[i][j]);
				}
				System.out.println();
			}		
			
			//사용자에게 숫자 입력 
			System.out.printf("1~%d의 숫자를 입력 하세요.(종료:0)>",SIZE*SIZE);
			num = scanner.nextInt();
			
			//입력 받은 숫자와 같은 숫자가 저장된 요소를 찾아서 0을 저장
			outer:  //named break : 2중 for문을 벚어 난다.
			for(int i=0;i<SIZE;i++) {
				for(int j=0;j<SIZE;j++) {
					if(bingo[i][j] == num) {
						bingo[i][j] = 0;
						break outer;
					}
				}
			}
			
			
		}while(num!=0);
		
		System.out.println("==========================");
		System.out.println("==프로그램 종료!==");
		System.out.println("==========================");
		
		
		

	}

}
//1~25의 숫자를 입력 하세요.(종료:0)>18
//17 16  5  2 19 
//14  9 20 24  4 
//13 10  0  3 12 
//23 25 15 21 22 
// 8 11  7  1  6 
//1~25의 숫자를 입력 하세요.(종료:0)>