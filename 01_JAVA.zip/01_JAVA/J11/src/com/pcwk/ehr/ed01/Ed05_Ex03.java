package com.pcwk.ehr.ed01;

public class Ed05_Ex03 {

	public static void main(String[] args) {
		// A * B = C(2행2열)
		int[][] A = { { 1, 2, 3 }, 
				      { 4, 5, 6 } };

		int[][] B = { { 7, 8 }, 
				      { 9, 10 }, 
				      { 11, 12 } };
		
		//곱셈결과
		int[][] C =new int[2][2];
		
		// 58
		//{{1*7+2*9+3*11, 1*8+2*10+3*12}
		//,{4*7+5*9+6*11, 4*8+5*10+6*12}}
		
		for(int i=0;i<2;i++) {//C의 행
			for(int j=0;j<2;j++) {//C의 열
				
				int sum = 0;
				
				for(int k=0;k<3;k++) {
					sum += A[i][k]*B[k][j];
				}
				//System.out.println("sum:"+sum);
				C[i][j]= sum;
				
			}
		}
		
		
		//행렬의 곱 C 출력
		for(int i=0;i<C.length;i++) {
			for(int j=0;j<C[0].length;j++) {
				System.out.printf("C[%d][%d]=%d ",i,j,C[i][j]);
			}
			System.out.println();
		}
		

	}

}
//C[0][0]=58 C[0][1]=64 
//C[1][0]=139 C[1][1]=154 