package com.pcwk.ehr.ed02;

public class TvMain {

	public static void main(String[] args) {
		Tv tv;//Tv인스턴스를 참조하기 위한 변수 tv선언
		tv = new Tv();//Tv 인스턴스 생성

		//멤버변수
		tv.power = true;
		tv.channel = 3;
		
		//메서
		tv.channelUp();
		
		
		System.out.printf("전원 : %b\t 채널:%d\n",tv.power, tv.channel);
	}

}
//전원 : true	 채널:4