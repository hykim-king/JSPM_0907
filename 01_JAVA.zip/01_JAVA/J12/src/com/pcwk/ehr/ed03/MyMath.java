package com.pcwk.ehr.ed03;

public class MyMath {

	//return문이 제어문마다 올수 있다.
	long max(long x, long y) {
		if( x > y) {
			return x;
		}else {
			return y;
		}
	}
	
	
	
	void printDisp() {
		System.out.println("return문이 없다.");
		
		//return; 컴파일러가 추가해 준다.
	}
	
	/**
	 * 더하기        <br/>
	 * @param x 
	 * @param y
	 * @return x + y
	 */
	long add(long x, long y) {
		long result = x + y;
		
		return result; //return x+y
	}
	
	/**
	 * 빼기
	 * @param x
	 * @param y
	 * @return x - y
	 */
	long substract(long x, long y) {
		return x - y;
	}
	
	/**
	 * 곱하기
	 * @param x
	 * @param y
	 * @return x*y
	 */
	long multiply(long x, long y) {
		return x * y;
	}
	
	
	double divide(double x, double y) {
		return x/y;
	}

	
}
