package com.pcwk.ehr.ed03;

public class MyMathMain {

	public static void main(String[] args) {
		MyMath mm=new MyMath();
		
		long result01 = mm.add(14L, 12L);
		long result02 = mm.substract(14L, 12L);
		long result03 = mm.multiply(14L, 12L);
		double result04 = mm.divide(14.0, 12.0D);
		
		System.out.printf("add(14L, 12L)=%d\n",result01);
		System.out.printf("substract(14L, 12L)=%d\n",result02);
		System.out.printf("multiply(14L, 12L)=%d\n",result03);
		System.out.printf("divide(14L, 12L)=%5.2f\n",result04);

	}

}
//add(14L, 12L)=26
//substract(14L, 12L)=2
//multiply(14L, 12L)=168
//divide(14L, 12L)= 1.17