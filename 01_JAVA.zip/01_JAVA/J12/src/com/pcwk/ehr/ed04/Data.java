package com.pcwk.ehr.ed04;

public class Data {
	int x;
}
