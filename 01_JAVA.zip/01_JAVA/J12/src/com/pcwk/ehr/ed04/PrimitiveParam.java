package com.pcwk.ehr.ed04;

public class PrimitiveParam {

	public static void main(String[] args) {
		
		Data d=new Data();
		d.x = 10;
		
		System.out.println("main(): x="+d.x);
		
		change(d.x);
		System.out.println("change 호출 이후");
		System.out.println("main(): x="+d.x);
	}
	
	static void change(int x) {//기본형 매개 변수
		x = 1000;
		System.out.println("change():x="+x);
	}

}
//main(): x=10
//change():x=1000
//change 호출 이후
//main(): x=10
