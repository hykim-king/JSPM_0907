package com.pcwk.ehr.ed05;

public class FactorialMain {

	public static void main(String[] args) {
//		팩토리얼(階乘, 문화어: 차례곱, 영어: factorial)은 그 수보다 작거나 같은 모든 양의 정수의 곱이다. 
//		n이 하나의 자연수일 때, 1에서 n까지의 모든 자연수의 곱을 n에 상대하여 이르는 말이다. 
//		기호는 느낌표(!) 를 쓰며 팩토리얼이라고 읽는다.
//      5! -> 5*4*3*2*1
		int result = factorial(5);
		
		System.out.println("5!="+result);
	}
	
	
	static int factorial(int n) {
		int result = 0;
		
		if(n == 1) {
			result = 1;
		}else {
			result = n * factorial(n-1);
		}
				
		return result;		
	}

}
//5!=120