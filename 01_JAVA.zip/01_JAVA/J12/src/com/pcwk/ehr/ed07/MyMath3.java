package com.pcwk.ehr.ed07;

public class MyMath3 {

	/**
	 * add
	 * @param x
	 * @param y
	 * @return int + int
	 */
	int add(int x, int y) {
		System.out.print("int add(int x, int y) -");
		return x+y;
	}
	
//	int add(int a, int b) {
//		System.out.print("int add(int x, int y) -");
//		return x+y;
//	}
	
	
	long add(int x, long y) {
		System.out.print("int add(int x, long y) -");
		return x+y;
	}
	
	long add(long x, int y) {
		System.out.print("long add(long x, int y) -");
		return x+y;
	}	
}
