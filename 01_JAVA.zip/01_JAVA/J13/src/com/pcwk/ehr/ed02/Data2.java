package com.pcwk.ehr.ed02;

public class Data2 {
	int value;

// 인자있는 생성자가 1개라도 있으면 default생성자를 
// 만들어 주지 않는다.	
//	Data2(){
//		
//	}
	
	Data2(int x){
		value = x;
	}
}
