package com.pcwk.ehr.ed03;

public class CarMain {

	public static void main(String[] args) {
		
		Car myCar=new Car();
		myCar.brand = "GENESIS";
		myCar.model = "GV80";
		myCar.year  = 2023;
		
		//Car클래스의 인자있는 생성자를 통한 멤버 변수 초기화
		Car myCar02=new Car("GENESIS","GV80",2023);
		
		myCar02.startEngine();
		myCar02.stopEngine();
		
		System.out.println("brand:"+myCar02.brand);
		System.out.println("model:"+myCar02.model);
		System.out.println("year:"+myCar02.year);

	}

}
//차량 시동을 겁니다.
//차량 시동을 꺼집니다.
//brand:GENESIS
//model:GV80
//year:2023