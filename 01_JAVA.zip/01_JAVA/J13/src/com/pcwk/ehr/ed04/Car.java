package com.pcwk.ehr.ed04;

public class Car {
	// 멤버변수(인스턴스 변수)

	String brand;// 브랜드
	String model;// 모델
	int year; // 연식

	Car() {
	  //System.out.println(""); Constructor call must be the first statement in a constructor	
      this("GENESIS","GV80",2023);
	}
	
	Car(String brand) {
		this(brand,"GV80",2023);
	}

	// alt+shift+s ->
	Car(String brand, String model, int year) {
		this.brand = brand;
		this.model = model;
		this.year = year;
	}

	public void startEngine() {
		System.out.println("차량 시동을 겁니다.");
	}

	public void stopEngine() {
		System.out.println("차량 시동을 꺼집니다.");
	}
}
