package com.pcwk.ehr.ed04;

public class CarConstructorThisMain {

	public static void main(String[] args) {
		Car car01=new Car();
		
		System.out.println("car01.brand:"+car01.brand);
		System.out.println("car01.model:"+car01.model);
		System.out.println("car01.year:"+car01.year);

		System.out.println("===========================");
		
		Car car02=new Car("그랜저");
		System.out.println("car02.brand:"+car02.brand);
		System.out.println("car02.model:"+car02.model);
		System.out.println("car02.year:"+car02.year);		
	}

}
