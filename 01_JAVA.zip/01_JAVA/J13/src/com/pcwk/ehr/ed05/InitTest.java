package com.pcwk.ehr.ed05;

public class InitTest {

	int x;
	int y = 0;
	
	
	void methodP() {
		int i=0;
		//The local variable i may not have been initialized
		//int j = i;
		System.out.println(i);
	}
	
}
