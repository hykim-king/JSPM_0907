package com.pcwk.ehr.ed01;

public class CaptionTv extends Tv {

	boolean caption;//캡셥 on/off
	
	void displayCaption(String text) {
		
		if(caption) {//캡셥 on때 자박 출력
			System.out.println(text);
		}
	}
	
	
}
