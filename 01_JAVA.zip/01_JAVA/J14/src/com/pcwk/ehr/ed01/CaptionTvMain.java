package com.pcwk.ehr.ed01;

public class CaptionTvMain {

	public static void main(String[] args) {
		CaptionTv captionTv=new CaptionTv();//클래스 이름은 대문자로 시작하고, 그 다음 단어의 첫 글자 대문자로 표시한다.
		
		captionTv.power();//전원 on
		
		captionTv.channel = 3;//tvN
		captionTv.channelUp();
		
		System.out.println(captionTv.channel);
		System.out.println(captionTv.power);
		
		System.out.println("caption");
		captionTv.displayCaption("Hello, world!");
		
		captionTv.caption = true;
		captionTv.displayCaption("Hello, world!");

	}

}
//4
//true
//caption
//Hello, world!