package com.pcwk.ehr.ed02;

/**
 * 도형 클래스 Parent
 * @author user
 *
 */
public class Shape {

	String color = "black";
	
	void draw() {
		System.out.printf("[color=%s]\n",color);
	}
	
}
