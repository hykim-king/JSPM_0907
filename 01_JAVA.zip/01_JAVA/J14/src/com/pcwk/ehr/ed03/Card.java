package com.pcwk.ehr.ed03;
/**
 * 카드클래스 모델링
 * @author user
 *
 */
public class Card {

	static final int KIND_MAX = 4; //무늬 4개
	static final int NUM_MAX  = 13;//무늬 별 카드 수 13개
	
	static final int SPADE = 4;
	static final int DIAMOND = 3;
	static final int HEART = 2;
	static final int CLOVER = 1;
	
	int kind;//무늬
	int number;//숫자
	
	public Card() {
		this(SPADE,1);
	}
	
	public Card(int kind, int number) {
		this.kind = kind;
		this.number = number;
	}
   
	@Override
	public String toString() {
		//배열 인덱스 == CLOVER = 1,HEART = 2,...SPADE = 4
		String[] kinds = {"","CLOVER","HEART","DIAMOND","SPADE"};
		String numbers = "0123456789XJQK";//숫자 10은 X로 표시
		
		return "kind :"+kinds[this.kind] +", number : "
		           +numbers.charAt(this.number);
	}
	

	
	
	
	
}
