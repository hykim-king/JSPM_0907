package com.pcwk.ehr.ed03;

public class DeckMain {

	public static void main(String[] args) {
		Deck deck=new Deck();
		
		Card c = deck.pick(0);
		//초기화된 Deck 배열요소 0 : SPADE,1
		System.out.println(c.toString());
		

		deck.shuffle();//카드 석기
		Card c2 = deck.pick(0);
		System.out.println(c2.toString());
		
	}

}
//kind :SPADE, number : 1
//kind :DIAMOND, number : Q