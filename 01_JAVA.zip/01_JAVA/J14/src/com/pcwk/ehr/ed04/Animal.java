package com.pcwk.ehr.ed04;

public class Animal {//extends Object 컴파일러가 넣는다.

	void makeSound() {
		System.out.println("동물이 소리를 내고 있습니다.");
	}
}
