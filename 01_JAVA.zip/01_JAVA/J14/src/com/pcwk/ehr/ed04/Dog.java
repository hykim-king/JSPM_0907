package com.pcwk.ehr.ed04;

public class Dog extends Animal {

	@Override
	void makeSound() {
		System.out.println("개가 짖고 있습니다.");
	}
}
