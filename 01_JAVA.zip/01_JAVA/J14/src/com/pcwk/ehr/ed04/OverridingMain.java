package com.pcwk.ehr.ed04;

public class OverridingMain {

	public static void main(String[] args) {
		Dog dog=new Dog();
		//개가 짖고 있습니다. 오버라이드된 Dog의 makeSound()호출
		dog.makeSound();

	}

}
