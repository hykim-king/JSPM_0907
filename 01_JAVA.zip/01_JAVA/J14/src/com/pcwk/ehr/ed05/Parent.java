package com.pcwk.ehr.ed05;

public class Parent {
	int age = 22;
}
