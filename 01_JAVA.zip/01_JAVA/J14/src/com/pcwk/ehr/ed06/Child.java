package com.pcwk.ehr.ed06;

public class Child extends Parent {

	int childNum;
	
	Child(int num, int childNum){
		
		//첫 줄에 와야 한다.
		//명시적으로 super(num)를 호출 하지 않으면 컴파일러가 super()를 넣는다.
		super(num);
		this.childNum = childNum;
		
	}
}
