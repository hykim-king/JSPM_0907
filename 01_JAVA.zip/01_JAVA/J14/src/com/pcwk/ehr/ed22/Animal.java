package com.pcwk.ehr.ed22;

//부모 클래스
class Animal {
	void eat() {
		System.out.println("동물이 먹는 중입니다.");
	}
}