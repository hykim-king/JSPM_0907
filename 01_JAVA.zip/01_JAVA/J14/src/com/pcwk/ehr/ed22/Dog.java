package com.pcwk.ehr.ed22;

//자식 클래스
class Dog extends Animal {
	void bark() {
		System.out.println("강아지가 짖습니다.");
	}
}