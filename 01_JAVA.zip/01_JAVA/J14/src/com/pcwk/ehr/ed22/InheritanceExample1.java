package com.pcwk.ehr.ed22;

public class InheritanceExample1 {

    public static void main(String[] args) {
        Dog myDog = new Dog();
        myDog.eat(); // 부모 클래스의 메서드 호출
        myDog.bark(); // 자식 클래스의 메서드 호출
    }
}
