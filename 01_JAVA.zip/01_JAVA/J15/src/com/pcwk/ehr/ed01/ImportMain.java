package com.pcwk.ehr.ed01;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.pcwk.ehr.ed02.Time;

//ctrl+shift+f : 소스 정렬
//ctrl+shift+o : import문 정리 : *은 해당 클래스로, 사용하지 않은 import문 삭제

/**
 * Package Name : com.pcwk.ehr.ed01 <br/>
 * Class Name: ImportMain.java <br/>
 * Description: 자바 라이브러리 import 테스트 <br/>
 * Modification imformation : <br/>
 * ------------------------------------------<br/>
 * 최초 생성일 : 2023.09.26<br/>
 *
 * ------------------------------------------<br/>
 * @author : user
 * @since  : 2023.09.07
 * @version: 0.5
 */
public class ImportMain {

	/**
	 * 두 수를 더하는 메서드
	 * {@link StaticImport}의 특정 메서드를 호출
	 * @param a 첫 번째 정수
	 * @param b 두 번째 정수
	 * @return 두 수의 합
	 */
	public int add(int a, int b) {
		return a+b;
	}
	
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
//java.util.Date  today=new java.util.Date();

		Date today = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd");// 년.월.일
		SimpleDateFormat time = new SimpleDateFormat("hh:mm:ss a");// 년.월.일

		System.out.println("today:" + today);
		System.out.println("yyyy.MM.dd:" + sdf.format(today));
		System.out.println("hh:mm:ss a" + time.format(today));
		
		Time timeNew=new Time();

	}

}
//today:Tue Sep 26 10:04:49 KST 2023
//yyyy.MM.dd:2023.09.26
//hh:mm:ss a10:04:49 오전