/**
 * Package Name : com.pcwk.ehr.ed01 <br/>
 * Class Name: StaticImport.java <br/>
 * Description: static import문 <br/>
 * Modification imformation :
 * ------------------------------------------
 * 최초 생성일 : 2023.09.26
 *
 * ------------------------------------------
 * author : user
 * since  : 2023.09.07
 * version: 0.5
 * see    : <br/>
 * Copyright (C) by PCWK All right reserved.
 */
package com.pcwk.ehr.ed01;

import static java.lang.Math.PI;
import static java.lang.System.out;

public class StaticImport {

	/**
	 * main 메서드
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		// System.out.println("static import");
		// public final static PrintStream out = null;
		out.println("static import");

		// public static final double PI = 3.14159265358979323846;
		// System.out.println(Math.PI);
		out.println(PI);

	}

}
//static import
//3.141592653589793