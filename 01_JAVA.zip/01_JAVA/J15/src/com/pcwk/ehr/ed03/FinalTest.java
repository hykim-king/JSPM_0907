/**
 * Package Name : com.pcwk.ehr.ed03 <br/>
 * Class Name: FinalTest.java <br/>
 * Description: <br/>
 * Modification imformation :
 * ------------------------------------------
 * 최초 생성일 : 2023.09.26
 *
 * ------------------------------------------
 * author : user
 * since  : 2023.09.07
 * version: 0.5
 * see    : <br/>
 * Copyright (C) by PCWK All right reserved.
 */
package com.pcwk.ehr.ed03;


public final class FinalTest { // 변경될 수 없는 클래스, 확장될 수 없는 클래스 :ex) String
  
	final int MAX_SIZE = 10;  //값을 변경할 수 없는 멤버변수(상수)
	
	final void getMaxSize() { //오버라이딩할 수 없는 메서드
		final int LV = 14; // 값을 변경할 수 없는 지역변수
	}
	
}
