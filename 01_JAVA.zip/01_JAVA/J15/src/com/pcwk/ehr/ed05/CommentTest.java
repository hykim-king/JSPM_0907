package com.pcwk.ehr.ed05;
/**
 * Package Name : com.pcwk.ehr.ed05 <br/>
 * Class Name: CommentTest.java <br/>
 * Description: <br/>
 * Modification imformation :
 * ------------------------------------------<br/>
 * 최초 생성일 : 2023.09.26<br/>
 *
 * ------------------------------------------<br/>
 * author : user
 * since  : 2023.09.07
 * version: 0.5
 * see    : <br/>
 * Copyright (C) by PCWK All right reserved.
 */
public class CommentTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
