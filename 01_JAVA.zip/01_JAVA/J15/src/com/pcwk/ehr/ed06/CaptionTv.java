package com.pcwk.ehr.ed06;

public class CaptionTv extends Tv {

	String text;// 캡셥 on/off

	void displayCaption() {
		System.out.println(text);
	}

}
