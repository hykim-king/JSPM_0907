package com.pcwk.ehr.ed07;
/**
 * Package Name : com.pcwk.ehr.ed07 <br/>
 * Class Name: FireEngine.java <br/>
 * Description: <br/>
 * Modification imformation :
 * ------------------------------------------<br/>
 * 최초 생성일 : 2023.09.26<br/>
 *
 * ------------------------------------------<br/>
 * author : user
 * since  : 2023.09.07
 * version: 0.5
 * see    : <br/>
 * Copyright (C) by PCWK All right reserved.
 */

/**
 * @author user
 *
 */
public class FireEngine extends Car {

	public FireEngine() {}
	
	void warter() {
		System.out.println("water!!");
	}
}
