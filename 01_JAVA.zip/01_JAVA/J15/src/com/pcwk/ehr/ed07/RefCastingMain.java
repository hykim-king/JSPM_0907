package com.pcwk.ehr.ed07;
/**
 * Package Name : com.pcwk.ehr.ed07 <br/>
 * Class Name: RefCastingMain.java <br/>
 * Description: <br/>
 * Modification imformation :
 * ------------------------------------------<br/>
 * 최초 생성일 : 2023.09.26<br/>
 *
 * ------------------------------------------<br/>
 * author : user
 * since  : 2023.09.07
 * version: 0.5
 * see    : <br/>
 * Copyright (C) by PCWK All right reserved.
 */

/**
 * @author user
 *
 */
public class RefCastingMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Car  car = null;
		FireEngine  fe=new FireEngine();
		
		fe.warter();
		
		//자손 타입 → 조상타입(Up-casting) :  형변환 생략 가능
		car = fe;
		//car.water(); //The method water() is undefined for the type Car
		
		FireEngine  fe02=null;
		
		//조상타입  → 자손 타입(Down-casting): 형변환 생략 불가
		fe02 = (FireEngine) car;
		fe02.warter();
	}

}
