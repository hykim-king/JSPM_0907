package com.pcwk.ehr.ed09;

public class Child extends Parent {
	public int age = 12;
	
	public void pcwkMethod() {
		System.out.println("Child pcwkMethod()");
	}
}
