package com.pcwk.ehr.ed01;

public class Audio extends Product{

	public Audio() {
		super(1100);//Audio 가격 1100만원으로 한다.
	}

	@Override
	public String toString() {
		return "Audio";
	}
	
	
}
