package com.pcwk.ehr.ed01;

public class Buyer {
	int money = 5_000;  //소유 금액
	int bonusPoint = 0; //보너스 포인트

	public Buyer() {
		super();
	}
	
	
	void buy(Product p) {
		if(money<p.price ) {
			System.out.println("잔액이 부족합니다.\n잔액을 확인 하세요");
			return;
		}
		
		money = money - p.price;//money -= p.price
		bonusPoint += p.bonusPoint; //제품의 보너스 점수를 추가한다.
		
		System.out.println(p + "을/를 구입 했습니다.");
	}
	
	
	
}
