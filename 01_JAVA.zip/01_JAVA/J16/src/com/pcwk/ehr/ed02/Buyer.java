package com.pcwk.ehr.ed02;

public class Buyer {
	int money = 5_000; // 소유 금액
	int bonusPoint = 0; // 보너스 포인트

	Product[] item=new Product[10];//구입한 제품을 저장
	int i =0;//구입한 제품 counter
	
	public Buyer() {
		super();
	}

	/**
	 * 구매 제품 요약 : 구매 제품 List, 총구매 금액(sum)
	 */
	void summary() {
		int sum = 0;//구매 제품 합계
		String itemList = "";//제품 리스트
		
		
		
		for(int i=0;i<item.length;i++) {
			if(null==item[i]) {
				break;
			}
			
			sum += item[i].price;
			
			itemList += item[i]+",";
		}
		
		
		System.out.println("구매 총금액 :"+sum+"만원 입니다.");
		System.out.println("구매 제품은 "+itemList+" 입니다.");
		
	}
	
	
	/**
	 * 제품 구매
	 * @param p
	 */
	void buy(Product p) {
		if (money < p.price) {
			System.out.println("잔액이 부족합니다.\n잔액을 확인 하세요");
			return;
		}

		money = money - p.price;// money -= p.price
		bonusPoint += p.bonusPoint; // 제품의 보너스 점수를 추가한다.

		item[i++] = p; //Product[]에 제품 저장
		
		System.out.println(p + "을/를 구입 했습니다.");
	}

}
