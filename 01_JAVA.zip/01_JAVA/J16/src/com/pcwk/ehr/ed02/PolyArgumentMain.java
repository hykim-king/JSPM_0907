package com.pcwk.ehr.ed02;

public class PolyArgumentMain {

	public static void main(String[] args) {
		Buyer b=new Buyer();
		
		
		b.buy(new Computer());
		b.buy(new Audio());
		b.buy(new Tv());
		
		
		System.out.println("================================");
		System.out.println("잔액:"+b.money+"만원 입니다.");
		System.out.println("보너스 점수:"+b.bonusPoint+"점 입니다.");
		
		b.summary();
	}

}
//Computer을/를 구입 했습니다.
//Audio을/를 구입 했습니다.
//Tv을/를 구입 했습니다.
//================================
//잔액:2000만원 입니다.
//보너스 점수:300점 입니다.
//구매 총금액 :3000만원 입니다.
//구매 제품은 Computer,Audio,Tv, 입니다.