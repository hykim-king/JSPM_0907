package com.pcwk.ehr.ed03;

import java.util.Vector;

public class Buyer {
	int money = 5_000; // 소유 금액
	int bonusPoint = 0; // 보너스 포인트

	Vector item=new Vector();//구입한 제품을 저장 Vector
	int i =0;//구입한 제품 counter
	
	public Buyer() {
		super();
	}

	/**
	 * item, money, bonusPoint 되돌리기
	 * @param p
	 */
	void refund(Product p) {
		//item 되돌리기
		if(true==item.remove(p)) {
			
			money =  money + p.price;//소유 금액
			
			bonusPoint =  bonusPoint - p.bonusPoint;
			System.out.println(p +"을 반품하셨습니다.");
		}else {
			System.out.println("구입 한 제품 중 해당 제품이 없습니다.");
		}
	}
	
	/**
	 * 구매 제품 요약 : 구매 제품 List, 총구매 금액(sum)
	 */
	void summary() {
		int sum = 0;//구매 제품 합계
		String itemList = "";//제품 리스트
		
		if(true==item.isEmpty()) {
			System.out.println("구입하신 제품이 없습니다.");
			return;
		}
		
		
		
		for(int i=0;i<item.size() ;i++) {
			Product p = (Product) item.get(i);
			
			sum += p.price;
			
			//String delim = (i==(item.size()-1))?"":",";
			
			itemList += (i==0) ? ""+p:","+p;
		}
		
		
		System.out.println("구매 총금액 :"+sum+"만원 입니다.");
		System.out.println("구매 제품은 "+itemList+" 입니다.");
		
	}
	
	
	/**
	 * 제품 구매
	 * @param p
	 */
	void buy(Product p) {
		if (money < p.price) {
			System.out.println("잔액이 부족합니다.\n잔액을 확인 하세요");
			return;
		}

		money = money - p.price;// money -= p.price
		bonusPoint += p.bonusPoint; // 제품의 보너스 점수를 추가한다.

		boolean isAdded = item.add(p); //Vector에 제품 추가!
		System.out.println("추가 여부:"+isAdded);
		//item[i++] = p; //Product[]에 제품 저장
		
		System.out.println(p + "을/를 구입 했습니다.");
	}

}
