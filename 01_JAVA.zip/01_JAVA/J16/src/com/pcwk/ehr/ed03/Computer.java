package com.pcwk.ehr.ed03;

public class Computer extends Product {

	public Computer() {
		super(900);//Computer 가격 900만원으로 한다.
	}

	@Override
	public String toString() {
		return "Computer";
	}
	
	
}
