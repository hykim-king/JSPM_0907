package com.pcwk.ehr.ed03;

public class PolyArgumentMain {

	public static void main(String[] args) {
		Buyer b=new Buyer();
		
		Computer c=new Computer();
		Audio a=new Audio();
		Tv t=new Tv();
		
		b.buy(c);
		b.buy(a);
		b.buy(t);
		b.summary();
		System.out.println("보너스 점수:"+b.bonusPoint+"점 입니다.");
		System.out.println("================================");
		b.refund(a);
		b.summary();
		System.out.println("보너스 점수:"+b.bonusPoint+"점 입니다.");
		
//		System.out.println("================================");
//		System.out.println("잔액:"+b.money+"만원 입니다.");
//		System.out.println("보너스 점수:"+b.bonusPoint+"점 입니다.");
		
		
	}

}
//추가 여부:true
//Computer을/를 구입 했습니다.
//추가 여부:true
//Audio을/를 구입 했습니다.
//추가 여부:true
//Tv을/를 구입 했습니다.
//구매 총금액 :3000만원 입니다.
//구매 제품은 Computer,Audio,Tv 입니다.
//보너스 점수:300점 입니다.
//================================
//Audio을 반품하셨습니다.
//구매 총금액 :1900만원 입니다.
//구매 제품은 Computer,Tv 입니다.
//보너스 점수:190점 입니다.
