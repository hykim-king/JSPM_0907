package com.pcwk.ehr.ed03;

public class Tv extends Product {

	public Tv() {
		super(1000); //Tv가격을 1000만원으로 한다.
	}

	@Override
	public String toString() {
		return "Tv";
	}
	
	
}
