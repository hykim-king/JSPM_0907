package com.pcwk.ehr.ed04;

public class AbstractMain {

	public static void main(String[] args) {
		//Cannot instantiate the type Player
		Player player=new AudioPLayer();

		player.play(22);
		player.disp();
		player.stop();
	}

}
