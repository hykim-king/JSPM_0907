package com.pcwk.ehr.ed04;

public class AudioPLayer extends Player {

	@Override
	void play(int post) {
		System.out.println("AudioPLayer:play()"+post);
		
	}

	@Override
	void stop() {
		System.out.println("AudioPLayer:stop()");
		
	}



}
