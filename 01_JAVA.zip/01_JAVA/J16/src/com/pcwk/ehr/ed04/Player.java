package com.pcwk.ehr.ed04;

public abstract class Player {

	boolean pause;//일시정지
	int currentPos;//현재 play위치
	
	abstract void play(int post); //추상 메서드
	abstract void stop(); //추상 메서드
	
	void disp() {
		System.out.println("disp()");
	}
	
}
