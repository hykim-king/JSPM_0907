package com.pcwk.ehr.ed05;

public class AbstractMain {

	public static void main(String[] args) {
		//Unit배열
		Unit[] unitArray=new Unit[4];
		
		unitArray[0] = new Marine();
		unitArray[1] = new Tank();
		unitArray[2] = new Dropship();
		unitArray[3] = new Marine();
		
		
		//Unit이동
		for(int i=0;i<unitArray.length;i++) {
			unitArray[i].move(100, 180);
		}
		System.out.println("======================");
		
		
		//모든 자바 클래스의 조상 Object
		Object[] objArray=new Object[4];
		objArray[0] = new Marine();
		objArray[1] = new Tank();
		objArray[2] = new Dropship();
		objArray[3] = new Marine();	
		
		for(int i=0;i<objArray.length;i++) {
			Unit u=(Unit)objArray[i];
			u.move(200, 180);
		}
		
		
	}

}
//Marine 이동 x=100, y=180
//Tank 이동 x=100, y=180
//Dropship 이동 x=100, y=180
//Marine 이동 x=100, y=180
//======================
//Marine 이동 x=200, y=180
//Tank 이동 x=200, y=180
//Dropship 이동 x=200, y=180
//Marine 이동 x=200, y=180