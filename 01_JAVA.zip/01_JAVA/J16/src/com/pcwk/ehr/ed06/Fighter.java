package com.pcwk.ehr.ed06;

//public class Fighter extends Unit implements Attackable, Movable {
public class Fighter extends Unit implements Fightable {

	@Override
	public void attack(Unit u) {
		// TODO Auto-generated method stub

	}

	@Override
	public void move(int x, int y) {
		// TODO Auto-generated method stub

	}

}
