package com.pcwk.ehr.ed06;

public class FighterMain {

	public static void main(String[] args) {
		Fighter  f=new Fighter();
		
		//Fighter다형성
		if(f instanceof Unit) {
			System.out.println("Fighter는 Unit클래스의 자손이다.");
		}
		
		if(f instanceof Fightable) {
			System.out.println("Fighter는 Fightable인터페이스를 구현.");
		}
		
		if(f instanceof Movable) {
			System.out.println("Fighter는 Movable인터페이스를 구현.");
		}		
		
		if(f instanceof Attackable) {
			System.out.println("Fighter는 Attackable인터페이스를 구현.");
		}
		
		if(f instanceof Object) {
			System.out.println("Fighter는 Object클래스의 자손이다.");
		}		
	}

}
//Fighter는 Unit클래스의 자손이다.
//Fighter는 Fightable인터페이스를 구현.
//Fighter는 Movable인터페이스를 구현.
//Fighter는 Attackable인터페이스를 구현.
//Fighter는 Object클래스의 자손이다.

