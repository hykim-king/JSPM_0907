package com.pcwk.ehr.ed02;

public class ParserMain {

	public static void main(String[] args) {
		Parseable parser = ParserManager.getParser("XML");
		parser.parse("pcwk.xml");//pcwk.xml XML parsing completed

		parser = ParserManager.getParser("JSON");
		parser.parse("pcwkJson.json");//pcwkJson.json JSON parsing completed
		
	}

}
