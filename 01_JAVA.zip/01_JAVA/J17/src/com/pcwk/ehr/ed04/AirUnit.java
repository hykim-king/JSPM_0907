package com.pcwk.ehr.ed04;

public class AirUnit extends Unit {
	
	AirUnit(int hp){
		super(hp);
	}
}
