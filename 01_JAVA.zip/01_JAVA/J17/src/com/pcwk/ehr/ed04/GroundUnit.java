package com.pcwk.ehr.ed04;

public class GroundUnit extends Unit {

	GroundUnit(int hp){
		super(hp);
	}
}
