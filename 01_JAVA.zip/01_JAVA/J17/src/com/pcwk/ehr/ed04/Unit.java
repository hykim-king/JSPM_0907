package com.pcwk.ehr.ed04;

public class Unit {
	int hitPoint;
	final int MAX_HP;//상수
	
	Unit(int hp){
		MAX_HP = hp;//상수를 생성자 내에서 초기화
	}
	
}
