package com.pcwk.ehr.ed05;

public class Person {
	Chicken  chicken;
	
	public Person() {
		chicken = new Chicken();
	}
	
	public void startEat() {
		chicken.eat();
	}
	
}
