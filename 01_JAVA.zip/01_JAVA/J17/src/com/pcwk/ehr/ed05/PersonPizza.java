package com.pcwk.ehr.ed05;

public class PersonPizza {
	Pizza  pizza;
	
	public PersonPizza() {
		pizza = new Pizza();
	}
	
	public void startEat() {
		pizza.eat();
	}
	
}
