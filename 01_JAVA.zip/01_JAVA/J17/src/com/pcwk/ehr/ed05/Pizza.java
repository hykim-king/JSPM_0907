package com.pcwk.ehr.ed05;

public class Pizza {

	
	public void eat() {
		System.out.println("포테이토 피자를 먹습니다.");
	}
}
