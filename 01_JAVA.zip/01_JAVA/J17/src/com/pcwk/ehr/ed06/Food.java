package com.pcwk.ehr.ed06;

public interface Food {
	
	//public abstract void eat();
	void eat();
}
