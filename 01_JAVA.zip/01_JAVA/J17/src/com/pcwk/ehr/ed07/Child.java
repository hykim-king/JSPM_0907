package com.pcwk.ehr.ed07;

public class Child extends Parent implements PcwkInter {

	@Override
	public void reularMethod() {
		System.out.println("child reularMethod()");
		
	}
	
	public void pcwkDefaultMethod() {
		System.out.println("pcwkDefaultMethod() is child");
	}
	

}
