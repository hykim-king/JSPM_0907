package com.pcwk.ehr.ed07;

public interface PcwkInter {
    //추상 메서드 
	void reularMethod();
	
	/**
	 * default키워드 사용시 일반메서드 처럼 body부분을 생성할 수 있다.
	 */
	default void pcwkDefaultMethod() {
		System.out.println("pcwkDefaultMethod() is PcwkInter");
	}
	
	/**
	 * static키워드 사용시 일반메서드 처럼 body부분을 생성할 수 있다.
	 */
	static void pcwkStaticMethod() {
		System.out.println("pcwkStaticMethod() is PcwkInter");
	}
}
