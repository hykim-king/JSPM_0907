package com.pcwk.ehr.ed08;

public class Outer {
	//instance inner class
	class InstanceInner {
		int iv = 100;
		
		//static int cv = 200; static변수를 사용할수 없다.
		final static int CONST = 22; //상수는 가능
	}
	//static inner class
	static class StaticInner{
		int iv = 200;
		static int cv = 200;
	}
	
	void pcwkMethod() {
		//local inner class
		class LocalInner {
			int iv = 300;
			//static int cv = 200; 사용 불가
			
		}
	}
}
