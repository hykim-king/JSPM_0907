package com.pcwk.ehr.ed08;

public class OuterInnerMain {

	public static void main(String[] args) {
		//인스턴스 생성시 우선적으로 Outer생성 필요
		Outer oc=new Outer();
		
		Outer.InstanceInner ii = oc.new InstanceInner();

		System.out.println("ii.iv:"+ii.iv);
		
		System.out.println("Outer.StaticInner.cv:"+Outer.StaticInner.cv);
		
		Outer.StaticInner si=new Outer.StaticInner();
		System.out.println("si.iv:"+si.iv);
	}

}
