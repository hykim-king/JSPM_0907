package com.pcwk.ehr.ed09;

public class PcwkMain {

	public static void main(String[] args) {
		
		Animal  animal=new Dog();
		//개가 짖습니다.
		System.out.println(animal.bark());

	}

}
