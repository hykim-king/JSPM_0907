package com.pcwk.ehr.ed10;

public class Animal {
	public String bark() {
		return "동물이 웁니다.";
	}
}
