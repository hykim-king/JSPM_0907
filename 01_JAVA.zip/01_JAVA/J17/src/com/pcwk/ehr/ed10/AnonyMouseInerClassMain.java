package com.pcwk.ehr.ed10;

public class AnonyMouseInerClassMain {

	public static void main(String[] args) {
		Animal dog =new Animal() {

			@Override
			public String bark() {
				return "개가 짖습니다.";
			}
			
		};

		System.out.println(dog.bark());
	}

}
