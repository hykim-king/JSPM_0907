package com.pcwk.ehr.ed02;

public class ACONException extends Exception {

	public ACONException(String message) {
		super(message);
	}
}
