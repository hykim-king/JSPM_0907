package com.pcwk.ehr.ed02;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class Ex05_finally {

	public static void main(String[] args) {
		FileInputStream fis = null;
		System.out.println("A");
		
		String name = "C:\\JSPM_0907\\01_JAVA\\WORKSPACE\\J18\\src\\com\\pcwk\\ehr\\ed02\\Ex05_finally.java";
		
		try {
			System.out.println("B");
			fis = new FileInputStream(name);
			System.out.println("C");
		} catch (FileNotFoundException e) {
			System.out.println("D");
			e.printStackTrace();
		}finally {
			try {
				if(null !=fis) {
					fis.close();
				}
				System.out.println("finally E");
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		System.out.println("┌──────────────────┐");
		System.out.println("│프로그램 종료                │");
		System.out.println("└──────────────────┘");		
		
	}

}
//A
//B
//C
//finally E
//┌──────────────────┐
//│프로그램 종료                │
//└──────────────────┘