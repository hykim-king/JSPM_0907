package com.pcwk.ehr.ed02;

public class Ex06_MultiCatchMain {

	public static void main(String[] args) {
		
		System.out.println("A");
		
		int[] intArray= {1,2,0,3};
		try {
			System.out.println("B");
			
			for(int i=0;i<=intArray.length;i++) {
				System.out.println(intArray[i]);
			}
			
			System.out.println("C");
		}catch(ArithmeticException | ArrayIndexOutOfBoundsException e) {
			if(e instanceof ArithmeticException) {
				System.out.println("D");
				System.err.println("ArithmeticException:"+e.getMessage());
			}else if(e instanceof ArrayIndexOutOfBoundsException) {
				System.out.println("E");
				System.err.println("ArrayIndexOutOfBoundsException:"+e.getMessage());
			}
		}finally {//예외 발생 여부와 상관 없이 무조건 수행
			System.out.println("F finally");
		}
			
		System.out.println("┌──────────────────┐");
		System.out.println("│ End              │");
		System.out.println("└──────────────────┘");		
	}

}
//A
//B
//1
//2
//0
//3
//ArrayIndexOutOfBoundsException:4
//E
//F finally
//┌──────────────────┐
//│ End              │
//└──────────────────┘