package com.pcwk.ehr.ed02;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class Ex07_TryWithResourceMain {
    //try-with-resource 사용하지 않은 경우 : finally구문이 매우 장대함
	public static void main(String[] args) {
		//Ex07_TryWithResourceMain.java -> CopyEx07_TryWithResourceMain.java
		FileInputStream  fis = null;
		FileOutputStream fos = null;
		String orgFileName = "C:\\JSPM_0907\\01_JAVA\\WORKSPACE\\J18\\src\\com\\pcwk\\ehr\\ed02\\Ex07_TryWithResourceMain.java";
		String saveFileName = "CopyEx07_TryWithResourceMain.java";
		try {
			
			fis=new FileInputStream(orgFileName);
			fos=new FileOutputStream(saveFileName);
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) { //예외 처리의 최 상위 조상
			e.printStackTrace();
		}finally {
			if(null != fis) {
				try {
					fis.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			
			
			if(null !=fos) {
				try {
					fos.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

	}

}
