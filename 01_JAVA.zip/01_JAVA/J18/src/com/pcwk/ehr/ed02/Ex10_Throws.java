package com.pcwk.ehr.ed02;

public class Ex10_Throws {

	public static void main(String[] args) {
		
		try {
			checkAge(15);
			//checkAge(19);
		}catch(IllegalArgumentException e) {
			System.err.println("IllegalArgumentException 나이를 확인 하세요 :"+e.getMessage());
		}catch(ArrayIndexOutOfBoundsException e) {
			System.err.println("ArrayIndexOutOfBoundsException "+e.getMessage());
		}
		
		System.out.println("┌──────────────────┐");
		System.out.println("│ End              │");
		System.out.println("└──────────────────┘");	

	}

	
	static void checkAge(int age) throws IllegalArgumentException,ArrayIndexOutOfBoundsException {
		if(age<18) {
			throw new IllegalArgumentException("나이는 18세 이상 이어야 합니다.");
		}else {
			System.out.println("사이트에 access 가능 합니다.");
		}
	}
	
}
//IllegalArgumentException 나이를 확인 하세요 :나이는 18세 이상 이어야 합니다.
//┌──────────────────┐
//│ End              │
//└──────────────────┘