package com.pcwk.ehr.ed02;

public class Ex11_Throws {

	public static void main(String[] args) {
		
		try {
			checkAge(15);
			//checkAge(19);
		}catch(ACONException e) {
			System.err.println("ACONException 나이를 확인 하세요 :"+e.getMessage());
		}catch(ArrayIndexOutOfBoundsException e) {
			System.err.println("ArrayIndexOutOfBoundsException "+e.getMessage());
		}
		
		System.out.println("┌──────────────────┐");
		System.out.println("│ End              │");
		System.out.println("└──────────────────┘");	

	}

	
	static void checkAge(int age) throws ACONException,ArrayIndexOutOfBoundsException {
		if(age<18) {
			throw new ACONException("나이는 18세 이상 이어야 합니다.");
		}else {
			System.out.println("사이트에 access 가능 합니다.");
		}
	}
	
}
//ACONException 나이를 확인 하세요 :나이는 18세 이상 이어야 합니다.
//┌──────────────────┐
//│ End              │
//└──────────────────┘