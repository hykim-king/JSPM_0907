package com.pcwk.ehr.ed05;


import java.util.Date;

public class OverridetoStringMain {

	public static void main(String[] args) {
		//toString() 오버라이드 : Date, String
		Date today=new Date();
		System.out.println(today);
		System.out.println(today.toString());
		
		//String, java.lang에 속해 있으므로 import불필요
		String str=new String("점심");
		System.out.println(str);
		System.out.println(str.toString());
	}

}
//Thu Oct 05 12:38:26 KST 2023
//Thu Oct 05 12:38:26 KST 2023
//점심
//점심