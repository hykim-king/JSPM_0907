package com.pcwk.ehr.ed07;

public class Circle implements Cloneable {

	Pointer p;// x,y좌표
	int r;// 반지름

	/**
	 * @param p
	 * @param r
	 */
	public Circle(Pointer p, int r) {
		super();
		this.p = p;
		this.r = r;
	}

	@Override
	protected Circle clone() throws CloneNotSupportedException {
		Object obj = null;

		obj = super.clone();

		return (Circle) obj;
	}

	@Override
	public String toString() {
		return "Circle [p=" + p + ", r=" + r + "]";
	}

}
