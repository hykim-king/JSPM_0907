package com.pcwk.ehr.ed07;

public class Pointer  implements Cloneable{
/**
 * 구현 내용이 없음! : 마커 인터페이스 
 * public interface Cloneable {
   }
 */
	int x;//x좌표
	int y;//y좌표
	
	/**
	 * @param x
	 * @param y
	 */
	public Pointer(int x, int y) {
		super();
		this.x = x;
		this.y = y;
	}

	@Override
	public String toString() {
		return "Pointer [x=" + x + ", y=" + y + "]";
	}
	
	@Override
	public Object clone() {
		Object obj = null;
		
		try {
			obj = super.clone();
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
		}
		
		
		return obj;
	}
	
	
	
	
}
