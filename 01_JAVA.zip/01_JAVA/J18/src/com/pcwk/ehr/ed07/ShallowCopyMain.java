package com.pcwk.ehr.ed07;

public class ShallowCopyMain {

	public static void main(String[] args) {
		//얕은 Copy
		Circle  circle=new Circle(new Pointer(14,12), 17);
		
		try {
			Circle  cloneCircle=circle.clone();
			
			System.out.println("circle:"+circle);
			System.out.println("cloneCircle:"+cloneCircle);
			
			System.out.println("======================");
			circle.p.x = 4;
			circle.p.y = 2;
			
			System.out.println("circle:"+circle);
			System.out.println("cloneCircle:"+cloneCircle);			
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
		}
		

	}

}
//값 변경시 원본과 clone사이에 영향이 있음!
//circle:Circle [p=Pointer [x=14, y=12], r=17]
//cloneCircle:Circle [p=Pointer [x=14, y=12], r=17]
//======================
//circle:Circle [p=Pointer [x=4, y=2], r=17]
//cloneCircle:Circle [p=Pointer [x=4, y=2], r=17]