package com.pcwk.ehr.ed08;

public class Circle implements Cloneable {

	Pointer p;// x,y좌표
	int r;// 반지름

	/**
	 * @param p
	 * @param r
	 */
	public Circle(Pointer p, int r) {
		super();
		this.p = p;
		this.r = r;
	}

	@Override
	protected Circle clone() throws CloneNotSupportedException {
		Object obj = null;

		obj = super.clone();

		//참조변수 Pointer copy
		Circle tmpCircle=(Circle)obj;
		tmpCircle.p = new Pointer(this.p.x, this.p.y);
		
		
		return tmpCircle;
	}

	@Override
	public String toString() {
		return "Circle [p=" + p + ", r=" + r + "]";
	}

}
