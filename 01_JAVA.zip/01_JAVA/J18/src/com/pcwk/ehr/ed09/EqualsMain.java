package com.pcwk.ehr.ed09;

public class EqualsMain {

	public static void main(String[] args) {
		Person person01=new Person(1234567890);
		Person person02=new Person(1234567890);
//      
//      동일한 데이터를 가지고 있어도 동일하지 않음		
//	    public boolean equals(Object obj) {
//	        return (this == obj);
//	    }	
		//person01.equals(person02):false
		System.out.println("person01.equals(person02):"+person01.equals(person02));

	}

}
