package com.pcwk.ehr.ed09;

public class Person {
	long id;//회원ID

	/**
	 * @param id
	 */
	public Person(long id) {
		super();
		this.id = id;
	}

	@Override
	public String toString() {
		return "Person [id=" + id + "]";
	}
	
	
}
