package com.pcwk.ehr.ed10;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class EqualsMain {
	
	static final Logger LOG = LogManager.getLogger(EqualsMain.class);
	
	public static void main(String[] args) {
		Person person01=new Person(1234567890);
		Person person02=new Person(1234567890);
		
		//person01.equals(person02):true
		LOG.debug("person01.equals(person02):"+person01.equals(person02));
		LOG.debug(person01.toString());
		LOG.debug(person02.toString());  
		
		

	}

}
//person01.equals(person02):true
//Person [id=1234567890]
//Person [id=1234567890]