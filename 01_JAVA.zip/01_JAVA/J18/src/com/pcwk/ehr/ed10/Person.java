package com.pcwk.ehr.ed10;

public class Person {
	long id;//회원ID

	/**
	 * @param id
	 */
	public Person(long id) {
		super();
		this.id = id;
	}

	@Override
	public String toString() {
		return "Person [id=" + id + "]";
	}

	@Override
	public int hashCode() {
		//소수
		final int prime = 31;
		int result = 1;
		//id: hashcode추출
		result = prime * result + (int) (id ^ (id >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Person other = (Person) obj;
		if (id != other.id)
			return false;
		return true;
	}
	
//	@Override
//	public boolean equals(Object obj) {
//		if(null !=obj && obj instanceof Person) {
//			//id값으로 비교
//			return this.id == ((Person)obj).id;
//		}else {
//			return false;
//		}
//	}
	
	
	
}
