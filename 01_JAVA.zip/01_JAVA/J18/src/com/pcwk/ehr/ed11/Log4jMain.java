package com.pcwk.ehr.ed11;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class Log4jMain {

	static final Logger  LOG = LogManager.getLogger(Log4jMain.class);
	
	public static void main(String[] args) {
//		FATAL > ERROR > WARN > INFO > DEBUG > TRACE										
//		TRACE : 상세한 정보										
//		DEBUG : 상세한 일반 정보										
//		INFO : 일반 정보										
//		WARN : 주의										
//		ERROR : 일반에러										
//		FETAL : 치명적인 에러
		LOG.debug("debug");
		LOG.info("info");
		LOG.warn("warn");
		LOG.error("error");
		LOG.fatal("fatal");

	}

}
