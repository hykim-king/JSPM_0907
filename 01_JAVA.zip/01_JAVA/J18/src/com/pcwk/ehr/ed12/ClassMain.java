package com.pcwk.ehr.ed12;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class ClassMain {

	
	static final Logger LOG = LogManager.getLogger(ClassMain.class);
	
	public static void main(String[] args) throws InstantiationException, IllegalAccessException {
		Book c01=new Book("브라질에 비가 내리면 스타벅스 주식을 사라", 16_200);
		
		Book c02 = Book.class.newInstance();
		LOG.debug("c01:"+c01.toString());
		LOG.debug("c02:"+c02);//c02:Book [title=Java의 정석, price=30000]
		LOG.debug("======================");
		
		Class cObj =c01.getClass();
		LOG.debug("cObj.getName():"+cObj.getName());  //com.pcwk.ehr.ed12.Book
		LOG.debug("cObj.toString():"+cObj.toString());//class com.pcwk.ehr.ed12.Book
	}

}
//c01:Book [title=브라질에 비가 내리면 스타벅스 주식을 사라, price=16200]
//c02:Book [title=Java의 정석, price=30000]
//======================
//cObj.getName():com.pcwk.ehr.ed12.Book
//cObj.toString():class com.pcwk.ehr.ed12.Book