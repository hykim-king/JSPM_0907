package com.pcwk.ehr.ed01;

public class Ex01_HashCodeMain {

	public static void main(String[] args) {
		String str01=new String("abc");
		String str02=new String("abc");
		
		//String 클래스는 hashCode 데이터 기준으로 오버라이딩 되어 있음!
		System.out.println(str01.hashCode());
		System.out.println(str02.hashCode());
		
		System.out.println(str02.equals(str01));
		
		//Object의 hashCodec 처럼 객체의 주소값으로 해시코드를 생성: 서로 다른 해시코드
		System.out.println(System.identityHashCode(str01));
		System.out.println(System.identityHashCode(str02));
				
	}

}
