package com.pcwk.ehr.ed01;

import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;

public class Log4JMain {
    
	final static Logger LOG = LogManager.getLogger(Log4JMain.class);
    
	public static void main(String[] args) {
		LOG.debug("Log4j");

	}

}
