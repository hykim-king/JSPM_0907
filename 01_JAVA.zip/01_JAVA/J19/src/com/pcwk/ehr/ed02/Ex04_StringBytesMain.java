package com.pcwk.ehr.ed02;

import java.io.UnsupportedEncodingException;
import java.util.StringJoiner;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class Ex04_StringBytesMain {
	static final Logger LOG = LogManager.getLogger(Ex04_StringBytesMain.class);

	public static void main(String[] args) throws UnsupportedEncodingException {

		String str = "가";

		// OS default 인코딩으로 문자열 추출
		byte[] bArr = str.getBytes();// UTF-8 : 한글을 3byte로 표시

		byte[] bArr2 = str.getBytes("CP949");// CP949 한글을 2byte로 표시

		System.out.println("bArr:" + joinByteArray(bArr));//bArr:[EA:B0:80]
		System.out.println("bArr2:" + joinByteArray(bArr2));//bArr2:[B0:A1]
		
		// UTF-8,CP949 인코딩된 문자를 디코딩
		// 한글 깨지는 경우 : 서로 인코딩이 다른 경우
		System.out.println("CP949:"+new String(bArr2,"UTF-8"));//CP949:��
		System.out.println("UTF-8:"+new String(bArr,"CP949"));//UTF-8:媛¢
		
		System.out.println("CP949:"+new String(bArr2,"CP949"));//CP949:가
		System.out.println("UTF-8:"+new String(bArr,"UTF-8"));//UTF-8:가		
	}

	static String joinByteArray(byte[] bArr) {
		String str = "";
		StringJoiner sj = new StringJoiner(":", "[", "]");

		for (byte b : bArr) {

			sj.add(String.format("%02X", b));
		}
		str = sj.toString();
		return str;
	}

}
