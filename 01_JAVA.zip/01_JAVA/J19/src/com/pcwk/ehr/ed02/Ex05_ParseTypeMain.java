package com.pcwk.ehr.ed02;

public class Ex05_ParseTypeMain {

	public static void main(String[] args) {
		int age = 22;
		
		//int를 문자열
		String strAge = String.valueOf(age);
		//String strAge = age+"";
		
		//double을 문자열
		double dValues = 220.0;
		String strDouble = 220.0 +"";
		
		//문자열을 원래 타입(int,double)
		int paresAge = Integer.parseInt(strAge);
		
		dValues = Double.parseDouble(strDouble);
		
		System.out.println("paresAge:"+(paresAge+1));
		System.out.println("dValues:"+(dValues+1));

	}

}
//paresAge:23
//dValues:221.0