package com.pcwk.ehr.ed02;

public class Ex06_indexOf_substringMain {

	public static void main(String[] args) {
		String fullName = "Hello.java";
		
		int idx = fullName.indexOf(".");
		System.out.println("idx:"+idx);
		
		//Hello
		String fileName = fullName.substring(0, idx);//0<=x<5
		System.out.println("fileName:"+fileName);
		
		//java
		String ext = fullName.substring(idx+1);
		System.out.println("ext:"+ext);
		
		

	}

}
//idx:5
//fileName:Hello
//ext:java