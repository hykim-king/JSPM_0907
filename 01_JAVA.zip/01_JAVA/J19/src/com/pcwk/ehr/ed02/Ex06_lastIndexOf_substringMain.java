package com.pcwk.ehr.ed02;

public class Ex06_lastIndexOf_substringMain {

	public static void main(String[] args) {
		
		//파일 이름에 "."들어 갈수 있으므로 : 항상 뒤에서 부터 읽어야 한다.
		String fullName = "He.llo.java";
		
		int idx = fullName.lastIndexOf(".");
		System.out.println("idx:"+idx);
		
		//Hello
		String fileName = fullName.substring(0, idx);//0<=x<5
		System.out.println("fileName:"+fileName);
		
		//java
		String ext = fullName.substring(idx+1);
		System.out.println("ext:"+ext);
		
		
	}

}
//idx:6
//fileName:He.llo
//ext:java
