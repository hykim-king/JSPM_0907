package com.pcwk.ehr.ed02;

import com.pcwk.ehr.cmn.PLogger;

public class Ex07_StringBufferMain implements PLogger {

	
	public static void main(String[] args) {
		//thread safe: 속도는 StringBuilder에 비해 느리다.
		StringBuffer  sb=new StringBuffer();//16개 문자 저장
		LOG.debug("sb.capacity():"+sb.capacity());
		LOG.debug("sb.length():"+sb.length());

		
		sb.append("12345678901234567");
		//용량이 가득 차면 자동으로 capacity 증가된다.
		LOG.debug("sb.capacity():"+sb.capacity());
		LOG.debug("sb.length():"+sb.length());
		LOG.debug(sb.toString());
	}

}
