package com.pcwk.ehr.ed03;

import com.pcwk.ehr.cmn.PLogger;
import static java.lang.Math.*;

public class Ex11_Math implements PLogger {

	//절대값: abs()
	public static void pcwkAbs() {
		int x = -10;
		LOG.debug(Math.abs(x));//(a < 0) ? -a : a;
	}
	
	
	//max(x,y) 주어진 두값을 비교하여 큰쪽을 반환!
	//min(x,y) 주어진 두값을 비교하여 작은쪽을 반환!
	public static void pcwkMax() {
		int x = 14;
		int y = 12;
		LOG.debug("Math.max(x, y):"+Math.max(x, y));
		LOG.debug("Math.min(x, y):"+Math.min(x, y));
	}
	
	//(1,1) ~ (2,2)
//	Math.sqrt() : root
//	Math.sqrt( Math.pow((x2-x1),2) + Math.pow((y2-y1),2) )
	public void pcwkDistance() {
		int x1 = 1;
		int y1 = 1;
		
		int x2 = 2;
		int y2 = 2;
		
		//root
		LOG.debug(Math.sqrt(2));//1.4142135623730951
		LOG.debug(Math.pow(3, 2));//3에 2승
		
		double distance = Math.sqrt( Math.pow( (x2-x1), 2) +Math.pow( (y2-y1), 2) );
		System.out.println(distance);
		//double distance = 
	}
	
	public static void main(String[] args) {
		Ex11_Math eMain=new Ex11_Math();
		eMain.pcwkDistance();
		//pcwkAbs();
		//pcwkMax();
	}

}
//(Ex11_Math.java:11) - 10
//(Ex11_Math.java:20) - Math.max(x, y):14
//(Ex11_Math.java:21) - Math.min(x, y):12
