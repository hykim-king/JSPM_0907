package com.pcwk.ehr.ed04;

import java.math.BigDecimal;

public class BigDecimalEx {

	public static void main(String[] args) {
		// BigDecimal 객체 생성
		BigDecimal num1 = new BigDecimal("123.4567");
		BigDecimal num2 = new BigDecimal("2.0");

		// 더하기
		BigDecimal sum = num1.add(num2);
		System.out.println("덧셈 결과: " + sum);

		// 빼기
		BigDecimal difference = num1.subtract(num2);
		System.out.println("뺄셈 결과: " + difference);

		// 곱하기
		BigDecimal product = num1.multiply(num2);
		System.out.println("곱셈 결과: " + product);

		// 나누기 (반올림 모드 설정 가능)
		BigDecimal division = num1.divide(num2, 2, BigDecimal.ROUND_HALF_UP);
		System.out.println("나눗셈 결과: " + division);
	}
}
//덧셈 결과: 125.4567
//뺄셈 결과: 121.4567
//곱셈 결과: 246.91340
//나눗셈 결과: 61.73