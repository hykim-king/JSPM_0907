package com.pcwk.ehr.ed04;

import java.util.ArrayList;

public class Ex11_AutoBoxingUnboxingMain {

	public static void main(String[] args) {
		
		int i = 22;
		Integer iObj=new Integer(23);
		
		//unboxing
		int sum = i + iObj;//컴파일러가 다음 처럼 처리. i+iObj.intValue()
		System.out.println("sum:"+sum);//sum:45

		
		//Autoboxing
		ArrayList<Integer> list=new ArrayList<Integer>();
		list.add(10);//오토박싱 : 10 -> new Integer(10)
		
		//unboxing
		int value = list.get(0);//unboxing : new Integer(10) -> 10
		
	}

}
