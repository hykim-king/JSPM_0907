package com.pcwk.ehr.ed01;
import java.util.Calendar;

public class Ex04_CalendarAdd {

	public static void main(String[] args) {
		Calendar  cal=Calendar.getInstance();
		
		System.out.println(toDateString(cal));//2023년10월10

		//3일 후의 날짜 계산
		cal.add(Calendar.DATE, 3);//2023년10월13
		System.out.println(toDateString(cal));
		
		//6개월 후
		cal.add(Calendar.MONTH, 6);//2024년4월13
		System.out.println(toDateString(cal));
		
		//5개월 후
		cal.add(Calendar.MONTH, -5);//2023년11월13
		System.out.println(toDateString(cal));	
		
		//31이후 날짜 계산
		cal.add(Calendar.DATE,31);//2023년12월14
		System.out.println(toDateString(cal));
	}
	
	/**
	 * 형식에 맞춘 날짜 
	 * @param cal
	 * @return 2024년 11월30일
	 */
	public static String toDateString(Calendar  cal) {
		String formatDate = "";		
		formatDate = cal.get(Calendar.YEAR)+"년"+(cal.get(Calendar.MONTH)+1)+"월"+cal.get(Calendar.DAY_OF_MONTH);		
		return formatDate;
	}	

}
