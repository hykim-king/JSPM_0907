package com.pcwk.ehr.ed01;

import java.util.Calendar;

public class Ex05_01_Calendar5Week {

	/**
	 * 형식에 맞춘 날짜 
	 * @param cal
	 * @return 2024년 11월30일
	 */
	public static String toDateString(Calendar  cal) {
		String formatDate = "";		
		formatDate = cal.get(Calendar.YEAR)+"년"+(cal.get(Calendar.MONTH)+1)+"월"+cal.get(Calendar.DAY_OF_MONTH)+"일";				
		return formatDate;
	}
	
	public static void main(String[] args) {
		// 1. 년월일 입력 받기
		int year = 0;// 년도
		int month = 0;// 월

		try {
			String yearString = args[0];
			String monthString = args[1];

			//System.out.println("년도:" + yearString);
			//System.out.println("월:" + monthString);
			
			year = Integer.parseInt(yearString);
			month = Integer.valueOf(monthString);
		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("년도와 월을 입력 하세요.ex)2023 10");
			System.out.println(e.getMessage());
			// 프로그램 종료: 0이면 정상 종료, 그 외 값은 비정상 종료
			System.exit(0);
		}
		
		Calendar  sDay=Calendar.getInstance();//시작일
		Calendar  eDay=Calendar.getInstance();//종료일
		
		//시작일
		sDay.set(Calendar.YEAR, year);
		sDay.set(Calendar.MONTH, month-1);//Calendar 1월이 0부터 시작
		sDay.set(Calendar.DAY_OF_MONTH,1);//당월 1일
		
		System.out.println(toDateString(sDay));
		
		//종료일
		//그 달의 마지막일
		//시작일
		eDay.set(Calendar.YEAR, year);
		eDay.set(Calendar.MONTH, month-1);//Calendar 1월이 0부터 시작
			
		int lastDay = sDay.getActualMaximum(Calendar.DAY_OF_MONTH);		
		eDay.set(Calendar.DAY_OF_MONTH,lastDay);//당월 1일	
		//System.out.println(toDateString(eDay));
		
		
		String[] daysOfWeek = {"일","월","화","수","목","금","토"};
		
		//요일 출력
		for(String dayOfWeek:daysOfWeek) {
			System.out.print(dayOfWeek+"\t");
		}
		//line skip
		System.out.println();	
		
		//시작요일: 2023.10.01 시작요일
		int firstDayOfWeek=sDay.get(Calendar.DAY_OF_WEEK);
		//System.out.println("firstDayOfWeek:"+firstDayOfWeek);
		
		
		//before()메서드: 날짜시간 비교 이전이면 true 그렇치 않으면 false
		// {Calendar 개체}.before({비교대상})
		// {Calendar 개체}.after({비교대상})
		// {Calendar 개체}.equals({비교대상})
		
		//System.out.println(7-eDay.get(Calendar.DAY_OF_WEEK));

		
		eDay.add(Calendar.DATE, 7-eDay.get(Calendar.DAY_OF_WEEK));
		
		//System.out.println("5마지막 주차 :"+toDateString(eDay));//5마지막 주차 :2023년11월4
		//시작일(1)이 일요일이 아닌 경우 출력
		if(sDay.get(Calendar.DAY_OF_WEEK) != 1) {
			sDay.add(Calendar.DATE, -(firstDayOfWeek-1));
		}
		//System.out.println("지난달 전주차 :"+toDateString(sDay));
		for(int day=0;sDay.before(eDay)|| sDay.equals(eDay);sDay.add(Calendar.DATE, 1)) {
			day = sDay.get(Calendar.DATE);
			if(day<10) {
				System.out.print(" "+day+"\t");
			}else {
				System.out.print(day+"\t");	
			}
			
			if(sDay.get(Calendar.DAY_OF_WEEK) == 7) {
				System.out.println();
			}
		}
	}

}
