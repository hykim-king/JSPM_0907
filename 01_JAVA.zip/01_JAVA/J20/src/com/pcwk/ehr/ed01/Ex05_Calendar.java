package com.pcwk.ehr.ed01;

import java.util.Calendar;

public class Ex05_Calendar {
	/**
	 * 형식에 맞춘 날짜
	 * 
	 * @param cal
	 * @return 2024년 11월30일
	 */
	public static String toDateString(Calendar cal) {
		String formatDate = "";
		formatDate = cal.get(Calendar.YEAR) + "년" + (cal.get(Calendar.MONTH) + 1) + "월";
		return formatDate;
	}

	public static void main(String[] args) {
		// 1. 년월일 입력 받기
		int year = 0;// 년도
		int month = 0;// 월

		try {
			String yearString = args[0];
			String monthString = args[1];

			//System.out.println("년도:" + yearString);
			//System.out.println("월:" + monthString);
			
			year = Integer.parseInt(yearString);
			month = Integer.valueOf(monthString);
		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("년도와 월을 입력 하세요.ex)2023 10");
			System.out.println(e.getMessage());
			// 프로그램 종료: 0이면 정상 종료, 그 외 값은 비정상 종료
			System.exit(0);
		}
		
		
		//2. 시작요일에 시작일을 넣는다.
		//3. 그 달의 마지막일 : 28,29,30,31
		
		//Calendar객체 생성
		Calendar cal = Calendar.getInstance();
		
		//년도, 월, 일(1):set()
		cal.set(Calendar.YEAR, year);
		cal.set(Calendar.MONTH, month-1);//Calendar 1월이 0부터 시작
		cal.set(Calendar.DAY_OF_MONTH,1);//당월 1일
		
		//System.out.println(toDateString(cal));
		
		System.out.printf("%s\n",toDateString(cal));
		
		String[] daysOfWeek = {"일","월","화","수","목","금","토"};
		
		//요일 출력
		for(String dayOfWeek:daysOfWeek) {
			System.out.print(dayOfWeek+"\t");
		}
		//line skip
		System.out.println();		
		
		//시작요일: 2023.10.01 시작요일
		int firstDayOfWeek=cal.get(Calendar.DAY_OF_WEEK);
		//System.out.println("firstDayOfWeek:"+firstDayOfWeek);
		
		//첫 주 시작요일 까지 탭으로 출력
		for(int i=1;i<firstDayOfWeek;i++) {
			System.out.print("\t");
		}
		
		
		//그 달의 마지막일
		int lastDay = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
		for(int i=1;i<=lastDay;i++) {
			System.out.print(i+"\t");
			
			//토요일이면 줄바꿈
			if(firstDayOfWeek % 7 == 0) {
				System.out.println();
			}
			firstDayOfWeek++;
		}


	}

}
//2023년10월
//일	월	화	수	목	금	토	
//1	2	3	4	5	6	7	
//8	9	10	11	12	13	14	
//15	16	17	18	19	20	21	
//22	23	24	25	26	27	28	
//29	30	31	