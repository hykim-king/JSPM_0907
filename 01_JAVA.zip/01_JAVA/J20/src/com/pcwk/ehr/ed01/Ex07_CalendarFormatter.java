package com.pcwk.ehr.ed01;

import com.pcwk.ehr.cmn.PLogger;

import java.text.SimpleDateFormat;
import java.util.Date;
public class Ex07_CalendarFormatter implements PLogger {

	public static void main(String[] args) {
		//날짜 :Deprecated(앞으로 없어질 가능성이 있으니 가급적 사용하지 마시오.)
		Date date=new Date();
		//LOG.debug("date:"+date.toString());
		
		//날짜형식으로 출력
		SimpleDateFormat  dateFormat=new SimpleDateFormat("yyyy/MM/dd");
		LOG.debug("yyyy/MM/dd:"+dateFormat.format(date));//yyyy/MM/dd:2023/10/10
		
		SimpleDateFormat  dateFormat02=new SimpleDateFormat("yyyy-MM-dd");
		LOG.debug("yyyy-MM-dd:"+dateFormat02.format(date));//yyyy-MM-dd:2023-10-10	
		
		//시간
		SimpleDateFormat timeFormat=new SimpleDateFormat("HH:mm:ss");
		LOG.debug("HH:mm:ss=>"+timeFormat.format(date));//HH:mm:ss=>14:30:15
		
		//날짜및 시간
		SimpleDateFormat dateTimeFormat=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		LOG.debug("yyyy-MM-dd HH:mm:ss =>"+dateTimeFormat.format(date));//yyyy-MM-dd HH:mm:ss =>2023-10-10 14:31:23
		
		
	}

}
