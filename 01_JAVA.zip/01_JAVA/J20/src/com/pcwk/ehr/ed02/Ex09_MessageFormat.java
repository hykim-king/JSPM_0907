package com.pcwk.ehr.ed02;

import com.pcwk.ehr.cmn.PLogger;
import java.text.MessageFormat;
public class Ex09_MessageFormat implements PLogger {

	public static void main(String[] args) {
		//메시지 패턴 정의
		String pattern = "안녕하세요. {0}! 오늘은 뚜둥, {1} 입니다.";
		
		MessageFormat  messageFormat=new MessageFormat(pattern);
		
		//메시지 생성 및 변수 치환
		String name = "이인경님";
		String dayofWeek = "화요일";
		
		Object [] arguments = {name,dayofWeek};
		
		//메시지 출력
		LOG.debug(messageFormat.format(arguments));//안녕하세요. 이인경님! 오늘은 뚜둥, 화요일 입니다.
	}

}
