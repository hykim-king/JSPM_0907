package com.pcwk.ehr.ed01;

import java.time.LocalDate;
import java.time.LocalTime;

import com.pcwk.ehr.cmn.PLogger;

public class Ed01_LocalDateLocalTime implements PLogger {

	public static void main(String[] args) {
		LOG.debug("========================");
//		LocalDate	날짜(연도, 월, 일)를 나타내는 클래스
//		LocalTime	시간(시,분,초)을 나타내는 클래스
//		
//		객체 생성 : 
//			now() : 현재 날짜와 시간 생성
//			of() : 특정  날짜와 시간 생성
		
		LocalDate currentDate = LocalDate.now();//날짜(연도, 월, 일)를 나타내는 클래스
		LocalDate userDate = LocalDate.of(2023,12,31);
		
		LOG.debug("currentDate:"+currentDate.toString());//currentDate:2023-10-11
		LOG.debug("userDate:"+userDate);//월은 1(1월)~12
		LOG.debug("========================");
		
		LocalTime currentTime = LocalTime.now();//시간(시,분,초)을 나타내는 클래스
		LOG.debug("currentTime:"+currentTime);
		
		LocalTime userTime =  LocalTime.of(23, 58,1);//시간: 0~23, 분,초: 0~59
		LOG.debug("userTime:"+userTime);//userTime:23:58:01
		
		
	}

}
//========================
//currentDate:2023-10-11
//userDate:2023-12-31
//========================
//currentTime:09:36:46.919
//userTime:23:58:01
