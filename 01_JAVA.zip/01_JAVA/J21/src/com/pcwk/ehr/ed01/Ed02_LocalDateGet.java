package com.pcwk.ehr.ed01;

import com.pcwk.ehr.cmn.PLogger;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.temporal.ChronoField;

public class Ed02_LocalDateGet implements PLogger {

	public static void main(String[] args) {
//		ChronoField.YEAR: 연도를 나타내는 필드로, 날짜와 시간 객체에서 연도를 읽거나 설정할 때 사용됩니다.
//		ChronoField.MONTH_OF_YEAR: 월을 나타내는 필드로, 1부터 12까지의 값을 가집니다.
//		ChronoField.DAY_OF_MONTH: 한 달의 일을 나타내는 필드로, 1부터 31까지의 값을 가집니다.
//		ChronoField.HOUR_OF_DAY: 하루의 시간을 나타내는 필드로, 0부터 23까지의 값을 가집니다.
//		ChronoField.MINUTE_OF_HOUR: 시간의 분을 나타내는 필드로, 0부터 59까지의 값을 가집니다.
//		ChronoField.SECOND_OF_MINUTE: 분의 초를 나타내는 필드로, 0부터 59까지의 값을 가집니다.
//		ChronoField.NANO_OF_SECOND: 초의 나노초를 나타내는 필드로, 0부터 999,999,999까지의 값을 가집니다.
//		ChronoField.DAY_OF_WEEK: 주의 요일을 나타내는 필드로, 월요일부터 일요일까지의 값을 가집니다.
//		ChronoField.DAY_OF_YEAR: 연중 일 수를 나타내는 필드로, 1부터 365 또는 366까지의 값을 가집니다.
//		ChronoField.ERA: 연대(예: 기원 전, 기원 후)를 나타내는 필드로, ChronoField 상수 ERA의 값으로 음수와 양수를 구분합니다.		
		//현재 날짜와 시간
		LocalDate currentDate = LocalDate.now();
		
		
		//년, 월, 일 : getXXX()
		int year = currentDate.getYear();//year
		int month = currentDate.getMonthValue();//1 ~ 12. 
		int dayOfMonth = currentDate.getDayOfMonth();//1~31
		
		//요일: get(
		int dayOfWeek = currentDate.get(ChronoField.DAY_OF_WEEK);//1(월요일)~7(일요일)
		int chronoYear = currentDate.get(ChronoField.YEAR);
		LOG.debug("year:"+year);
		LOG.debug("chronoYear:"+chronoYear);
		LOG.debug("month:"+month);
		LOG.debug("dayOfMonth:"+dayOfMonth);
		LOG.debug("dayOfWeek:"+dayOfWeek);
		
		LOG.debug("========================");
		LocalTime currentTime = LocalTime.now();
		
		int hour = currentTime.getHour();//시간: 0~23
		int minute = currentTime.getMinute();//분: 0~59
		int second = currentTime.getSecond();//초: 0~59
		
		LOG.debug("hour:"+hour);
		LOG.debug("minute:"+minute);
		LOG.debug("second:"+second);
		
		int chronoHour  = currentTime.get(ChronoField.HOUR_OF_DAY);
		LOG.debug("chronoHour:"+chronoHour);
		int chronoNono  = currentTime.get(ChronoField.NANO_OF_SECOND);
		LOG.debug("chronoNono:"+chronoNono);
		
		
	}

}
//year:2023
//chronoYear:2023
//month:10
//dayOfMonth:11
//dayOfWeek:3
//========================
//hour:10
//minute:9
//second:11
//chronoHour:10
//chronoNono:875000000