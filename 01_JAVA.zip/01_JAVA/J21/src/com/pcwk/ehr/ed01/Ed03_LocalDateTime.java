package com.pcwk.ehr.ed01;

import com.pcwk.ehr.cmn.PLogger;
import java.time.LocalDateTime;
public class Ed03_LocalDateTime implements PLogger {

	public static void main(String[] args) {
		//현재 날짜와 시간 
		LocalDateTime currentDateTime = LocalDateTime.now();
		
		LOG.debug("현재 날짜와 시간 :"+currentDateTime.toString() );//현재 날짜와 시간 :2023-10-11T10:17:33.756
		
		//특정 날짜와 시간
		LocalDateTime customDateTime = LocalDateTime.of(2023, 12, 31, 23, 59, 59);
		LOG.debug("특정 날짜와 시간 :"+customDateTime);

		//문자열에서 LocalDateTime 파싱
		String dateTimeStr = "2023-12-31T23:59:59";
		
		LocalDateTime parsedDateTime = LocalDateTime.parse(dateTimeStr);
		LOG.debug("문자열에서 LocalDateTime 파싱 :"+parsedDateTime);
		
		// LocalDateTime연산 : plusXXX()
		//3일 2시간간 이후
		LocalDateTime futureDateTime = currentDateTime.plusDays(3).plusHours(2);
		LOG.debug("LocalDateTime연산 : plusXXX() :"+futureDateTime);
	}

}
//현재 날짜와 시간 :2023-10-11T10:23:43.539
//특정 날짜와 시간 :2023-12-31T23:59:59
//문자열에서 LocalDateTime 파싱 :2023-12-31T23:59:59
//LocalDateTime연산 : plusXXX() :2023-10-14T12:23:43.539
