package com.pcwk.ehr.ed01;
import java.time.ZonedDateTime;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;

import java.time.format.DateTimeFormatter;
public class Ex04_ZonedDateTime {

	public static void main(String[] args) {
		
		//현째 날짜와 시간대로 가져오기
		ZonedDateTime currentZonedDateTime = ZonedDateTime.now();
		System.out.println("현째 날짜와 시간대 :"+currentZonedDateTime);
		
		
		//특정 시간대로 설정하기
		ZoneId newYorkZone = ZoneId.of("America/New_York");
		ZonedDateTime customeZoneDateTime =  ZonedDateTime.now(newYorkZone);
		System.out.println("특정 시간대로 설정하기 :"+customeZoneDateTime);
		

	    //특정 날짜와 시간을 특정 시간대로 설정
		ZonedDateTime customeZonedDateTime =ZonedDateTime.of( LocalDate.now(), 
				                          LocalTime.now(), ZoneId.of("Asia/Seoul"));
		
		System.out.println("특정 날짜와 시간을 특정 시간대로 설정 :"+customeZonedDateTime);
		
		//날짜 및 시간 형식 지정: yyyy-MM-dd HH:mm:ss z
		DateTimeFormatter  formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss Z");
		String formattedDateTime = customeZonedDateTime.format(formatter);
		System.out.println("날짜 및 시간 형식 지정: yyyy-MM-dd HH:mm:ss Z:"+formattedDateTime);
				
		
	}

}
//현째 날짜와 시간대 :2023-10-11T10:44:54.508+09:00[Asia/Seoul]
//특정 시간대로 설정하기 :2023-10-10T21:44:54.510-04:00[America/New_York]
//특정 날짜와 시간을 특정 시간대로 설정 :2023-10-11T10:44:54.517+09:00[Asia/Seoul]
//날짜 및 시간 형식 지정: yyyy-MM-dd HH:mm:ss :2023-10-11 10:44:54 +0900