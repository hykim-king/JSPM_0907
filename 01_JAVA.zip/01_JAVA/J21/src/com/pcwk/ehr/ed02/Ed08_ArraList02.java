package com.pcwk.ehr.ed02;

import com.pcwk.ehr.cmn.PLogger;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Ed08_ArraList02 implements PLogger {
	/**
	 * List 내용을 콘솔에 출력
	 * @param list
	 */
	public static void dispList(List<String> list) {
		for(String str :list) {
			LOG.debug(str);
		}
	}
	
	public static void main(String[] args) {
		List nameList=new ArrayList();
		
		int cnt = 0;//김씨 인원 count
		
		
		Scanner scanner=new Scanner(System.in);
		while(nameList.size() !=5) {
			System.out.print("이름을 입력 하세요>");
			
			String name = scanner.nextLine();
			
			nameList.add(name);
			LOG.debug(name);
		}
		
		//ArrayList에 들어 있는 데이터 출력: 입력된 순서대로 출력 됨
		dispList(nameList);
		
		
		for(int i=0;i<nameList.size();i++) {
			String findName = (String) nameList.get(i);
			
			//이름 중 김씨 성을 가진 사람
			if(findName.startsWith("김")) {
				cnt++;
				System.out.println("findName:"+findName);
			}
		}
		LOG.debug("김씨 성을 가진 사람은 "+cnt+"명 입니다.");
	}

}
//이름을 입력 하세요>이상무
//[2023-10-11 12:46:23] DEBUG Ed08_ArraList02.main(Ed08_ArraList02.java:32) - 이상무
//이름을 입력 하세요>김지우
//[2023-10-11 12:46:27] DEBUG Ed08_ArraList02.main(Ed08_ArraList02.java:32) - 김지우
//이름을 입력 하세요>박성욱
//[2023-10-11 12:46:32] DEBUG Ed08_ArraList02.main(Ed08_ArraList02.java:32) - 박성욱
//이름을 입력 하세요>김진수
//[2023-10-11 12:46:36] DEBUG Ed08_ArraList02.main(Ed08_ArraList02.java:32) - 김진수
//이름을 입력 하세요>송레오
//[2023-10-11 12:46:40] DEBUG Ed08_ArraList02.main(Ed08_ArraList02.java:32) - 송레오
//[2023-10-11 12:46:40] DEBUG Ed08_ArraList02.dispList(Ed08_ArraList02.java:15) - 이상무
//[2023-10-11 12:46:40] DEBUG Ed08_ArraList02.dispList(Ed08_ArraList02.java:15) - 김지우
//[2023-10-11 12:46:40] DEBUG Ed08_ArraList02.dispList(Ed08_ArraList02.java:15) - 박성욱
//[2023-10-11 12:46:40] DEBUG Ed08_ArraList02.dispList(Ed08_ArraList02.java:15) - 김진수
//[2023-10-11 12:46:40] DEBUG Ed08_ArraList02.dispList(Ed08_ArraList02.java:15) - 송레오
//findName:김지우
//findName:김진수
