package com.pcwk.ehr.ed02;
import java.util.LinkedList;
import java.util.List;

public class Ed10_LinkedList {

	/**
	 * LinkedList에 들어 있는 전체 요소 출력 
	 * @param list
	 */
	public static void dispLinkedList(List<String> list) {
		for(String str :list) {
			System.out.println(str);
		}
	}
	
	public static void main(String[] args) {
		
		LinkedList<String>  linkedList=new LinkedList<String>();
		
		//요소 추가
		linkedList.add("Java");
		linkedList.add("Oracle SQL");
		linkedList.add("Html");
		linkedList.add("CSS");
		linkedList.add("Javascript");
		linkedList.add("Spring");
		System.out.println("요소 추가");
		dispLinkedList(linkedList);
		System.out.println("==============================");
		//요소의 개수 출력
		System.out.println("요소의 개수: "+linkedList.size());
		
		
		//요소 출력
		System.out.println("첫 번째 요소: "+linkedList.get(0));
		System.out.println("6 번째 요소: "+linkedList.get(5));
		
		//요소 수정
		linkedList.set(5,"Spring Boot");
		System.out.println(" 6 번째 요소 요소 수정: "+linkedList.get(5));
		System.out.println("요소 수정");
		dispLinkedList(linkedList);
		System.out.println("==============================");
		
		//요소 삭제
		linkedList.remove(3);
		System.out.println("요소 삭제");
		dispLinkedList(linkedList);
		System.out.println("==============================");
		
		//전체 요소 출력
		for(String str :linkedList) {
			System.out.println(str);
		}
	}

}
//요소 추가
//Java
//Oracle SQL
//Html
//CSS
//Javascript
//Spring
//==============================
//요소의 개수: 6
//첫 번째 요소: Java
//6 번째 요소: Spring
// 6 번째 요소 요소 수정: Spring Boot
//요소 수정
//Java
//Oracle SQL
//Html
//CSS
//Javascript
//Spring Boot
//==============================
//요소 삭제
//Java
//Oracle SQL
//Html
//Javascript
//Spring Boot
//==============================
//Java
//Oracle SQL
//Html
//Javascript
//Spring Boot
