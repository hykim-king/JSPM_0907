package com.pcwk.ehr.ed02;

import com.pcwk.ehr.cmn.PLogger;
import java.util.*;

public class Ed11_ArrayListVSLinkedList implements PLogger {
	/**
	 * 순차적인 추가
	 * @param list
	 * @return
	 */
	public static long sequentialAdd(List list) {
		long start = System.currentTimeMillis();
		
		for(int i=0;i<1_000_000;i++) {
			list.add(i+"");
		}
		
		long end = System.currentTimeMillis();
		
		return end - start;
	}
	
	/**
	 * 중간에 추가
	 * @param list
	 * @return long
	 */
	public static long middleAdd(List list) {
		long start = System.currentTimeMillis();
		
		for(int i=0;i<10_000;i++) {
			list.add(99, i+"");//list 99번째에 데이터 추가
		}
		
		long end = System.currentTimeMillis();
		
		return end - start;
	}	
	
	//삭제:List 계열의 삭제는 마지막 부터 삭제
	public static long removeList(List list) {
		long start = System.currentTimeMillis();
// 앞에서 부터 순차적으로 삭제시 원하는 방향으로 삭제 않됨
//		for(int i=0;i<100;i++) {
//			list.remove(i);
//		}
		
		for(int i=list.size()-1;i>=0;i--) {
			list.remove(i);
		}
		
		long end = System.currentTimeMillis();
		
		return end - start;
	}	
	
	public static void main(String[] args) {
		//순차적인 추가 삭제
		ArrayList arrayList=new ArrayList();
		LinkedList linkedList=new LinkedList();
		
		//the current time in milliseconds
		//System.out.println(""+System.currentTimeMillis());
		LOG.debug("순차적인 추가");
		LOG.debug("arrayList:"+sequentialAdd(arrayList));
		LOG.debug("linkedList:"+sequentialAdd(linkedList));
		
		LOG.debug("===================================");
		LOG.debug("중가에 추가");
		LOG.debug("arrayList:"+middleAdd(arrayList));
		LOG.debug("linkedList:"+middleAdd(linkedList));		
		
		LOG.debug("===================================");
		LOG.debug("삭제 추가");
		LOG.debug("arrayList:"+removeList(arrayList));
		LOG.debug("linkedList:"+removeList(linkedList));
		//LOG.debug("arrayList:"+arrayList);
	}

}
// 순차적인 추가
// arrayList:99
// linkedList:702
// ===================================
// 중가에 추가
// arrayList:1402
// linkedList:4
// ===================================
// 삭제 추가
// arrayList:6
// linkedList:27