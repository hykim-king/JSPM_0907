package com.pcwk.ehr.ed02;

import java.util.Stack;

import com.pcwk.ehr.cmn.PLogger;

public class Ed12_Stack implements PLogger {

	public static void printStack(Stack<String> stack) {
		while (!stack.empty()) {
			LOG.debug(stack.pop());// stack에서 제거
		}
	}

	public static void main(String[] args) {
		Stack<String> stack = new Stack<String>();

		// 요소 추가
		stack.push("JAVA");
		stack.push("DATABASE");
		stack.push("HTML");
		stack.push("CSS");
		stack.push("JAVASCRIPT");
		stack.push("JSP");
		stack.push("SPRING");
		LOG.debug("요소 추가");

		// 요소 추출
		LOG.debug("요소 추출:" + stack.pop());

		// 요소 추출 : stack에서 제거 하지 않음
		LOG.debug("요소 추출 peek:" + stack.peek());

		// stack이 비어 있는지 여부 확인
		LOG.debug("stack이 비어 있는지 여부 empty:" + stack.empty());

		// 요소찾기
		LOG.debug("요소찾기 search:" + stack.search("DATABASE"));// 요소찾기 search:5

		// 전체요소 출력
		printStack(stack);
	}

}
// 요소 추가
// 요소 추출:SPRING
// 요소 추출 peek:JSP
// stack이 비어 있는지 여부 empty:false
// 요소찾기 search:5
// JSP
// JAVASCRIPT
// CSS
// HTML
// DATABASE
// JAVA
