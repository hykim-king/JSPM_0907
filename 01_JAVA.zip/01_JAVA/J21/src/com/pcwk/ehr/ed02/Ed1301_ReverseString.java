package com.pcwk.ehr.ed02;

import java.util.Stack;

public class Ed1301_ReverseString {

    public static String reverseString(String input) {
        Stack<Character> stack = new Stack<>();

        // 문자열의 각 문자를 스택에 넣음
        for (char c : input.toCharArray()) {
            stack.push(c);
        }

        // 스택에서 문자를 꺼내면 역순으로 된 문자열이 생성됨
        StringBuilder reversed = new StringBuilder();
        while (!stack.isEmpty()) {
            reversed.append(stack.pop());
        }

        return reversed.toString();
    }

    public static void main(String[] args) {
        String original = "Hello, World!";
        String reversed = reverseString(original);
        System.out.println("원본 문자열: " + original);
        System.out.println("역순 문자열: " + reversed);
    }
}
