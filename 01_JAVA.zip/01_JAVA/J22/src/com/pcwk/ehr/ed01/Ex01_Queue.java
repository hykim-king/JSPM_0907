package com.pcwk.ehr.ed01;

import com.pcwk.ehr.cmn.PLogger;
import java.util.*;

public class Ex01_Queue implements PLogger {

	public static void main(String[] args) {
		LOG.debug("좋은 아침!");
		
		Queue<Integer>  queue=new LinkedList<Integer>();
		
		//큐에 추가
		queue.offer(17);
		queue.offer(14);
		queue.offer(12);
		queue.add(22);
		queue.add(18);
		
		LOG.debug("queue:"+queue);
		
		//큐에 값 추출
		LOG.debug("큐에 값 추출(poll):"+queue.poll());
		
		LOG.debug("큐에 값 추출(peek):"+queue.peek());
		
		LOG.debug("queue:"+queue);
		
		while(!queue.isEmpty()) {
			LOG.debug(queue.poll());
		}
		
		
		
	}

}
//좋은 아침!
//queue:[17, 14, 12, 22, 18]
//큐에 값 추출(poll):17
//큐에 값 추출(peek):14
//queue:[14, 12, 22, 18]
//14
//12
//22
//18