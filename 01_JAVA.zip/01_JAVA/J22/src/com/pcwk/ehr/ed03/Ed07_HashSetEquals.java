package com.pcwk.ehr.ed03;

import java.util.HashSet;

public class Ed07_HashSetEquals {

	public static void main(String[] args) {
		HashSet  set=new HashSet();
		
		Person p01=new Person("Alice", 21);
		Person p02=new Person("Alice", 21);
		
		set.add("java");
		set.add("java");
		
		set.add(p01);
		set.add(p02);
		
		System.out.println(set);

	}

}
//[java, Person [name=Alice, age=21], Person [name=Alice, age=21]]
