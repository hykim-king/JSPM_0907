package com.pcwk.ehr.ed04;

import java.util.HashSet;

public class Ed08_HashSetEquals {

	public static void main(String[] args) {
		HashSet  set=new HashSet();
		
		Person p01=new Person("Alice", 21);
		Person p02=new Person("Alice", 21);
		
		set.add("java");
		set.add("java");
		
		set.add(p01);
		set.add(p02);
		
		System.out.println(set);

	}

}
//equals(),hashCode()로 참조형 변수의 도일성 체크
//[java, Person [name=Alice, age=21]]
