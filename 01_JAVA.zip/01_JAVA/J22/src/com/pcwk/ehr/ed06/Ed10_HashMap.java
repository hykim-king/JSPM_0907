package com.pcwk.ehr.ed06;

import java.util.HashMap;
import java.util.Iterator;

public class Ed10_HashMap {

	public static void main(String[] args) {
		// HashMap 객체 생성
		HashMap<String, Integer> map = new HashMap<String, Integer>();

		// HashMap에 데이터 추가(key, value)
		map.put("one", 1);
		map.put("two", 2);
		map.put("three", 3);
		map.put("four", 4);
		map.put("five", 5);

		map.put("three", 33);
		System.out.println("map:" + map);

		// key로 값 추출
		System.out.println("key로 값 추출:" + map.get("two"));

		// key존재 유무
		System.out.println("key존재 유무 :" + map.containsKey("two"));
		System.out.println("=================================================");
		// 모든 요소에 접근
		Iterator iter = map.keySet().iterator();

		while (iter.hasNext() == true) {
			String key = (String) iter.next();// key
			Integer value = map.get(key);// value

			System.out.printf("key=%s, value=%d\n", key, value);
		}

	}

}
//map:{four=4, one=1, two=2, three=33, five=5}
//key로 값 추출:2
//key존재 유무 :true
//=================================================
//key=four, value=4
//key=one, value=1
//key=two, value=2
//key=three, value=33
//key=five, value=5
