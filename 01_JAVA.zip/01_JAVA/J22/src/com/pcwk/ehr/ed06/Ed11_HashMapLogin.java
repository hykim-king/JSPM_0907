package com.pcwk.ehr.ed06;

import java.util.HashMap;
import java.util.Scanner;

public class Ed11_HashMapLogin {

	public static void main(String[] args) {
		// ID/비번을 HashMap에 저장 이를 이용해 ID로 비번 비교!
		HashMap<String, String> map=new HashMap<String, String>();
		
		map.put("myId", "1234");
		map.put("jamesol", "4321");
		map.put("abc", "1234");
		
		//scanner통해 : ID와 비번을 입력 비교
		Scanner scanner=new Scanner(System.in);
		
		while(true) {
			System.out.println("id와 비번을 입력 하세요.");
			System.out.print("id:");
			
			String id = scanner.next().trim();
			
			System.out.print("password:");
			
			String password = scanner.next().trim();
			
			if(map.containsKey(id)==false) {//id가 없으며
				System.out.println("입력 하신 id는 존재 하지 않습니다. 다시 입력해 주세요.");
				continue;
			}else {
				
				if(map.get(id).equals(password)==false) {
					System.out.println("비번을 확인 하세요. 다시 입력해 주세요.");
				}else {
					System.out.println("id와 비번이 일치 합니다.");
					break;
				}
				
			}
			
			
		}
		
		System.out.println("로그인 되었습니다.");
		scanner.close();
	}

}
