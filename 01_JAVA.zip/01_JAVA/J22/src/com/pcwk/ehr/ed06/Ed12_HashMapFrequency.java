package com.pcwk.ehr.ed06;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

public class Ed12_HashMapFrequency {

	/**
	 * value 수만 큼 # 출력
	 * @param ch
	 * @param value
	 * @return  value 수만 큼 # 문자열
	 */
	public static String printShap(char ch, int value) {
		char[] bar=new char[value];
		
		for(int i=0;i<bar.length;i++) {
			bar[i]=ch;
		}
		
		return new String(bar);
	}
	public static void main(String[] args) {
		String [] data = {"A","K","A","K","D","K","Z"};
		// A : ## 2
		// D : # 1
		// K : ### 3
		// Z : # 1
		
		
		HashMap<String, Integer>  map=new HashMap<String, Integer>();
		
		for(String str  :data) {
			//기존 키가 있는 경우
			if(map.containsKey(str)) {
				Integer value=map.get(str);
				map.put(str, value+1);
			}else {//최초 추가
				map.put(str, new Integer(1));
			}
		}
		
		System.out.println(map);
		
		//entrySet: key,value모두 가지고 있음
		Iterator<Entry<String, Integer>> iter = map.entrySet().iterator();
		
		while(iter.hasNext()) {
			//key,value
			Map.Entry  entry = iter.next();
			
			int value = ((Integer)entry.getValue()).intValue();
			String key   = (String) entry.getKey();
			//System.out.printf("key=%s, value=%d\n",key,value);
			System.out.println(key +":"+ printShap('#',value)+ " "+value);
		}
		
		

	}

}




