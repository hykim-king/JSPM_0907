package com.pcwk.ehr.ed06;

import java.util.Map;
import java.util.TreeMap;

public class Ed14_TreeMapFrequency {

	public static void dispStringArray(String []words) {
		for(String word :words) {
			System.out.println(word);
		}
	}
	
	
	public static void main(String[] args) {
		//텍스트 문자열
		String text = "A Red-Black tree based NavigableMap implementation. The map is sorted according to the natural ordering of its keys, or by a Comparator provided at map creation time, depending on which constructor is used.";
//		text += "This implementation provides guaranteed log(n) time cost for the containsKey, get, put and remove operations. Algorithms are adaptations of those in Cormen, Leiserson, and Rivest's Introduction to Algorithms." + 
//				"Note that the ordering maintained by a tree map, like any sorted map, and whether or not an explicit comparator is provided, must be consistent with equals if this sorted map is to correctly implement the Map interface. (See Comparable or Comparator for a precise definition of consistent with equals.) This is so because the Map interface is defined in terms of the equals operation, but a sorted map performs all key comparisons using its compareTo (or compare) method, so two keys that are deemed equal by this method are, from the standpoint of the sorted map, equal. The behavior of a sorted map is well-defined even if its ordering is inconsistent with equals; it just fails to obey the general contract of the Map interface.";
//		
		
		//TreeMap을 이용한 단어 빈도수 구하기
		TreeMap<String, Integer> wordFrequency=new TreeMap<String, Integer>();
		
		//공백 문자를 기준으로 단어 분리
		String[] words = text.split(" ");
		//dispStringArray(words);
		
		for(String word :words) {
			//정규식: [^a-z-] => [^a-z] :^소문자 전체 => 소문자 제외
			String cleanWord = word.toLowerCase().replaceAll("[^a-z-]", "");
			//System.out.println(cleanWord);
			if(wordFrequency.containsKey(cleanWord) ) {
				Integer value = wordFrequency.get(cleanWord);
				wordFrequency.put(cleanWord, value+1);
			}else {
				wordFrequency.put(cleanWord, new Integer(1));
			}
			
		}
		
		//System.out.println(wordFrequency);
		
		for(Map.Entry<String, Integer> entry :wordFrequency.entrySet()) {
			String word = entry.getKey();
			int    value= entry.getValue();
			System.out.println(word+": "+value);
		}
		
		
	}

}
//a: 2
//according: 1
//at: 1
//based: 1
//by: 1
//comparator: 1
//constructor: 1
//creation: 1
//depending: 1
//implementation: 1
//is: 2
//its: 1
//keys: 1
//map: 2
//natural: 1
//navigablemap: 1
//of: 1
//on: 1
//or: 1
//ordering: 1
//provided: 1
//red-black: 1
//sorted: 1
//the: 2
//time: 1
//to: 1
//tree: 1
//used: 1
//which: 1
