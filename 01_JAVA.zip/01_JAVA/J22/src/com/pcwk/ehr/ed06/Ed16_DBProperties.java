package com.pcwk.ehr.ed06;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class Ed16_DBProperties {

	public static void main(String[] args) {
		Properties  properties=new Properties();
		
		FileInputStream fileInput = null;
		
		String filePath = "C:\\JSPM_0907\\01_JAVA\\WORKSPACE\\J22\\src\\com\\pcwk\\ehr\\ed06\\db_config.properties";
		
		try {
			fileInput = new FileInputStream(filePath);
			
			properties.load(fileInput);
		} catch (FileNotFoundException e) {
			System.out.println("FileNotFoundException");
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println("IOException");
			e.printStackTrace();
		}finally {
			if(null != fileInput) {
				try {
					fileInput.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		
		String dbUserName = properties.getProperty("db.username");
		String dbPassword = properties.getProperty("db.password");//
		String dbURL = properties.getProperty("db.url");
		
		System.out.println("dbUserName:"+dbUserName);
		System.out.println("dbUserName:"+dbUserName);
		System.out.println("dbURL:"+dbURL);

	}

}
