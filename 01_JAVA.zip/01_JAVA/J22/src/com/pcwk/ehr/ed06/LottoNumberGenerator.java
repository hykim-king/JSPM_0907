package com.pcwk.ehr.ed06;

import java.util.Set;
import java.util.TreeSet;

public class LottoNumberGenerator {

	public static void main(String[] args) {
		Set<Integer> lottoNumbers = new TreeSet<>();

		while (lottoNumbers.size() < 6) {
			int randomNumber = (int) (Math.random() * 45) + 1;// 1에서 45 사이의 난수 생성
			lottoNumbers.add(randomNumber);
		}

		System.out.println("로또 번호 (오름차순 정렬):");
		for (int number : lottoNumbers) {
			System.out.print(number + " ");
		}
	}
}
//로또 번호 (오름차순 정렬):
//2 12 15 25 35 44 
//7 16 25 31 32 37 