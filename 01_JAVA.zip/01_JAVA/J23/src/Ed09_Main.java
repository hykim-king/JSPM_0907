
public class Ed09_Main {

	@SuppressWarnings("deprecation")
	public static void main(String[] args) {
		Ed09_Deprecated dep=new Ed09_Deprecated();
		
		dep.oldAge = 23;
		
		System.out.println(dep.getOldAge());
		
	}

}
