package com.pcwk.ehr.ed01;

public class Box<T> {
	private T content;
	
	
	public Box() {}
	public Box(T t) {
		this.content = t;
	}

	/**
	 * @return the content
	 */
	public T getContent() {
		return content;
	}

	/**
	 * @param content the content to set
	 */
	public void setContent(T content) {
		this.content = content;
	}
	
	
}
