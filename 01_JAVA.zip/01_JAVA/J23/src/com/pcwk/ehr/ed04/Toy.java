package com.pcwk.ehr.ed04;

public class Toy {

	@Override
	public String toString() {
		return "Toy";
	}

}
