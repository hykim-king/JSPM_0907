package com.pcwk.ehr.ed05;

public class Ed05_WildCard {

	public static void main(String[] args) {
		FruitBox<Fruit> fruitBox=new FruitBox<Fruit>();
		
		fruitBox.add(new Apple());
		fruitBox.add(new Grape());
		
		
		System.out.println(Juicer.makeJuice(fruitBox));
		System.out.println("==========================");
		FruitBox<Apple> appleBox=new FruitBox<Apple>();
		appleBox.add(new Apple());
		appleBox.add(new Apple());
		//appleBox.add(new Grape());
		System.out.println(Juicer.makeJuice(appleBox));
	}

}
