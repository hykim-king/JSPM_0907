package com.pcwk.ehr.ed05;

public class Fruit{

	@Override
	public String toString() {
		return "Fruit";
	}

}
