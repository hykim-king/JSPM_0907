package com.pcwk.ehr.ed05;

public class Juicer {

	static Juice makeJuice(FruitBox<? extends Fruit> box) {
		String temp = "";
		
		for(Fruit f :box.getList()) {
			temp += f.toString()+ " ";
		}
		
		return new Juice(temp);
	}
	
	
}
