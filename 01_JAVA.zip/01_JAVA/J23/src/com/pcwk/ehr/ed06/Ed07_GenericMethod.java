package com.pcwk.ehr.ed06;

import java.util.Arrays;

public class Ed07_GenericMethod {

	//배열의 두수의 자리 변경:Integer,String
	
	/**
	 * 배열의 두수의 자리 변경:Integer,String
	 * @param <T>
	 * @param arr
	 * @param i
	 * @param j
	 */
	public static <T> void swap(T[] arr, int i, int j) {
		T temp = arr[i];
		arr[i] = arr[j];
		arr[j] = temp;
	}
	
	public static void main(String[] args) {
		Integer [] intArr= {1,2};
		System.out.println(Arrays.toString(intArr));
		swap(intArr,0,1);
		
		System.out.println(Arrays.toString(intArr));

		
		String[] strArr= {"Hello","world"};
		swap(strArr,0,1);
		System.out.println(Arrays.toString(strArr));
		
	}

}
//[1, 2]
//[2, 1]
//[world, Hello]