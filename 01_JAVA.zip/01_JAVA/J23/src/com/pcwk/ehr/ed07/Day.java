package com.pcwk.ehr.ed07;

public enum Day {

	SUNDAY, MONDAY, TUESDAY,WEDNESDAY,THURSDAY, FRIDAY, SATURDAY
	
}
