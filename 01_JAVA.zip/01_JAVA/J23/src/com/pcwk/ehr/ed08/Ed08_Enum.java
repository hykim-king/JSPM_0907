package com.pcwk.ehr.ed08;

public class Ed08_Enum {

	public static void main(String[] args) {
		TrafficSignal signal = TrafficSignal.RED;
		
		System.out.println("signal:"+signal);
		System.out.println("action:"+signal.getAction());

	}

}
//signal:RED
//action:Stop