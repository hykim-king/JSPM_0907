package com.pcwk.ehr.ed08;

public enum TrafficSignal {

	//RED     -> stop
	//GREEN   -> go
	//YELLOW  -> Slow down
	RED("Stop"),GREEN("Go"),YELLOW("Slow down");
	
	private String action;
	
	TrafficSignal(String action){
		this.action = action;
	}
	
	public String getAction() {
		return action;
	}
}
