package com.pcwk.ehr.ed09;

public class Parent {

	void parentMethod() {
		
	}
}
