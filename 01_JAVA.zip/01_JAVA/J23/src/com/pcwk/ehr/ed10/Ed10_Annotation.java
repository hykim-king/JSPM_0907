package com.pcwk.ehr.ed10;

import java.lang.reflect.Method;

public class Ed10_Annotation {
	//리플렉션을 통해서 애너테이션 정보를 읽어 올수 있다.
	public static void main(String[] args) 
			throws NoSuchMethodException, SecurityException {
		
		Class<MyClass> myCLass=MyClass.class;
		//myMethod()에 접근
		Method method = myCLass.getMethod("myMethod");
		
		MyAnnotaion annotation = method.getAnnotation(MyAnnotaion.class);
		
		if(null != annotation) {
			System.out.println("애너테이션 값:"+annotation.value());
		}else {
			System.out.println("애너테이션이 존재하지 않습니다.");
		}
	}

}
//애너테이션 값:애너테이션 테스트