package com.pcwk.ehr.ed02;

public class Ed02_Main {

	public static void main(String[] args) {
		Ed02_Thread edThread=new Ed02_Thread();
		
		//JVM이 run()메서드 호출 함.
		edThread.start();
	}

}
