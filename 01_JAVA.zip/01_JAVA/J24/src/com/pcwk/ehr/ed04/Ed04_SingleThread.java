package com.pcwk.ehr.ed04;

public class Ed04_SingleThread {

	public static void main(String[] args) {
		//싱글쓰레드로 프로그래밍 수행
		
		long startTime = System.currentTimeMillis();
		
		for(int i=0;i<300;i++) {
			System.out.printf("%s",new String("-"));
		}
		long endTime  = System.currentTimeMillis();
		System.out.println("소요시간 1:"+(endTime-startTime));
		
		for(int i=0;i<300;i++) {
			System.out.printf("%s",new String("|"));
		}		
		
		endTime  = System.currentTimeMillis();
		System.out.println("소요시간 2:"+(endTime-startTime));		
	}

}
