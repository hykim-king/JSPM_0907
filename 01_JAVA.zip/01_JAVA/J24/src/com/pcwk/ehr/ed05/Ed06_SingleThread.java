package com.pcwk.ehr.ed05;

import javax.swing.JOptionPane;

public class Ed06_SingleThread {

	public static void main(String[] args) {
		//하나의 스레드로 사용자의 입력을 받는 로직과, 숫자를 출력하는 프로그램이 순차적으로 수행 된다.
		String input = JOptionPane.showInputDialog("점심 메뉴를 입력 하세요.");
		System.out.println("input:"+input);

		for(int i=10;i>0;i--) {
			System.out.println(i);
			
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				System.out.println("InterruptedException:"+e.getMessage());
				e.printStackTrace();
			}
		}
		System.out.println("프로그램 종료!");
	}

}
