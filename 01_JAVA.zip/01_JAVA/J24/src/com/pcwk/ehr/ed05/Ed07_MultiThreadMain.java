package com.pcwk.ehr.ed05;

import javax.swing.JOptionPane;

public class Ed07_MultiThreadMain {

	public static void main(String[] args) {
		
		MultiThread mTh=new MultiThread();

		
		mTh.start();
		
		String input = JOptionPane.showInputDialog("점심 메뉴 입력");
		System.out.println("입력 하신 값은 "+input+" 입니다.");
	}

}
