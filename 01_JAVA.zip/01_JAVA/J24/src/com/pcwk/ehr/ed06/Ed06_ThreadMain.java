package com.pcwk.ehr.ed06;

public class Ed06_ThreadMain {

	public static void main(String[] args) {
		Thread6_01 th01=new Thread6_01();
		Thread6_02 th02=new Thread6_02();
		
		th02.setPriority(7);//쓰레드를 수행하기전 우선 순위 부여
		//Thread6_02 우선 순위가 높으므로 : Thread6_01에 비해 더 많은 양의 실행시간이 주어 진다.
		System.out.println("Thread6_01(-):"+th01.getPriority());
		System.out.println("Thread6_02(|):"+th01.getPriority());
		
		th01.start();
		th02.start();

	}

}
