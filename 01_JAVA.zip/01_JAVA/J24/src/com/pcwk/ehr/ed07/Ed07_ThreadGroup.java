package com.pcwk.ehr.ed07;

public class Ed07_ThreadGroup {

	static class MyRunnable implements Runnable{

		@Override
		public void run() {
			
			System.out.println("스레스가 실행 중: "+Thread.currentThread().getName());
			
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				System.out.println("InterruptedException:"+e.getMessage());
			}
		}

		
	}
	
	public static void main(String[] args) {
		ThreadGroup  parentGroup=new ThreadGroup("부모 그룹");
		
		//스레드 그룹에 속한 스레드 생성
		Thread thread01=new Thread(parentGroup, new MyRunnable(), "스레드-1");
		Thread thread02=new Thread(parentGroup, new MyRunnable(), "스레드-2");
		
		
		//스레드 시작
		thread01.start();
		thread02.start();
		
		//스레드 그룹 내의 스레드 목록 출력
		parentGroup.list();
		
		
		//스레드 그룹 내의 활성 스레드 수 출력
		int activeCountThreadCount= parentGroup.activeCount();
		System.out.println("활성 스레드 수: "+activeCountThreadCount);
		
		
		//스레드 그룹 내의 스레드 그룹 목록 출력
		ThreadGroup[] threadGroups=new ThreadGroup[parentGroup.activeGroupCount()];
		parentGroup.enumerate(threadGroups,true);
		
		System.out.println("스레드 그룹 목록:");
		
		for(ThreadGroup group  :threadGroups) {
			System.out.println(group.getName());
		}
		
		
	}

}



























