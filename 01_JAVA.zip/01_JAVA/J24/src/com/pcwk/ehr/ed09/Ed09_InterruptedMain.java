package com.pcwk.ehr.ed09;

import javax.swing.JOptionPane;

public class Ed09_InterruptedMain {

	public static void main(String[] args) {
		ThreadInterupped th01=new ThreadInterupped();
		th01.start();
		
		String input = JOptionPane.showInputDialog("입력하세요.");

		System.out.println("입력한 값은 "+input +" 입니다.");
		
		//스레드를 interrupt를 호출 : isInterrupted가 true가 된다.
		th01.interrupt();
		System.out.println("th01.isInterrupted: "+th01.isInterrupted());
	}

}
