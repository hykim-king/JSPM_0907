package com.pcwk.ehr.ed09;

public class ThreadInterupped extends Thread {

	@Override
	public void run() {

		int i = 10;
		//isInterrupted(): 스레드의 Interrupt 상태 반환
		while(i !=0 && !isInterrupted()) {
			System.out.println(i--);
			//for(long x=0;x<2_500_000_000L;x++);//시간 지연
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				//Interrupt가 false 자동 초기화
				System.out.println("InterruptedException:"+e.getMessage());
				this.interrupt();
			}
			
		}
		
		System.out.println("카운트 다운이 종료 되었습니다.");
		
	}

	
	
	
}
