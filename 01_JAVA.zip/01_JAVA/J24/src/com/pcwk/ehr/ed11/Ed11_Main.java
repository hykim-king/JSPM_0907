package com.pcwk.ehr.ed11;

public class Ed11_Main {

	public static void main(String[] args) {
		RunImpleEx r01=new RunImpleEx();
		RunImpleEx r02=new RunImpleEx();
		RunImpleEx r03=new RunImpleEx();
		
		
		Thread th01=new Thread(r01, "*");
		Thread th02=new Thread(r02, "**");
		Thread th03=new Thread(r03, "***");
		
		th01.start();
		th02.start();
		th03.start();
		
		
		try {
			Thread.sleep(2000);
			r01.suspend();
			
			Thread.sleep(2000);
			r02.suspend();			
			
			
			Thread.sleep(3000);		
			r01.resume();
			
			Thread.sleep(3000);	
			r01.stop();
			r02.stop();
			
			Thread.sleep(3000);			
			r03.stop();
			
			
		}catch(InterruptedException e) {
			
		}

	}

}
//*
//**
//***
//***
//**
//*
//*
//***
//**
//**
//***
//***
//***
//***
//***
//*
//***
//*
//***
//*
//***
//*- stopped!
//**- stopped!
//***
//***
//***- stopped!
