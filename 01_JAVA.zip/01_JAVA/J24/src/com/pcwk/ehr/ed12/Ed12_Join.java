package com.pcwk.ehr.ed12;

public class Ed12_Join {

	public static void main(String[] args) throws InterruptedException {
        Thread thread1 = new Thread(new FirstTask());
        Thread thread2 = new Thread(new SecondTask());
        thread1.start();
        thread1.join(); // 첫 번째 스레드의 실행 완료를 기다립니다.

        thread2.start();
	}

	static class FirstTask implements Runnable {
		public void run() {
			System.out.println("첫 번째 스레드 실행");
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			System.out.println("첫 번째 스레드 완료");
		}
	}

	static class SecondTask implements Runnable {
		public void run() {
			System.out.println("두 번째 스레드 실행");
		}
	}
}
