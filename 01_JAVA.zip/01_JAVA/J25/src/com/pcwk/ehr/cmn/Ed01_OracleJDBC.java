package com.pcwk.ehr.cmn;

import java.sql.*;

public class Ed01_OracleJDBC {
    /**
     * Java와 Oracle연결
     * insert sql수행
     * @param args
     */
	public static void main(String[] args) {
		// jdbc:mysql://localhost:3306/your_database : MySQL
		// "jdbc:oracle:thin:@serverIP:port:전역DB"
		String url = "jdbc:oracle:thin:@192.168.0.123:1521:XE"; // JDBC URL
		String user = "scott"; // 계정
		String password = "pcwk";// 비번

		Connection conn = null; // DB연결
		PreparedStatement pstmt = null;
		StringBuilder sb = new StringBuilder();//

		int flag = 0;

		try {
			// 1. 드라이버 로드
			Class.forName("oracle.jdbc.driver.OracleDriver");

			// 2. DB연결
			conn = DriverManager.getConnection(url, user, password);

			System.out.println("1.conn:" + conn);

			// 3. SQL
			sb.append(" insert into tb402 \n");
			sb.append(" values (          \n");
			sb.append(" ?,                \n");
			sb.append(" ?,                \n");
			sb.append(" SYSDATE           \n");
			sb.append(" )                 \n");

			System.out.println("2.SQL:" + sb.toString());
			//4. SQL : param설정
			pstmt = conn.prepareStatement(sb.toString());

			System.out.println("3.pstmt:" + pstmt);
			// ? param설정
			pstmt.setInt(1, 99);
			pstmt.setString(2, "이상무");

			//5. SQL수행
			flag = pstmt.executeUpdate();
			System.out.println("4.flag:" + flag);
		} catch (ClassNotFoundException e) {
			System.out.println("ClassNotFoundException:" + e.getMessage());
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("SQLException:" + e.getMessage());
			e.printStackTrace();
		} finally {
			//PreparedStatement
			if(null != pstmt) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			//Connection
			if(null != conn) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			
		}

		System.out.println("프로그램 수행 완료!");

	}

}
