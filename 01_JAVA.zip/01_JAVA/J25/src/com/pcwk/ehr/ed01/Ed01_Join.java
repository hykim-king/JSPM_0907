package com.pcwk.ehr.ed01;

import com.pcwk.ehr.cmn.PLogger;

public class Ed01_Join implements PLogger {

	
	static class SecondTask implements Runnable{

		@Override
		public void run() {
			LOG.debug("두 번째 스레드 실행");
		}
		
	}
	
	static class FirstTask implements Runnable{

		@Override
		public void run() {
			LOG.debug("첫 번째 스레드 실행");
			try {
				Thread.sleep(2000);
			}catch(InterruptedException e) {
				LOG.debug("InterruptedException:"+e.getMessage());
			}
			
			LOG.debug("첫 번째 스레드 실행종료!");
		}
		
	}//-- FirstTask end
	
	public static void main(String[] args) throws InterruptedException {
		LOG.debug("log4j2 ~~");
		
		Thread thread01=new Thread(new FirstTask());
		Thread thread02=new Thread(new SecondTask());
		
		
		thread01.start();
		thread01.join(); //첫 번째 스레드의 실행 완료를 기다립니다.
		
		thread02.start();
	}

}

//첫 번째 스레드 실행
//첫 번째 스레드 실행종료!
//두 번째 스레드 실행






















