package com.pcwk.ehr.ed02;

public class Account {

	private int balance = 1_000;// 잔고

	/**
	 * @return the balance
	 */
	public int getBalance() {
		return balance;
	}

	/**
	 * 출금: 메서드 동기화
	 * 
	 * @param money
	 */
//	public synchronized void withdraw(int money) {
//		if(balance >= money) {//잔고가 출금 금액 보다 커야 지만 출금 가능
//			try {
//				Thread.sleep(1000);
//			} catch (InterruptedException e) {
//				e.printStackTrace();
//			}
//			
//			balance -= money;
//			
//		}
//	}

	//block동기화
	public void withdraw(int money) {
		synchronized (this) {
			if (balance >= money) {// 잔고가 출금 금액 보다 커야 지만 출금 가능
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}

				balance -= money;

			}
		}
	}
}
