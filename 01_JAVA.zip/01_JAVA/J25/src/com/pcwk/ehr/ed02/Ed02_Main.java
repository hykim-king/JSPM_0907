package com.pcwk.ehr.ed02;

public class Ed02_Main {

	public static void main(String[] args) {
		RunnableEx  r=new RunnableEx();
		
		//balance가 minus(-)발생 하지 않음!
		new Thread(r).start();
		new Thread(r).start();

	}

}
//balance: 800
//balance: 500
//balance: 300
//balance: 0
//balance: 0