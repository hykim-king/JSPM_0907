package com.pcwk.ehr.ed02;

import com.pcwk.ehr.cmn.PLogger;

public class RunnableEx implements Runnable,PLogger {
	Account account=new Account();
	
	
	
	@Override
	public void run() {
		while(account.getBalance() > 0) {
			//100,200,300
			int money=(int)(Math.random()*3+1)*100;
			
			account.withdraw(money);
			LOG.debug("balance: "+account.getBalance());
			
		}//--while
		
	}//--run

}
