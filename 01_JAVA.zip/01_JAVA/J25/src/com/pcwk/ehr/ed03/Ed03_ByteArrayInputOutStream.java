package com.pcwk.ehr.ed03;
import java.io.*;
import java.util.Arrays;


public class Ed03_ByteArrayInputOutStream {

	public static void main(String[] args) {
		//스트림에서 읽고/쓰기
		
		byte[]  inSrc = {0,1,2,3,4,5,6,7,8,9};
		byte[]  outSrc= null;
		
		ByteArrayInputStream  bais = null;//읽기
		ByteArrayOutputStream baos = null;//쓰기
		
		
		bais = new ByteArrayInputStream(inSrc);
		baos = new ByteArrayOutputStream();
		
		int data = 0;
		//data = bais.read()
		//data !=-1
		while( (data= bais.read()) !=-1) {//데이터가 더이상 없으면 -1
			System.out.println("data:"+data);
			baos.write(data);
		}
		
		outSrc = baos.toByteArray();//스트림의 내용을 byte배열로 변환
		
		System.out.println("inSrc:"+Arrays.toString(inSrc));
		System.out.println("outSrc:"+Arrays.toString(outSrc));
		
		
		
		
	}

}
//data:0
//data:1
//data:2
//data:3
//data:4
//data:5
//data:6
//data:7
//data:8
//data:9
//inSrc:[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
//outSrc:[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
