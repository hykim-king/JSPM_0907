package com.pcwk.ehr.ed08;

import java.io.*;

public class Ed08_BufferedOutputStream {

	public static void main(String[] args) {
		
		FileOutputStream  fos= null;
		BufferedOutputStream bos = null;
		
		try {
			fos = new FileOutputStream("num.txt");
			//BufferedOutputStream 버퍼의 크기를 5로 설정
			bos = new BufferedOutputStream(fos, 5);
			
			for(int i='1';i<='9';i++) {
				bos.write(i);
			}
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
//			if( null != fos) {
//				try {
//					fos.close();
//				} catch (IOException e) {
//					e.printStackTrace();
//				}
//			}
			
			//보조 스트림을 닫으면 기반스트림을 닫는다. 
			//buffer를 닫지 않으면 버퍼에 데이가 남아 있는 상태로 처리된다.
			//따라서 buffer만큼 데이터 부정확 하다.
			if( null !=bos) {
				try {
					bos.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
		}
		

	}

}
