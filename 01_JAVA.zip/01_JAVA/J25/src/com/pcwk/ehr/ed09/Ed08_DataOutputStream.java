package com.pcwk.ehr.ed09;

import java.io.DataOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class Ed08_DataOutputStream {

	public static void main(String[] args) {
//		DataInputStream/DataOutputStream는 FilterInputStream/FilterOutputStream을 부모로 두고 있으며, 
//		DataInput/DataOutput 인터페이스를 각가 구현. 
//		byte단위가 아니고 기본형 데이터를 읽고쓸수 있다.

		try (FileOutputStream fos = new FileOutputStream("pcwk.dat");
				DataOutputStream dos = new DataOutputStream(fos);) {

			boolean boolValue = true;
			byte byteValue = 123;
			char charValue = 'A';
			int intValue = 16;
			double doubleValue = 3.14d;
			String strValue = "환절기 감기 조심하세요.";

			// 기록한 순서대로 읽어야
			dos.writeBoolean(boolValue);// boolean 데이터 기록
			dos.writeByte(byteValue);// Byte 데이터 기록
			dos.writeChar(charValue);// char 데이터 기록
			dos.writeInt(intValue);// int 데이터 기록
			dos.writeDouble(doubleValue);// double 데이터 기록
			dos.writeUTF(strValue);// 문자열 데이터 기록

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}

		System.out.println("프로그램 종료: F5");

	}

}
