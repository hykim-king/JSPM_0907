package com.pcwk.ehr.ed10;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Ed10_FileReader {
	/**
	 * byte stream으로 파일 read
	 * @param filePath
	 */
	public static void byteStream(String filePath) {
		FileInputStream  fis = null;
		
		
		try {
			fis = new FileInputStream(filePath);
			int data = 0;//read data
			
			byte[] buffer=new byte[1024];//1kb 버퍼
			int bytesRead = 0;//
			
			//read() 메서드를 사용하여 파일로부터 데이터를 읽고 buffer에 저정
			while( (bytesRead=fis.read(buffer) ) !=-1) {
				//bytesRead는 실제로 읽은 바이트 수를 나타낸다.
				//System.out.print( (char)data);
				
				//읽은 데이터 만큼 화면에 출력
				System.out.write(buffer,0,bytesRead);
			}
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if(null != fis) {
				try {
					fis.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		System.out.println("byteStream 완료!");

	}
	
	/**
	 * char stream으로 파일 read
	 * @param filePath
	 */
	public static void charStream(String filePath) {
		FileReader fr = null;
		
		try {
			fr = new FileReader(filePath);
			
			int data = 0;
			
			//데이터를 2byte씩 읽고 더이상 데이터가 없으면
			//-1이 return된다.
			while( (data=fr.read()) !=-1) {
				System.out.print((char)data);
			}
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();	
		}catch(IOException e) {
			e.printStackTrace();
		}finally {
			if(null !=fr) {
				try {
					fr.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}	
	
	public static void main(String[] args) {
		String filePath =
				"C:\\JSPM_0907\\01_JAVA\\WORKSPACE\\J25\\src\\com\\pcwk\\ehr\\ed10\\Ed10_FileReader.java";

		byteStream(filePath);
		//charStream(filePath);
		
	}

}















