package com.pcwk.ehr.ed11;

import java.io.*;

public class Ed12_BufferedReader {

	public static void main(String[] args) {
		//String filePath = "C:\\JSPM_0907\\01_JAVA\\WORKSPACE\\J25\\src\\com\\pcwk\\ehr\\ed11\\Ed11_BufferedReader.java";
        String filePath = "C:\\JSPM_0907\\01_JAVA\\WORKSPACE\\J25\\src\\launchBox.txt";
        long startTime = System.currentTimeMillis();// 시작시간
		try (FileReader fr = new FileReader(filePath)) {
			

			int data = 0;
			
			//br.readLine() : 데이터가 더이상 업으면 null이 return
			while( (data = fr.read()) !=-1) {
				System.out.print((char)data);
			}
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}

		long endTime = System.currentTimeMillis();//종료시간
		System.out.println("경과시간:"+(endTime - startTime));//경과시간:251, 경과시간:1158
		
	}

}
