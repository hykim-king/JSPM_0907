package com.pcwk.ehr.ed02;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import com.pcwk.ehr.cmn.PLogger;

public class Ed02_01FileInputStream implements PLogger {

	public static void main(String[] args) {
		String filePath = "C:\\JSPM_0907\\01_JAVA\\WORKSPACE\\J26\\src\\com\\pcwk\\ehr\\ed02\\IE002568231_PHT.jpg";
		long start = System.currentTimeMillis();
		
		try (FileInputStream fis = new FileInputStream(filePath);
				FileOutputStream fos = new FileOutputStream("newImage.jpg");) {

			int data = 0;
			while(  (data=fis.read()) !=-1) {
				fos.write(data);
			}
			
		} catch (IOException e) {
			LOG.debug("IOException:" + e.getMessage());
		}
		long end = System.currentTimeMillis();
		LOG.debug("경과시간:"+(end - start));
		LOG.debug("image 복사 완료!");

	}

}
