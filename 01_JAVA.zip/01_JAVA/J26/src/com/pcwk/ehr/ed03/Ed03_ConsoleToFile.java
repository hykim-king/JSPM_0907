package com.pcwk.ehr.ed03;

import java.io.*;

public class Ed03_ConsoleToFile {

	public static void main(String[] args) {
		
		PrintStream   ps = null;
		try {
			ps = new PrintStream(new FileOutputStream("out.txt"));
			
			//콘솔 출력을 파일로 리다이렉션
			System.setOut(ps);
			
			System.out.println("┌───────────────────────────┐");
			System.out.println("│이 내용을 파일에 기록 됩니다.      │");
			System.out.println("└───────────────────────────┘");
			
			
			//콘솔 출력으로 변경
			System.setOut(new PrintStream(new FileOutputStream(FileDescriptor.out)));
			System.out.println("콘솔에 출력");
		}catch(IOException e) {
			System.out.println("IOException:"+e.getMessage());
		}finally {
			if(null != ps) {
				ps.close();
			}
		}
		
		System.out.println("프로그램 종료!");

	}

}
