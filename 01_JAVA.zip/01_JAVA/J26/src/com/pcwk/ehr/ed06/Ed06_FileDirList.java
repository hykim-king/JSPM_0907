package com.pcwk.ehr.ed06;

import java.io.*;
import java.util.*;
public class Ed06_FileDirList {
 
	static int totalFiles = 0;//파일개수
	static int totalDirs  = 0;//디렉토리 개수
	//재귀호출
	public static void printFileDirList(File dir) {
		ArrayList<String> subDir=new ArrayList<String>();//하위 디렉토리
		
		//System.out.println(dir.getAbsolutePath()+" 디렉토리");
		
		//디렉토리 하부의 파일과 디렉토리 목록
		File[] files = dir.listFiles();
		
		for(int i=0;i<files.length;i++) {
			String fileName = files[i].getName();
			
			
			
			//디렉토리이면 [디렉토리명]
			if(files[i].isDirectory()) {
				fileName = "["+fileName+"]";
				subDir.add(i+"");
			}
			
			//System.out.println(fileName);
			
			int dirNum = subDir.size();
			int fileNum = files.length - dirNum;//전체(파일+디렉토리수 - 디레토리수)
			
			totalDirs  += dirNum;
			totalFiles += fileNum;
			
			//System.out.println(fileNum+ " 개의 파일, "+dirNum+" 개의 디렉토리");
			//System.out.println();
			
			for(int j=0;j<subDir.size();j++) {
				int index =Integer.parseInt(subDir.get(j));
				printFileDirList(files[index]);
			}
			
			
		}//--for
		
		
		
	}//--printFileDirList
	
    static class JavaFileFilter implements FilenameFilter {
        @Override
        public boolean accept(File dir, String name) {
            return name.toLowerCase().endsWith(".java");
        }
    }
    
	public static void main(String[] args) {
		if(args.length !=1) {
			System.out.println("디렉토리를 입력 하세요.");
			System.exit(0);
		}
		
		File dir=new File(args[0]);
		if(!dir.exists() || !dir.isDirectory()) {
			System.out.println("유효하지 않은 디렉토리입니다.");
			System.exit(0);
		}
		
		printFileDirList(dir);
		System.out.println("총 "+totalDirs+"개의 디렉토리");
		System.out.println("총 "+totalFiles+"개의 파일");
		

	}

}
