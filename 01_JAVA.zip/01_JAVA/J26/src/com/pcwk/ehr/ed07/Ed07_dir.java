package com.pcwk.ehr.ed07;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;


public class Ed07_dir {

	public static void main(String[] args) {
		//dos :dir
		//linux: ls -l

		if(args.length !=1) {
			System.out.println("디렉토리 경로를 입력 하세요.");
			System.exit(0);
		}
		
		String filePathName = args[0];
		
		//디렉토리 객체 생성
		File directory=new File(filePathName);
		
		//디렉토리 및 파일 리스트
		File[]  fileList = directory.listFiles();
		
		for(File f:fileList) {
			//파일이름
			System.out.printf("%-24s",f.getName());
			
			//파일크기
			String formattedNumber = String.format("%,d", f.length());
			
			System.out.printf("%12s\t",formattedNumber);
			
			//-rwx
			// -:file
			// d:directory
			// r:read
			// w:write
			// x:executable
			
			//권한
			System.out.print(f.isFile()==true?"-":"d");//파일과 디렉토리 구분
			System.out.print(f.canRead()?"r":"-");//읽기권한
			System.out.print(f.canWrite()?"w":"-");//기록할 권한
			System.out.print(f.canExecute()?"x":"-");//실행 권한
			System.out.print("\t");
			
			//최종 수정일
			Date lastModDate=new Date(f.lastModified());
			
			//yyyy-MM-dd HH:mm:ss
			SimpleDateFormat  sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			
			System.out.print(sdf.format(lastModDate));
			
			
			
			System.out.println();
		}//--for
		
		
		

	}//--main

}
