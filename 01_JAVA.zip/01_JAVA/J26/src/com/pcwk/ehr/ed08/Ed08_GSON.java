package com.pcwk.ehr.ed08;

import java.io.*;

import com.google.gson.*;
import com.pcwk.ehr.cmn.PLogger;

public class Ed08_GSON implements PLogger {

	public static void main(String[] args) {
		String filePathName = "C:\\JSPM_0907\\01_JAVA\\WORKSPACE\\J26\\src\\com\\pcwk\\ehr\\ed08\\data.json";
		try(FileReader fr=new FileReader(filePathName)){
			
			//Gson객체 생성
			Gson  gson=new Gson();
			Member data=gson.fromJson(fr, Member.class);
			
			LOG.debug("Name: "+data.getName());
			LOG.debug("Age: "+data.getAge());
			
		}catch(IOException e) {
			LOG.debug("IOException:"+e.getMessage());
		}

	}

}
