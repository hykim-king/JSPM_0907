package com.pcwk.ehr.ed09;

import java.util.ArrayList;
import java.util.List;

public class Channel {

	private List<Item> items=new ArrayList<Item>();
	
	public Channel() {}

	/**
	 * @return the items
	 */
	public List<Item> getItems() {
		return items;
	}

	/**
	 * @param items the items to set
	 */
	public void setItems(List<Item> items) {
		this.items = items;
	}
	
	
	
}
