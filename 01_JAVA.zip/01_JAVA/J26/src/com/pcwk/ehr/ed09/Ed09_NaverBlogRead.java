package com.pcwk.ehr.ed09;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.List;

import com.google.gson.Gson;
import com.pcwk.ehr.cmn.PLogger;

public class Ed09_NaverBlogRead implements PLogger {
	/**
	 * 1. naver web 인증
	 * 2. 검색어: UTF-8
	 * 3. 받아온 JSON 파싱
	 * @param args
	 */
	public static void main(String[] args) {

		String clientId = "xVZljeTXhBnGbvEXJokQ";//애플리케이션 클라이언트 아이디값";
		String clientSecret= "jJKfXFe1xu";//애플리케이션 클라이언트 비번
		//curl  "https://openapi.naver.com/v1/search/blog.json?query=%EB%A6%AC%EB%B7%B0&display=10&start=1&sort=sim" \
		String apiURL   = "https://openapi.naver.com/v1/search/blog.json?query=";
		BufferedReader  br = null;
		
		try {
			String text = URLEncoder.encode("홍대 맛집", "UTF-8");
			LOG.debug("text:"+text);
			apiURL += text;
			LOG.debug("apiURL+검색어:"+apiURL);
			
			
			//1. naver web 인증
			URL  url=new URL(apiURL);
			HttpURLConnection con = (HttpURLConnection)url.openConnection();
			//접속정보:id/비번
			con.setRequestMethod("GET");//GET방식 접속
			con.setRequestProperty("X-Naver-Client-Id", clientId);//Naver ClientID
			con.setRequestProperty("X-Naver-Client-Secret", clientSecret);//Naver Client-Secret
			
			int responseCode = con.getResponseCode();
			LOG.debug("responseCode:"+responseCode);//200정상 접속,
			
			
			
			if(200 == responseCode) {//접속 성공
				//BufferedReader : char 스트림 연결
				//InputStreamReader: 바이트 스트림과 char 스트림 연결
				//con.getInputStream(): 바이트 스트림
				br = new BufferedReader(new InputStreamReader(con.getInputStream()));
			}else {//접속 실패
				
			}
			
			
			String inputLine = "";
			StringBuilder sb=new StringBuilder();
			while( (inputLine=br.readLine()) !=null) {
				//LOG.debug(inputLine);
				sb.append(inputLine);
			}
			
			//2.GSON
			Gson gson=new Gson();
			Channel channel = gson.fromJson(sb.toString(), Channel.class);
			
			List<Item> list = channel.getItems();
			
			for(Item item :list) {
				LOG.debug(item.toString());
			}
			
			
			
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if(null !=br) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		
		
		

	}

}
