package com.pcwk.ehr.ed09;

import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;
import java.io.File;
import java.io.IOException;
import java.util.Iterator;

public class ImageFormatDetection {
    public static void main(String[] args) {
        try {
            File imageFile = new File("C:\\JSPM_0907\\01_JAVA\\WORKSPACE\\J26\\newImage.png"); // 이미지 파일의 경로를 지정해야 합니다.

            // 이미지 파일을 읽을 ImageInputStream을 생성
            ImageInputStream imageInputStream = ImageIO.createImageInputStream(imageFile);

            if (imageInputStream == null) {
                System.out.println("이미지를 읽을 수 없습니다.");
                return;
            }

            // 이미지 포맷을 판별하기 위한 ImageReader 검색
            Iterator<ImageReader> imageReaders = ImageIO.getImageReaders(imageInputStream);
            if (imageReaders.hasNext()) {
                ImageReader reader = imageReaders.next();
                System.out.println("이미지 포맷: " + reader.getFormatName());
            } else {
                System.out.println("이미지 포맷을 판별할 수 없습니다.");
            }

            // ImageInputStream을 닫습니다.
            imageInputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

