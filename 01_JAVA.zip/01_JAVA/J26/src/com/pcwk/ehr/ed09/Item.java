package com.pcwk.ehr.ed09;

public class Item {
	private String title;//제목
	private String link;//링크
	private String description;//상세내용
	private String bloggername;//블러거 명
	private String bloggerlink;//블러거 링크
	private String postdate;//글 등록일
	
	public Item() {}

	/**
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * @param title the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * @return the link
	 */
	public String getLink() {
		return link;
	}

	/**
	 * @param link the link to set
	 */
	public void setLink(String link) {
		this.link = link;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the bloggername
	 */
	public String getBloggername() {
		return bloggername;
	}

	/**
	 * @param bloggername the bloggername to set
	 */
	public void setBloggername(String bloggername) {
		this.bloggername = bloggername;
	}

	/**
	 * @return the bloggerlink
	 */
	public String getBloggerlink() {
		return bloggerlink;
	}

	/**
	 * @param bloggerlink the bloggerlink to set
	 */
	public void setBloggerlink(String bloggerlink) {
		this.bloggerlink = bloggerlink;
	}

	/**
	 * @return the postdate
	 */
	public String getPostdate() {
		return postdate;
	}

	/**
	 * @param postdate the postdate to set
	 */
	public void setPostdate(String postdate) {
		this.postdate = postdate;
	}

	@Override
	public String toString() {
		return "Item [title=" + title + ", link=" + link + ", description=" + description + ", bloggername="
				+ bloggername + ", bloggerlink=" + bloggerlink + ", postdate=" + postdate + "]";
	}
	
	
	
	
}
