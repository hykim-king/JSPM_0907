package com.pcwk.ehr.ed01;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import com.pcwk.ehr.cmn.PLogger;

public class Ed01_DirFileRead implements PLogger {
	static int totalFileCount      =0;//총 파일 수
	static int totalDierctoryCount =0;//총 디렉토리 수
	
	static int keywordCount        =0;//keyword 수
	//java파일만 read
	static String keyWord          = "";
	
	public static void main(String[] args) {
		// Directory내에 파일들의 내용을 읽고 : if keyword count
		// C:\JSPM_0907\01_JAVA\WORKSPACE\J27 if
		if(args.length !=2) {
			System.out.println("디렉토리명, 검색어를 입력 하세요.");
			System.exit(0);
		}
		
		//디렉토리 path
		String directoryPath = args[0];
		//keyWord
		keyWord = args[1];
		
		System.out.printf("directoryPath=%s, keyWord=%s\n",directoryPath,keyWord);
		
		//디렉토리 객체 생성
		File directory=new File(directoryPath);
		
		try {
			printDirectoryContents(directory);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		System.out.println("--------------------------");
		System.out.println("keyWord:"+keyWord);
		System.out.println("keywordCount:"+keywordCount);
		System.out.println("--------------------------");
		
	}

	public static void printDirectoryContents(File dir) throws IOException {
		
		//파일, 디렉토리 리스트
		File[] files = dir.listFiles();
		
		for(int i=0;i<files.length;i++) {
			
			//디렉토리 
			if(files[i].isDirectory() == true) {
				printDirectoryContents(files[i]);
			//파일	
			}else {
				//파일이름
				String fileName = files[i].getName();
				
				//파일확장자 : Ed01_DirFileRead.java
				
				String extension = fileName.substring(fileName.lastIndexOf(".")+1);
				//확장자가 자바가 아니면 continue
				if(!extension.equals("java")) { continue; }
				
				//파일이름: 디렉토리+패스구분자+파일이름
				//ex C:\JSPM_0907\01_JAVA\WORKSPACE\J27+\+Ed01_DirFileRead.java 
				fileName = dir.getAbsolutePath()+File.separator+fileName;
				
				FileReader  fr=new FileReader(files[i]);
				BufferedReader  br=new BufferedReader(fr);
				
				//한 줄씩 데이터 읽기
				String data = "";
				//라인번호
				int lineNum = 0;
				
				while( (data=br.readLine()) !=null) {
					lineNum++;
					
					if(data.indexOf(keyWord) !=-1) {
						keywordCount++;
						System.out.println("["+fileName+"("+lineNum+")"+"]"+data);
					}
				}//--while
				
				br.close();
				
			}
			
			
		}//--for i
		
	}//-- printDirectoryContents
	
	
	
	
	
	
}
