package com.pcwk.ehr.ed02;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;

public class Ed02_Deserialized {

	public static void main(String[] args) {
		String name = "C:\\JSPM_0907\\01_JAVA\\WORKSPACE\\J27\\pcwk_serial.ser";
		// 역직렬화
		try (FileInputStream fis = new FileInputStream(name); 
				ObjectInputStream ois = new ObjectInputStream(fis);) {

			Person person01=(Person) ois.readObject();
			Person person02=(Person) ois.readObject();
			
			System.out.println("person01:"+person01);
			System.out.println("person02:"+person02);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

	}

}
