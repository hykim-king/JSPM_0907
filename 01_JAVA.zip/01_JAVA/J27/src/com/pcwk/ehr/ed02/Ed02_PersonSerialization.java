package com.pcwk.ehr.ed02;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class Ed02_PersonSerialization {

	public static void main(String[] args) {
		// 객체를 파일에 기록
		Person person01 = new Person("Bob", 24);
		Person person02 = new Person("Ann", 21);

		// 객체 직렬화, 파일에 기록
		try (FileOutputStream fis = new FileOutputStream("pcwk_serial.ser");
				ObjectOutputStream oos = new ObjectOutputStream(fis);) {
			oos.writeObject(person01);
			oos.writeObject(person02);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		System.out.println("파일 생성 완료!");
	}

}
