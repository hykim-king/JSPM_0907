package com.pcwk.ehr.ed04;
import java.net.*;

public class Ed04_InetAddress {

	public static void main(String[] args) {
		InetAddress  local = null;

		try {
			local = InetAddress.getLocalHost();
			
			//호스트 명: 
			System.out.println("호스트 명:"+local.getHostName());
			//호스트 주소
			System.out.println("호스트 주소:"+local.getHostAddress());
			
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		
	}

}
//호스트 명:DESKTOP-IOIHNH2
//호스트 주소:192.168.0.123