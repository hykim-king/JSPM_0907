package com.pcwk.ehr.ed04;
import java.net.*;


public class Ed04_InetAddress2 {
	
	static final String HOST_NAME = "www.naver.com";
	
	public static void main(String[] args) {
	
		try {
			InetAddress address = InetAddress.getByName(HOST_NAME);
			
			//호스트 이름
			System.out.println("호스트 이름:"+address.getHostName());
			
			//IP주소
			System.out.println("IP주소:"+address.getHostAddress());
			
			//모든 IP주소 출력
			InetAddress[] ipArray = InetAddress.getAllByName(HOST_NAME);
			for(int i=0;i<ipArray.length;i++) {
				System.out.println(ipArray[i].toString());
			}
			
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}

	}

}
//호스트 이름:www.naver.com
//IP주소:223.130.200.107
//www.naver.com/223.130.200.107
//www.naver.com/223.130.200.104