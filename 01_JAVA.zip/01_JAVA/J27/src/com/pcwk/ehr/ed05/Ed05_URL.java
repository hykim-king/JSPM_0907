package com.pcwk.ehr.ed05;
import java.net.*;


public class Ed05_URL {

	static final String ACON = "https://www.acorncampus.co.kr:443/business/process.jsp?seq=30";
	public static void main(String[] args) {
		
		try {
			URL url=new URL(ACON);
			
			//호스트명과 포트
			System.out.println("호스트명과 포트:"+url.getAuthority());
			
			//프로토콜
			System.out.println("프로토콜:"+url.getProtocol());
			
			//쿼리
			System.out.println("쿼리:"+url.getQuery());
			
			//전체
			System.out.println("전체:"+url.toURI());
			
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}
	}

}
