package com.pcwk.ehr.ed06;
import java.net.*;
import java.io.*;


public class Ed06_URLConnection {
	//서울특별시 마포구 양화로 122 LAB7 빌딩  4층
	//http://www.cgv.co.kr/movies/?lt=1&ft=0
	//static final String ACON = "https://www.acorncampus.co.kr:443/business/process.jsp?seq=30";
	static final String CGV = "http://www.cgv.co.kr/movies/?lt=1&ft=0";
	public static void main(String[] args) {
		BufferedReader  br = null;
		try {
			URL url=new URL(CGV);
			URLConnection conn = url.openConnection();//URLConnection 객체 생성
			
			InputStream is=conn.getInputStream();
			
			//byte -> char스트림으로 변경할수 있는 class(InputStreamReader)
			br=new BufferedReader(new InputStreamReader(is));
			
			String data = "";
			while( (data=br.readLine()) !=null) {
				System.out.println(data);
			}
			
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if(null !=br) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		

	}

}
