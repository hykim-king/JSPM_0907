package com.pcwk.ehr.ed07;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.*;

public class Client {
	
	static final int PORT        = 8890;
	//static final String SEVER_IP ="192.168.0.123";
	static final String SEVER_IP ="192.168.0.39";
	//
	public static void main(String[] args) {
		System.out.println("서버에 연결 중 :"+SEVER_IP+":"+PORT);
		Socket socket = null;
		
		try {
			socket =new Socket(SEVER_IP, PORT);
			
			//소켓을 통한 스트림 생성
			InputStream in = socket.getInputStream();
			DataInputStream dis=new DataInputStream(in);
			
			//서버로 부터 받은 메시지 출력
			String readMsg = dis.readUTF();
			System.out.println("서버 수신 메시지: "+readMsg);
			System.out.println("Client연결 종료");
			
			//스트림 소켓 종료
			dis.close();
			socket.close();
		}catch(IOException e) {
			System.out.println("===================");
			System.out.println("=IOException="+e.getMessage());
			System.out.println("===================");			
		}
		System.out.println("===================");
		System.out.println("=Client프로그램 종료.");
		System.out.println("===================");	
	}

}
