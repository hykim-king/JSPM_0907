package com.pcwk.ehr.ed07;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Ex07_Server {

	static final int PORT = 8888;
	
	public static String currDate() {
		SimpleDateFormat  sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		return sdf.format(new Date());
	}
	
	public static void main(String[] args) {
		//1. ServerSocket
		
		ServerSocket serverSocket = null;//서버소켓
		Socket       clientSocket = null;//소켓: client와 통신
		
		OutputStream out          = null;
		DataOutputStream  dos     = null;
		
		try {
			//8888포트 번호로 서버 소켓 생성
			serverSocket = new ServerSocket(PORT);
			
			//현제 시간 정보: yyyy-MM-dd HH:mm:ss
			System.out.println(currDate()+" Waiting for clients to connet ...");
			
			//무한 loop
			while(true) {
				//서버소캣은 클라이언트 연결요청이 올 때까지 실행을 멈추고 계속 대기한다.
				//클라이언트의 연결요청이 들어 오면 클라이언트와 통신할 새로운 소캣을 생성한다.
				clientSocket = serverSocket.accept();
				System.out.println(currDate()+
						"client ip:"+clientSocket.getInetAddress() +"Client connected.");
				
				
				//출력 스트림 생성
				out = clientSocket.getOutputStream();
				dos = new DataOutputStream(out);
				
				//client으로 메시지 전송!
				dos.writeUTF("This message if from server.\n오늘은 즐거운 목요일");
				
				dos.close();
				clientSocket.close();
			}//--while
			
			
			
		}catch(IOException e) {
			System.out.println("===================");
			System.out.println("=IOException="+e.getMessage());
			System.out.println("===================");
		}
		
		
		
	}

}
