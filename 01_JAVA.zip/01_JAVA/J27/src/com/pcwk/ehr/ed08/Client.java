package com.pcwk.ehr.ed08;
import java.net.*;
import java.io.*;

public class Client {

	final static int PORT = 9000;
	final static String SERVER_IP = "192.168.0.123";
	static final String USER = "client_james]";
	
	public static void main(String[] args) {
		
		try {
			//client소켓 생성
			Socket socket=new Socket(SERVER_IP, PORT);
			System.out.println("서버 접속...");
			
			//송 수신 용 객체 생성
			Sender sender=new Sender(socket, USER);
			Receiver receiver=new Receiver(socket);			
			
			//스레드 실행
			sender.start();
			receiver.start();			
			
		}catch(IOException e) {
			System.out.println("--------------------");
			System.out.println("-IOException-"+e.getMessage());
			System.out.println("--------------------");			
		}

	}

}
