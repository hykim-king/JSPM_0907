package com.pcwk.ehr.ed08;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

public class Sender extends Thread {
	Socket socket;
	DataOutputStream  out;//외부로 메시지 전송
	String name;//이름

	public Sender(Socket socket, String name) {
		super();
		this.socket = socket;
		this.name = name;
		
		try {
			out = new DataOutputStream(socket.getOutputStream());
			name += " "+socket.getInetAddress()+":"+socket.getPort();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void run() {
		//콘솔 입력 Scanner생성
		 Scanner scanner=new Scanner(System.in);
		 
		 while(null != out) {
			 try {
				out.writeUTF(name+">"+scanner.nextLine());
			} catch (IOException e) {
				e.printStackTrace();
			}
		 }
	}
}
