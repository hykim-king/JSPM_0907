package com.pcwk.ehr.ed08;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {

	final static int PORT = 9000;//Server Port 
	static final String USER = "james]";
	
	public static void main(String[]args) {

		ServerSocket  serverSocket = null;//client 최초 접속용 소켓
		Socket socket = null;//Client 통신용 소켓
		
		try {
			//client 최초 접속용 소켓: 9000
			serverSocket = new ServerSocket(PORT);
			System.out.println("Server ready...");
			
			socket = serverSocket.accept();
			
			//송 수신 용 객체 생성
			Sender sender=new Sender(socket, USER);
			Receiver receiver=new Receiver(socket);
			
			//스레드 실행
			sender.start();
			receiver.start();
		}catch(IOException e) {
			System.out.println("--------------------");
			System.out.println("-IOException-"+e.getMessage());
			System.out.println("--------------------");
		}
		
	}//--main
	
}
