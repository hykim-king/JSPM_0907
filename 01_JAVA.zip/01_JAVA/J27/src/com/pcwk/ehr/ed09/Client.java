package com.pcwk.ehr.ed09;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

import com.pcwk.ehr.cmn.PLogger;

public class Client implements PLogger {
	//server ip,port
	static final int PORT = 9998;
	static final String IP = "192.168.0.104";
	
	static class ClinetSender extends Thread{
		Socket socket ;
		String name;
		DataOutputStream out;
		
		ClinetSender(Socket socket,String name){
			this.socket = socket;
			this.name   = name;
			
			try {
				out = new DataOutputStream(socket.getOutputStream());
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		
		@Override
		public void run() {
			Scanner scanner=new Scanner(System.in);
			if(null !=out) {
				try {
					//서버로 이름 전송
					out.writeUTF(name);
					
					
					//채팅
					while(null !=out) {
						String message = "["+name+"]"+scanner.nextLine();
						out.writeUTF(message);
					}
				
				}catch(IOException e) {
					System.out.println("IOException:"+e.getMessage());
				}
				
			}//--if
			
			
		}//--run()
	}//-- ClinetSender
	
	static class ClinetReceiver extends Thread{
		Socket socket;
		DataInputStream in;
		
		ClinetReceiver(Socket socket){
			this.socket = socket;
			
			try {
				in = new DataInputStream(socket.getInputStream());
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		@Override
		public void run() {
			while(null !=in) {
				try {
					System.out.println(in.readUTF());
				} catch (IOException e) {
					System.out.println("IOException:"+e.getMessage());
				}
			}
			
			
		}//--run()
	}//-- ClinetReceiver	
	
	public static void main(String[] args) {
		//대화명
		if(args.length !=1) {
			LOG.debug("대화명을 입력 하세요.");
			System.exit(0);
		}  
		
		String chatId = args[0];
		LOG.debug("chatId:"+chatId);
		
		try {
			Socket  socket=new Socket(IP, PORT);
			System.out.println("서버에 접속 되었습니다.");
			
			//Sender 스레드 생성
			Thread sender=new Thread(new ClinetSender(socket,chatId));
			sender.start();
			
			
			//Receiver 스레드 생성
			Thread receiver=new Thread(new ClinetReceiver(socket));
			receiver.start();
			
		}catch(IOException e) {}
	}//--main

}
