package com.pcwk.ehr.ed09;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;

import com.pcwk.ehr.cmn.PLogger;


public class MultiServer implements PLogger{

	//Client정보: Thread Safe
	HashMap<String, DataOutputStream>  clients;
	static final int PORT = 9999;
	
	public MultiServer() {
		clients = new HashMap<String, DataOutputStream>();
		//map동기화:thread safe Map
		Collections.synchronizedMap(clients);
	}
	
	public void start() {
		//서버 소켓 생성
		ServerSocket  serverSocket = null;	
		//소켓 생성
		Socket socket = null;
		try {
			serverSocket = new ServerSocket(PORT);
			System.out.println("Server start ...");
			
			while(true) {
				socket = serverSocket.accept();
				LOG.debug("[" +socket.getInetAddress()+ "]에서 접속 했습니다.");
				
				//ServerReceiver 스레드 생성
				ServerReceiver serverReceiver=new ServerReceiver(socket);
				serverReceiver.start();
			}
			
		}catch(IOException e) {
			System.out.println("IOException:"+e.getMessage());
		}
	}
	
	
	class ServerReceiver extends Thread{
		Socket socket;
		DataInputStream  in;
		DataOutputStream out;
		
		ServerReceiver(Socket socket){
			this.socket = socket;
			try {
				in = new DataInputStream(socket.getInputStream());
				out= new DataOutputStream(socket.getOutputStream());
			}catch(IOException e) {
				System.out.println("IOException:"+e.getMessage());
			}
		}//--ServerReceiver
		
		@Override
		public void run() {
			//접속자 이름
			String name = "";
			try {
				name = in.readUTF();//client로 부터 이름 읽기
				//접속된 모든 사용자
				String firstMsg = "*"+name+"님이 접속 했습니다.";
				sendToAll(firstMsg);
				//thread safe한 HashMap에 클라이언트 이름, DataOutputStream
				clients.put(name,out);
				LOG.debug("현재 접속자 수 "+clients.size() +" 입니다.");
				
				
				//채팅
				while(null !=in) {
					String clientMsg = in.readUTF();
					LOG.debug("client 메시지:"+clientMsg);
					sendToAll(clientMsg);
				}
				
				
			}catch(IOException e) {
				System.out.println("IOException:"+e.getMessage());
			}finally {
				//접속 종료 처리
				sendToAll("#"+name+"님이 퇴장 하셨습니다.");
				clients.remove(name);
				
				LOG.debug("["+socket.getInetAddress()+"] 에서 접속 종료 했습니다.");
				LOG.debug("현재 접속자 수 "+clients.size() +" 입니다.");
			}
		}//--run
		
		//접속된 모든 사용자 에게 메시지 전송
		public void sendToAll(String message) {
			//모든 client 접속자 이름 
			Iterator<String> names = clients.keySet().iterator();
			
			while(names.hasNext() == true) {
				DataOutputStream out = clients.get(names.next());
				try {
					out.writeUTF(message);
				}catch(IOException e) {
					System.out.println("IOException:"+e.getMessage());
				}
			}//--while
			
		}//--sendToAll
		
		
	}//--ServerReceiver
	
	
	
	public static void main(String[] args) {
		new MultiServer().start();

	}

}
